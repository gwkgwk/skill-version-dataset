# STATUS

We apply for the **Available**, **Functional**, and **Reusable** badges (ACM Artifact Review and Badging v1.1). Reusable implies Functional; each is described below.

## Available

The artifact is deposited in a public archival repository with a DOI — Zenodo, https://doi.org/10.5281/zenodo.19367969 (mirrored on GitHub for convenience) — and is openly licensed under MIT (see `LICENSE`). It is de-identified and contains no live credential values, so it can be shared and reused without restriction.

## Functional

The artifact is documented, consistent, complete, and exercisable, and it ships with verification evidence. `README.md` is the entry point and `REPRODUCE.md` gives a claim-by-claim walkthrough (T1–T6); `REQUIREMENTS.md` lists the prerequisites; and `data/README.md` documents the dataset schema. A single offline command, `python3 code/helper.py analyze`, regenerates the paper's dataset statistics, the 10-pattern taxonomy (Table 3), the RQ1 landscape, and the R6/R8 disclosure and popularity tables, and every check reports `OK`. The static detectors flag a planted credential-to-sink flow, a Docker sandbox self-test reports `PASSED` on both the stdout and network channels with no API key, and the unit-test suite passes. The offline reproduction runs with no network at all, and the sandbox self-test runs its containers under `--network none`; only building or pulling the sandbox image (a one-time step) uses the network.

The checks a reviewer can run, and their expected results:

| Check | Command | Expected |
|-------|---------|----------|
| Dataset / taxonomy / R6 / R8 (offline) | `python3 code/helper.py analyze` | every check `OK`, exit 0 |
| Static detection (regex + AST source→sink) | planted-skill scan (see `ARTIFACT_APPENDIX.md`, E2) | `VUL-001` and an AST `steal→network` flow |
| Unit tests | `python3 -m pytest code/phase2_static/test_*.py code/phase3_dynamic/test_*.py -q` | `7 passed` (or `5 passed, 2 skipped` without Docker) |
| Dynamic sandbox leak detection | `bash code/scripts/03_dynamic_validate.sh --self-test` | `Phase 3 self-test PASSED` (stdout and network) |

## Reusable

The artifact is documented and structured so that others can reuse and repurpose it. It is documented at several levels: `REPRODUCE.md` walks through each claim (T1–T6), `data/README.md` gives the full dataset schema, and every code component carries its own README (for example `code/README.md`, `code/analysis/README.md`, and `code/phase2_static/README.md`), so each part can be understood and reused on its own. The pipeline is cleanly separated into collection, static analysis, dynamic validation, and offline analysis stages that each run independently, behind a single command-line entry point (`code/helper.py`) whose subcommands (`doctor`, `analyze`, `build`, `run`) and standalone scripts make the workflow easy to drive; its behaviour is configured through `config.yaml` and environment knobs, so it can be re-run at different scales or on new inputs without editing code. The released CSVs are schema-documented and load directly with pandas or the Hugging Face `datasets` library (mirror: `AgentSkillPrivacy/SkillLeakBench`); the 10-pattern detection ruleset (`code/phase2_static/scanning_rules.json`) is documented and extensible; and the instrumented sandbox ships as a prebuilt container image that can validate other agent skills. Unit and end-to-end tests, an MIT license, an archival DOI, and a citation entry make the artifact straightforward to adopt, extend, and cite.

### Reuse quickstart

Load the released data with pandas, or from the Hugging Face mirror with the `datasets` library:

```python
import pandas as pd
df = pd.read_csv("data/skills_dataset.csv")            # 520 affected skills

# or, from the Hugging Face mirror (pip install datasets):
from datasets import load_dataset
ds = load_dataset("AgentSkillPrivacy/SkillLeakBench", "affected_skills")
```

Extend the detector by adding a pattern to `code/phase2_static/scanning_rules.json`, then scan any skill directory of your own:

```bash
python3 code/phase2_static/scanner.py --config config.yaml --skill-path <your_skill_dir> --skill-id my_skill --output /tmp/out
```

Validate a skill in the instrumented sandbox using the prebuilt image:

```bash
docker pull ghcr.io/agentskillsprivacy/skill-leakbench:latest
docker tag  ghcr.io/agentskillsprivacy/skill-leakbench:latest skill-leakbench
bash code/scripts/03_dynamic_validate.sh --dual <candidates.json>   # or --interactive
```
