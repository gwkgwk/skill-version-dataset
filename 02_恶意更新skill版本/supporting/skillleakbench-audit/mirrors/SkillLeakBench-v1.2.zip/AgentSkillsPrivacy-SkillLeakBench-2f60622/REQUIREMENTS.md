# REQUIREMENTS

## Architecture and hardware

The artifact was packaged and tested on **x86-64** Linux, and **no GPU is required**. The offline reproduction runs on any laptop; the Docker sandbox is comfortable with about 4 CPU cores, 8 GB of RAM, and 5 GB of free disk.

## Software

Linux or macOS with **Python 3.10 or newer** (tested on 3.11) and the Python packages listed in `requirements.txt` (the pip manifest — `pandas`, `openpyxl`, `tree-sitter`, and so on). **Docker 20.10 or newer** is needed only for the dynamic sandbox and the full pipeline; `pytest` is optional, for the unit tests. The offline reproduction and the static-detection checks need only Python and `requirements.txt` — no Docker, no network, and no credentials.

## Container

The dynamic sandbox ships as a container image. Build it with `python3 code/helper.py build`, or pull the prebuilt image with `docker pull ghcr.io/agentskillsprivacy/skill-leakbench:latest` and tag it `skill-leakbench`. A `Dockerfile` for the sandbox lives in `code/phase3_dynamic/`.

## Optional credentials

Credentials are used only for the live paths: an `ANTHROPIC_API_KEY` (or a mounted `CLAUDE_CREDENTIALS_FILE`) for the agent-driven dual-condition validation, and a `SKILLSMP_API_KEY` for crawling real skills. Use a low-value, scoped key; all leak-target credentials the pipeline plants are mock.

## Network

The offline reproduction, the static-detection checks, and the Docker `--self-test` run without external network access (the self-test runs its containers under `--network none`). Building or pulling the sandbox image is a one-time step that uses the network, as do the agent-driven validation and the crawl.
