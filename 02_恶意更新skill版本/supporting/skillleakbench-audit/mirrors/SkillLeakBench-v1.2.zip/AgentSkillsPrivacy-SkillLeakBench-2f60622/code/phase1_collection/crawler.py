#!/usr/bin/env python3
"""SkillsMP marketplace crawler for SkillLeakBench Phase 1.

Collects skill metadata via the SkillsMP API and downloads repositories
from GitHub. Uses character-based search to enumerate all skills.

API Documentation: https://skillsmp.com/docs/api
- Endpoint: GET /api/v1/skills/search
- Rate Limit: 500 requests/day per API key
"""

import argparse
import json
import logging
import os
import random
import string
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Set
from urllib.parse import urlparse

import requests

# Allow running standalone or as part of the package
try:
    from code.utils.config_loader import Config
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from utils.config_loader import Config

logger = logging.getLogger("crawler")


class SkillsMPCrawler:
    """Crawl skill metadata from SkillsMP and download repositories.

    Uses character-based search to enumerate all skills from the API.
    API requires authentication via Bearer token.
    """

    def __init__(self, config_path: str = None):
        self.config = Config(config_path)
        self.base_dir = self.config.base_dir

        # API settings
        self.search_url = self.config.get(
            "phase1.crawler.api_url",
            "https://skillsmp.com/api/v1/skills/search"
        )
        self.api_key = os.environ.get("SKILLSMP_API_KEY") or self.config.get(
            "phase1.crawler.api_key", ""
        )

        # Crawler settings
        self.page_size = self.config.get("phase1.crawler.page_size", 100)
        self.max_limit = self.config.get("phase1.crawler.max_limit", 0)  # 0 = unlimited

        # Download settings
        self.github_token = (
            os.environ.get("GITHUB_TOKEN")
            or self.config.get("phase1.download.github_token", "")
        )
        self.workers = self.config.get("phase1.download.workers", 5)
        self.timeout = self.config.get("phase1.download.timeout", 300)
        self.retries = self.config.get("phase1.download.retries", 3)

        # HTTP headers
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
            "User-Agent": "SkillLeakBench/1.0",
        }

        # Progress tracking
        self.output_file = self.config.get(
            "phase1.crawler.output_file",
            "code/results/phase1_downloads/skills_metadata.json"
        )
        self.all_skills: List[Dict] = []
        self.exist_ids: Set[str] = set()

    # ------------------------------------------------------------------
    # Metadata crawling
    # ------------------------------------------------------------------

    def crawl_metadata(self, output_file: str = None) -> List[Dict]:
        """Crawl all skill metadata using character-based search.

        SkillsMP API requires a search query, so we enumerate by searching
        each character (a-z, 0-9) to capture all skills.

        Returns a list of dicts with keys:
            skill_id, skill_name, repo_url, description, author, language, ...

        The list is also written to *output_file* as JSON when provided.
        """
        if not self.api_key:
            logger.error("SKILLSMP_API_KEY not set. Get your API key from skillsmp.com")
            return []

        if output_file is None:
            output_file = self.output_file
        output_path = self.base_dir / output_file
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing data for resume
        self._load_existing_data(output_path)

        # Search characters: a-z and 0-9
        search_chars = list(string.ascii_lowercase) + list(string.digits)

        total_new = 0

        for char in search_chars:
            if self.max_limit and len(self.all_skills) >= self.max_limit:
                logger.info("Reached max_limit (%d skills)", self.max_limit)
                break

            logger.info("Searching with character: '%s'", char)
            new_count = self._search_character(char)
            total_new += new_count

            # Save progress after each character
            self._save_data(output_path)

            # Random delay to be polite to the API
            self._random_sleep(0.5, 1.5)

        logger.info("Crawl complete. Total: %d skills, New: %d",
                    len(self.all_skills), total_new)
        return self.all_skills

    def _search_character(self, char: str) -> int:
        """Search for skills using a single character query.

        Returns the number of new skills found.
        """
        new_count = 0
        page = 1

        while True:
            params = {
                "q": char,
                "page": page,
                "limit": self.page_size,
                "sortBy": "recent",
            }

            try:
                resp = self._request_with_retry("GET", self.search_url, params=params)
                if resp is None:
                    break

                data = resp.json()

                # Check for API errors
                if not data.get("success", True):
                    error = data.get("error", {}).get("code", "unknown")
                    logger.error("API error: %s", error)
                    break

                # Extract skills from response
                skills_data = data.get("data", {})
                skills = skills_data.get("skills", [])
                pagination = skills_data.get("pagination", {})

                if not skills:
                    break

                # Process each skill (respect max_limit as a HARD cap, mid-page)
                before = new_count
                for raw in skills:
                    if self.max_limit and len(self.all_skills) >= self.max_limit:
                        break
                    skill_id = str(raw.get("id", ""))
                    if skill_id and skill_id not in self.exist_ids:
                        self.exist_ids.add(skill_id)
                        self.all_skills.append(self._normalize_skill(raw))
                        new_count += 1

                page_new = new_count - before
                if page_new:
                    logger.info("  Page %d: %d new skills (total: %d)",
                                page, page_new, len(self.all_skills))

                # Stop crawling this character once the cap is reached.
                if self.max_limit and len(self.all_skills) >= self.max_limit:
                    break

                # Check pagination
                if not pagination.get("hasNext"):
                    break

                total_pages = pagination.get("totalPages", 0)
                if total_pages and page >= total_pages:
                    break

                page += 1

            except Exception as exc:
                logger.error("Exception during search: %s", exc)
                break

        return new_count

    # ------------------------------------------------------------------
    # Repository downloading
    # ------------------------------------------------------------------

    def download_repos(self, metadata_file: str = None,
                       output_dir: str = None,
                       workers: int = None,
                       limit: int = None) -> None:
        """Download skill repositories listed in a metadata JSON file.

        Progress is tracked so that previously downloaded repos are skipped on
        resume. ``limit`` (default: the crawler's max_limit) caps how many skills
        are downloaded, so a small CRAWL_LIMIT downloads only that many.
        """
        if metadata_file is None:
            metadata_file = self.output_file
        meta_path = self.base_dir / metadata_file
        if not meta_path.exists():
            logger.error("Metadata file not found: %s", meta_path)
            return

        with open(meta_path, "r", encoding="utf-8") as fh:
            skills = json.load(fh)

        if limit is None:
            limit = self.max_limit
        if limit:
            skills = skills[:limit]

        if output_dir is None:
            output_dir = self.config.get(
                "phase1.download.output_dir",
                "code/results/phase1_downloads/zips",
            )
        zip_dir = self.base_dir / output_dir
        zip_dir.mkdir(parents=True, exist_ok=True)

        if workers is None:
            workers = self.workers

        # Load / create progress tracker
        progress_path = self.base_dir / "code/results/phase1_downloads/progress.json"
        progress_path.parent.mkdir(parents=True, exist_ok=True)
        progress = self._load_progress(progress_path)

        # Filter out already-done skills
        # Re-download if marked done but the zip is actually gone (cleaned, or a stale
        # progress.json from a different output dir) — don't trust the recorded status alone.
        todo = [s for s in skills
                if progress.get(s["skill_id"], {}).get("status") != "done"
                or not (zip_dir / f"{s['skill_id']}.zip").exists()]
        logger.info("Skills to download: %d / %d (already done: %d)",
                    len(todo), len(skills), len(skills) - len(todo))

        if not todo:
            logger.info("Nothing to download.")
            return

        success = 0
        failed = 0

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(self._download_single, s, zip_dir): s
                for s in todo
            }
            for future in as_completed(futures):
                skill = futures[future]
                try:
                    result = future.result()
                except Exception as exc:
                    logger.exception("Unexpected error for %s: %s",
                                     skill["skill_id"], exc)
                    result = {"status": "error", "error": str(exc)}

                progress[skill["skill_id"]] = result
                if result["status"] == "done":
                    success += 1
                else:
                    failed += 1

                # Periodically flush progress (every 50 items)
                if (success + failed) % 50 == 0:
                    self._save_progress(progress_path, progress)
                    logger.info("Progress: %d done, %d failed", success, failed)

        self._save_progress(progress_path, progress)
        logger.info("Download complete. Success: %d, Failed: %d", success, failed)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _download_single(self, skill: dict, output_dir: Path) -> dict:
        """Download a single skill repository as a ZIP from GitHub."""
        skill_id = skill["skill_id"]
        repo_url = skill.get("repo_url", "")
        branch = skill.get("branch", "main")

        if not repo_url:
            return {"status": "skipped", "reason": "no repo_url"}

        # Parse owner/repo from various URL forms
        parts = self._parse_github_url(repo_url)
        if parts is None:
            return {"status": "skipped", "reason": f"not a GitHub URL: {repo_url}"}

        owner, repo = parts
        zip_url = (f"https://api.github.com/repos/{owner}/{repo}"
                   f"/zipball/{branch}")
        zip_name = f"{skill_id}.zip"
        zip_path = output_dir / zip_name

        headers = {"Accept": "application/vnd.github+json"}
        if self.github_token:
            headers["Authorization"] = f"Bearer {self.github_token}"

        for attempt in range(1, self.retries + 1):
            try:
                resp = requests.get(zip_url, headers=headers,
                                    timeout=self.timeout, stream=True)
                if resp.status_code == 200:
                    with open(zip_path, "wb") as fh:
                        for chunk in resp.iter_content(chunk_size=8192):
                            fh.write(chunk)
                    size_kb = zip_path.stat().st_size / 1024
                    return {"status": "done",
                            "zip_file": str(zip_path),
                            "size_kb": round(size_kb, 1)}

                if resp.status_code == 404:
                    # A missing repo/zipball will never become 200 — fail fast, no retries.
                    return {"status": "failed", "reason": "HTTP 404 (repo or zipball not found)"}
                if resp.status_code == 429:
                    wait = 2 ** attempt
                    logger.warning("Rate limited for %s, waiting %ds",
                                   skill_id, wait)
                    time.sleep(wait)
                    continue

                if resp.status_code >= 400:
                    logger.warning("HTTP %d for %s (attempt %d/%d)",
                                   resp.status_code, skill_id,
                                   attempt, self.retries)
                    if attempt < self.retries:
                        time.sleep(2)
                    continue

            except requests.RequestException as exc:
                logger.warning("Request error for %s: %s", skill_id, exc)
                if attempt < self.retries:
                    time.sleep(2)

        return {"status": "failed", "reason": f"exhausted {self.retries} retries"}

    @staticmethod
    def _parse_github_url(url: str) -> Optional[tuple]:
        """Extract (owner, repo) from a GitHub URL. Returns None on failure."""
        url = url.rstrip("/")
        # https://github.com/owner/repo(.git)?
        if "github.com" in url:
            parts = url.split("github.com/")[-1]
            parts = parts.replace(".git", "")
            segments = parts.split("/")
            if len(segments) >= 2:
                return segments[0], segments[1]
        return None

    @staticmethod
    def _parse_github_url_full(url: str) -> Optional[tuple]:
        """Return (owner, repo, branch, subdir) from a GitHub URL.

        SkillsMP entries usually point at a skill *inside* a repo, e.g.
        https://github.com/owner/repo/tree/main/skills/foo -> branch 'main',
        subdir 'skills/foo'. branch/subdir are '' when the URL is repo-level.
        """
        if not url or "github.com" not in url:
            return None
        tail = url.rstrip("/").split("github.com/", 1)[-1].replace(".git", "")
        seg = tail.split("/")
        if len(seg) < 2:
            return None
        owner, repo, branch, subdir = seg[0], seg[1], "", ""
        if len(seg) >= 4 and seg[2] in ("tree", "blob"):
            branch, subdir = seg[3], "/".join(seg[4:])
        return owner, repo, branch, subdir

    def _normalize_skill(self, raw: dict) -> dict:
        """Map an API record to a flat dict with our standard keys."""
        # Extract GitHub URL from various possible fields
        repo_url = (
            raw.get("githubUrl") or
            raw.get("source_url") or
            raw.get("html_url") or
            raw.get("repo_url") or
            ""
        )

        # Extract author from various possible fields
        author = (
            raw.get("author") or
            raw.get("owner_name") or
            (raw.get("owner", {}) or {}).get("login") or
            ""
        )

        parsed = self._parse_github_url_full(repo_url)
        url_branch = parsed[2] if parsed else ""
        skill_subdir = parsed[3] if parsed else ""

        return {
            "skill_id": str(raw.get("id", "")),
            "skill_name": raw.get("name") or raw.get("skill_name", ""),
            "repo_url": repo_url,
            "description": raw.get("description", ""),
            "author": author,
            "language": raw.get("language", ""),
            "branch": url_branch or raw.get("default_branch", "main"),
            "skill_subdir": skill_subdir,
            "stars": raw.get("stars") or raw.get("stargazers_count", 0),
            "skill_url": raw.get("skillUrl") or raw.get("url", ""),
            "updated_at": raw.get("updatedAt") or raw.get("updated_at", ""),
            "raw": raw,
        }

    def _request_with_retry(self, method: str, url: str, **kwargs):
        """Execute an HTTP request with exponential backoff on failures."""
        for attempt in range(1, self.retries + 1):
            try:
                resp = requests.request(
                    method, url, headers=self.headers, timeout=30, **kwargs
                )

                # Handle rate limiting
                if resp.status_code == 429:
                    remaining = resp.headers.get("X-RateLimit-Daily-Remaining", "?")
                    logger.warning("Rate limited (remaining: %s), waiting...", remaining)
                    wait = 60 * (2 ** attempt)  # 1min, 2min, 4min
                    time.sleep(wait)
                    continue

                # Handle auth errors
                if resp.status_code == 401:
                    logger.error("Authentication failed. Check SKILLSMP_API_KEY")
                    return None

                resp.raise_for_status()
                return resp

            except requests.RequestException as exc:
                logger.warning("Request failed (attempt %d/%d): %s",
                               attempt, self.retries, exc)
                if attempt < self.retries:
                    time.sleep(2)
        return None

    def _load_existing_data(self, path: Path) -> None:
        """Load existing data from file for resume support."""
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    self.all_skills = json.load(fh)
                    for item in self.all_skills:
                        if "skill_id" in item:
                            self.exist_ids.add(item["skill_id"])
                logger.info("Loaded %d existing skills from %s",
                            len(self.all_skills), path)
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning("Could not load existing data: %s", exc)
                self.all_skills = []
                self.exist_ids = set()

    def _save_data(self, path: Path) -> None:
        """Save current data to file."""
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.all_skills, fh, indent=2, ensure_ascii=False)

    @staticmethod
    def _load_progress(path: Path) -> dict:
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    return json.load(fh)
            except (json.JSONDecodeError, OSError):
                logger.warning("Could not read progress file, starting fresh")
        return {}

    @staticmethod
    def _save_progress(path: Path, data: dict) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

    def _random_sleep(self, min_s: float, max_s: float) -> None:
        """Sleep for random duration to be polite to the API."""
        time.sleep(random.uniform(min_s, max_s))


# ======================================================================
# CLI entry point
# ======================================================================

def main():
    parser = argparse.ArgumentParser(
        description="SkillsMP crawler — metadata + repo download")
    parser.add_argument("--config", default=None,
                        help="Path to config.yaml")
    sub = parser.add_subparsers(dest="command")

    md = sub.add_parser("metadata", help="Crawl skill metadata only")
    md.add_argument("--max-limit", type=int, default=None,
                    help="Cap total skills crawled, overriding config (0 = unlimited)")

    dl = sub.add_parser("download", help="Download repos from metadata file")
    dl.add_argument("--workers", type=int, default=None,
                    help="Concurrent download workers")
    dl.add_argument("--max-limit", type=int, default=None,
                    help="Download at most N skills (default: crawler max_limit)")

    all_cmd = sub.add_parser("all", help="Crawl metadata then download")
    all_cmd.add_argument("--workers", type=int, default=None,
                    help="Concurrent download workers")
    all_cmd.add_argument("--max-limit", type=int, default=None,
                    help="Cap total skills crawled, overriding config (0 = unlimited)")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    crawler = SkillsMPCrawler(args.config)
    if getattr(args, "max_limit", None) is not None:
        crawler.max_limit = args.max_limit

    if args.command == "metadata":
        crawler.crawl_metadata()
    elif args.command == "download":
        crawler.download_repos(workers=args.workers)
    elif args.command == "all":
        crawler.crawl_metadata()
        crawler.download_repos(workers=args.workers)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
