#!/usr/bin/env python3
"""ZIP archive extractor for SkillLeakBench Phase 1.

Extracts downloaded skill repositories into structured directories
suitable for static analysis in Phase 2.
"""

import argparse
import json
import logging
import re
import sys
import zipfile
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

try:
    from code.utils.config_loader import Config
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from utils.config_loader import Config

logger = logging.getLogger("extractor")


def _sanitize_name(name: str) -> str:
    """Produce a filesystem-safe directory name from a skill/archive name."""
    # Remove extension and leading path components
    stem = Path(name).stem
    # Replace characters that are problematic on common filesystems
    sanitized = re.sub(r"[^\w.\-]", "_", stem)
    return sanitized or "unknown"


def extract_single(zip_path: Path, output_dir: Path, subdir: str = "") -> dict:
    """Extract a single ZIP file to output_dir.

    Returns a dict with keys:
        zip_path, output_dir, status, file_count, error (on failure)
    """
    result = {
        "zip_path": str(zip_path),
        "output_dir": str(output_dir),
        "status": "done",
        "file_count": 0,
    }

    if not zip_path.exists():
        result["status"] = "error"
        result["error"] = "file not found"
        return result

    dest = output_dir / _sanitize_name(zip_path.name)
    dest.mkdir(parents=True, exist_ok=True)

    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Extract safe members only (skip path-traversal members)
            safe_members = [
                m for m in zf.namelist()
                if not m.startswith("/") and ".." not in m
            ]
            if subdir:
                # Extract ONLY the skill's subdirectory: SkillsMP points at /tree/<branch>/<subdir>,
                # and one repo can hold dozens of skills, so scoping to the subdir avoids attributing
                # sibling skills' findings here. GitHub zipballs wrap everything in a single
                # "<owner>-<repo>-<sha>/" top dir, which we strip.
                target = subdir.strip("/")
                count = 0
                for m in safe_members:
                    if m.endswith("/"):
                        continue
                    rel = m.split("/", 1)[1] if "/" in m else m   # drop the zipball top dir
                    if rel == target or rel.startswith(target + "/"):
                        inner = rel[len(target):].lstrip("/") or Path(rel).name
                        out_file = dest / inner
                        out_file.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(m) as src, open(out_file, "wb") as dst:
                            dst.write(src.read())
                        count += 1
                if count:
                    result["file_count"] = count
                else:
                    # The recorded subdir is absent (the repo renamed/moved/removed this skill).
                    # Do NOT extract the whole repo -- that pulls in dozens of unrelated sibling
                    # skills and misattributes their findings. Skip the crawled skill instead.
                    result["status"] = "skipped"
                    result["error"] = f"skill subdir {target!r} not in archive (renamed/removed upstream)"
            else:
                zf.extractall(dest, members=safe_members)
                result["file_count"] = len(safe_members)
    except zipfile.BadZipFile:
        result["status"] = "error"
        result["error"] = "bad zip file"
        logger.warning("Bad ZIP: %s", zip_path)
    except Exception as exc:
        result["status"] = "error"
        result["error"] = str(exc)
        logger.warning("Failed to extract %s: %s", zip_path, exc)

    if result["status"] == "skipped":
        try:
            dest.rmdir()  # leave no empty directory behind
        except OSError:
            pass
    return result


def extract_all(zip_dir: str, output_dir: str,
                skip_existing: bool = True,
                workers: int = 4,
                subdir_map: dict = None) -> None:
    """Extract all ZIP files in *zip_dir* into *output_dir*.

    Each archive is extracted to: output_dir/{sanitized_name}/

    If *skip_existing* is True, directories that already exist are skipped.
    """
    zip_path = Path(zip_dir)
    out_path = Path(output_dir)

    if not zip_path.is_dir():
        logger.error("ZIP directory does not exist: %s", zip_path)
        return

    out_path.mkdir(parents=True, exist_ok=True)

    zips = sorted(zip_path.glob("*.zip"))
    if not zips:
        logger.info("No ZIP files found in %s", zip_path)
        return

    # Filter out already-extracted archives when skipping
    if skip_existing:
        remaining = []
        for z in zips:
            dest = out_path / _sanitize_name(z.name)
            if dest.is_dir() and any(dest.iterdir()):
                continue
            remaining.append(z)
        skipped = len(zips) - len(remaining)
        zips = remaining
        if skipped:
            logger.info("Skipped %d already-extracted archives", skipped)

    logger.info("Extracting %d archives with %d workers", len(zips), workers)

    success = 0
    failed = 0
    skipped_gone = 0

    subdir_map = subdir_map or {}
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(extract_single, z, out_path, subdir_map.get(z.stem, "")): z
            for z in zips
        }
        for future in futures:
            zip_file = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {"status": "error", "error": str(exc)}

            if result["status"] == "done":
                success += 1
            elif result["status"] == "skipped":
                skipped_gone += 1
                logger.info("Skipped (skill gone upstream): %s — %s",
                            zip_file.name, result.get("error", ""))
            else:
                failed += 1
                logger.warning("Failed: %s — %s",
                               zip_file.name,
                               result.get("error", "unknown"))

    logger.info("Extraction complete. Success: %d, Skipped (gone upstream): %d, Failed: %d",
                success, skipped_gone, failed)


def main():
    parser = argparse.ArgumentParser(
        description="Extract downloaded skill ZIP archives")
    parser.add_argument("--config", default=None,
                        help="Path to config.yaml")
    parser.add_argument("--zip-dir", default=None,
                        help="Directory containing ZIP files")
    parser.add_argument("--output-dir", default=None,
                        help="Directory for extracted repos")
    parser.add_argument("--workers", type=int, default=4,
                        help="Number of parallel workers")
    parser.add_argument("--no-skip", action="store_true",
                        help="Re-extract even if output directory exists")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    config = Config(args.config)

    zip_dir = args.zip_dir or config.get(
        "phase1.extractor.zip_dir",
        "code/results/phase1_downloads/zips",
    )
    output_dir = args.output_dir or config.get(
        "phase1.extractor.output_dir",
        "code/results/phase1_downloads/repos",
    )

    # Resolve relative paths against the project base dir
    base = config.base_dir
    if not Path(zip_dir).is_absolute():
        zip_dir = str(base / zip_dir)
    if not Path(output_dir).is_absolute():
        output_dir = str(base / output_dir)

    # Map skill_id -> skill_subdir from crawl metadata, so each archive is scoped to just its
    # skill directory (a repo can hold dozens of skills; scoping avoids cross-skill misattribution).
    subdir_map = {}
    meta_file = config.get("phase1.crawler.output_file",
                           "code/results/phase1_downloads/skills_metadata.json")
    meta_path = Path(meta_file) if Path(meta_file).is_absolute() else base / meta_file
    if meta_path.exists():
        try:
            for s in json.load(open(meta_path, encoding="utf-8")):
                if s.get("skill_subdir"):
                    subdir_map[str(s.get("skill_id"))] = s["skill_subdir"]
        except Exception as exc:
            logger.warning("Could not read skill_subdir map from %s: %s", meta_path, exc)

    extract_all(zip_dir, output_dir,
                skip_existing=not args.no_skip,
                workers=args.workers,
                subdir_map=subdir_map)


if __name__ == "__main__":
    main()
