# Phase 1: Data Collection

Crawls skill repositories from SkillsMP marketplace.

## Prerequisites

```bash
export SKILLSMP_API_KEY="your-api-key"  # Required
export GITHUB_TOKEN="ghp_..."           # Recommended for rate limits
```

## Components

| File | Purpose |
|------|---------|
| `crawler.py` | Crawl SkillsMP API + download GitHub repos |
| `extractor.py` | Extract ZIP archives |

## Usage

```bash
python3 crawler.py --config ../../config.yaml all        # Crawl + download
python3 extractor.py --config ../../config.yaml          # Extract ZIPs
```

## Output

```
code/results/phase1_downloads/
├── skills_metadata.json
├── progress.json
├── zips/
└── repos/
```

## API Reference

SkillsMP API: https://skillsmp.com/docs/api

| Endpoint | Description |
|----------|-------------|
| `GET /api/v1/skills/search` | Search by keyword |
| `GET /api/v1/skills/ai-search` | AI semantic search |
