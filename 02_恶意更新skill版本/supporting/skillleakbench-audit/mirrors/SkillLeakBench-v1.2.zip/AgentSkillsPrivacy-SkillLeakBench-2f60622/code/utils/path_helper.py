"""Path utilities for SkillLeakBench (project-root discovery + dir helpers)."""
from pathlib import Path


def get_project_root(start: str = None) -> Path:
    """Walk up from ``start`` (or this file) until a directory with config.yaml."""
    p = Path(start or __file__).resolve()
    for parent in [p, *p.parents]:
        if (parent / "config.yaml").exists():
            return parent
    # fallback: code/utils/ -> repo root
    return Path(__file__).resolve().parent.parent.parent


def ensure_dir(path) -> Path:
    Path(path).mkdir(parents=True, exist_ok=True)
    return Path(path)


def data_dir() -> Path:
    return get_project_root() / "data"


def results_dir() -> Path:
    return get_project_root() / "code" / "results"


def analysis_dir() -> Path:
    return get_project_root() / "code" / "analysis"
