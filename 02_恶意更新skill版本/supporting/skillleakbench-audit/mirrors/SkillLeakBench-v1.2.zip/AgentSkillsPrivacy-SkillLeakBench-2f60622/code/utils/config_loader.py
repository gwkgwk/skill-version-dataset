"""Configuration loader for SkillLeakBench pipeline.

Loads settings from config.yaml and environment variables.
Environment variables take precedence over config.yaml values.
"""

import os
import yaml
from pathlib import Path


class Config:
    """Pipeline configuration loaded from YAML with env var overrides."""

    def __init__(self, config_path: str = None):
        if config_path is None:
            # Walk up from this file to find config.yaml
            config_path = Path(__file__).resolve().parent.parent.parent / "config.yaml"
        self.config_path = Path(config_path)
        self._data = {}
        self._load()

    def _load(self):
        """Load config.yaml and apply environment variable overrides."""
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {self.config_path}")

        with open(self.config_path, "r") as f:
            self._data = yaml.safe_load(f)

        # Apply env var overrides
        github_token = os.environ.get("GITHUB_TOKEN")
        if github_token:
            self._data.setdefault("phase1", {}).setdefault("download", {})[
                "github_token"
            ] = github_token

    def get(self, key_path: str, default=None):
        """Get a nested config value using dot-separated path.

        Example: config.get('phase1.crawler.api_url')
        """
        keys = key_path.split(".")
        value = self._data
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        return value

    @property
    def base_dir(self) -> Path:
        """Resolved base directory for the project."""
        raw = self.get("paths.base_dir", ".")
        p = Path(raw)
        if not p.is_absolute():
            return self.config_path.parent / p
        return p

    def resolve_path(self, relative_path: str) -> Path:
        """Resolve a path relative to base_dir."""
        return self.base_dir / relative_path

    @property
    def raw(self) -> dict:
        """Raw config dictionary."""
        return self._data
