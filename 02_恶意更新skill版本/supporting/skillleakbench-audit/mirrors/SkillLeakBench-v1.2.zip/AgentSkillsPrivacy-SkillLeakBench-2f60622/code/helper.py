#!/usr/bin/env python3
"""SkillLeakBench helper — one entry point for the pipeline and the reproducibility checks.

Run with NO arguments for an interactive menu, or call a subcommand directly:

    python3 code/helper.py            # interactive menu (banner + choices)
    python3 code/helper.py doctor     # check environment / dependencies
    python3 code/helper.py analyze    # reproduce ALL paper numbers from data/ (no secrets/Docker)
    python3 code/helper.py build      # build the dynamic-validation Docker image
    python3 code/helper.py run [--skip 1,3]   # collection + static + Phase-3 self-test (needs secrets/Docker)
    python3 code/helper.py status | clean | init

`analyze` is the recommended path for artifact evaluation: it reproduces the
dataset / Table-3 / RQ1 / R6 / R8 numbers offline.
"""
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent           # repo root
ANALYSIS = ROOT / "code" / "analysis"
ANALYZE_CHECKS = [
    ("verify_dataset.py", ["--check"]),
    ("rq2_taxonomy.py", ["--check"]),
    ("rq1_landscape.py", ["--check"]),
    ("remediation_status.py", ["--check"]),
    ("popularity.py", ["--check"]),
]

BANNER = r"""
────────────────────────────────────────────────────────────────────
   _____ __   _ ______               __   ____                  __  
  / ___// /__(_) / / /   ___  ____ _/ /__/ __ )___  ____  _____/ /_ 
  \__ \/ //_/ / / / /   / _ \/ __ `/ //_/ __  / _ \/ __ \/ ___/ __ \
 ___/ / ,< / / / / /___/  __/ /_/ / ,< / /_/ /  __/ / / / /__/ / / /
/____/_/|_/_/_/_/_____/\___/\__,_/_/|_/_____/\___/_/ /_/\___/_/ /_/ 
                                                                    

         Credential Leakage in LLM Agent Skills  ·  ASE'26          
────────────────────────────────────────────────────────────────────
"""


def print_banner():
    # Fancy on a terminal (bright cyan); plain when piped/redirected so logs stay clean.
    if sys.stdout.isatty():
        print(f"\033[96m{BANNER}\033[0m")
    else:
        print(BANNER)


def _run(cmd):
    print(f"$ {' '.join(str(c) for c in cmd)}")
    return subprocess.run(cmd)


# --------------------------------------------------------------------------- commands
def cmd_doctor(_=None):
    ok = True
    print(f"python: {sys.version.split()[0]}")
    try:
        import yaml  # noqa: F401
        print("[ OK ] pyyaml")
    except ImportError:
        ok = False
        print("[FAIL] pyyaml — pip install -r requirements.txt")
    for mod in ("tree_sitter", "tree_sitter_python", "tree_sitter_javascript"):
        try:
            __import__(mod)
            print(f"[ OK ] {mod}")
        except ImportError:
            print(f"[WARN] {mod} missing — needed for Phase 2 AST (pip install -r requirements.txt)")
    git_path = shutil.which("git")
    print(f"[{'OK ' if git_path else 'WARN'}] git: {git_path or 'not found'}")
    docker_path = shutil.which("docker")
    if not docker_path:
        print("[WARN] docker: not found (needed only to build/run the Phase 3 sandbox)")
    elif subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL).returncode == 0:
        print(f"[ OK ] docker: {docker_path} (daemon reachable)")
    else:
        print(f"[WARN] docker: {docker_path} found but daemon NOT reachable "
              "(start Docker, or use SLB_DOCKER='sudo docker')")
    env = ROOT / "code" / ".env"
    print(f"[{'OK ' if env.exists() else 'WARN'}] code/.env {'present' if env.exists() else 'missing (only needed for `run`)'}")
    for s, _a in ANALYZE_CHECKS:
        exists = (ANALYSIS / s).exists()
        ok = ok and exists
        print(f"[{'OK ' if exists else 'FAIL'}] analysis/{s}")
    print("\ndoctor: " + ("ready — run `analyze`" if ok else "missing dependencies"))
    return 0 if ok else 1


def cmd_init(_=None):
    src, dst = ROOT / "code" / ".env.example", ROOT / "code" / ".env"
    if dst.exists():
        print("code/.env already exists — leaving it untouched")
    else:
        shutil.copyfile(src, dst)
        print(f"created {dst} — fill in SKILLSMP_API_KEY / GITHUB_TOKEN if you will re-run collection")
    print("Reproduce paper numbers without secrets: python3 code/helper.py analyze")
    return 0


def cmd_analyze(_=None):
    print("Reproducing reported statistics from released data/ (offline)\n")
    failures = []
    for script, extra in ANALYZE_CHECKS:
        r = _run([sys.executable, str(ANALYSIS / script), *extra])
        if r.returncode != 0:
            failures.append(script)
        print("")
    if failures:
        print(f"ANALYZE: FAILED -> {', '.join(failures)}")
        return 1
    print("ANALYZE: all checks passed — data/ reproduces the paper's numbers")
    return 0


def cmd_build(_=None):
    if not shutil.which("docker"):
        print("[FAIL] docker not found — install Docker to build the Phase 3 sandbox")
        return 1
    ctx = ROOT / "code" / "phase3_dynamic"
    return _run(["docker", "build", "-t", "skill-leakbench", str(ctx)]).returncode


def cmd_run(args=None):
    skip = getattr(args, "skip", "") or ""
    cmd = ["bash", str(ROOT / "code" / "scripts" / "run_all.sh")]
    if skip:
        cmd += ["--skip", skip]
    print("Full pipeline: Phase 1 needs SKILLSMP_API_KEY; Phase 3 runs the mode set in code/.env")
    print("(PHASE3_MODE, default 'dual' = real agent validation, needs Docker + a Claude credential).")
    print("Set PHASE3_MODE=self-test for the no-API-key sandbox check; edit it via `config`.")
    return _run(cmd).returncode


def _mask(v):
    return (v[:4] + "…") if v and len(v) > 4 else ("set" if v else "")


def _env_or_dotenv(key):
    """A value from the environment, else from code/.env (name presence only)."""
    if os.environ.get(key):
        return os.environ[key]
    envf = ROOT / "code" / ".env"
    if envf.exists():
        for line in envf.read_text().splitlines():
            line = line.strip()
            if line.startswith(key + "=") and not line.startswith("#"):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def _cfg(keys, default=None):
    try:
        import yaml
        d = yaml.safe_load((ROOT / "config.yaml").read_text())
        for k in keys:
            d = d[k]
        return d
    except Exception:
        return default


def _json_len(path, key=None):
    try:
        import json
        data = json.load(open(path, encoding="utf-8"))
        if key and isinstance(data, dict):
            data = data.get(key, data)
        return len(data)
    except Exception:
        return None


def _count_skill_dirs(root):
    """Number of SKILL directories: a dir is a skill only if it holds SKILL.md."""
    if not root.exists():
        return 0
    return sum(1 for _ in root.rglob("SKILL.md")) + sum(1 for _ in root.rglob("skill.md"))


# Editable pipeline knobs stored in code/.env (status shows them; `config` edits them).
ENV_KNOBS = [
    ("CRAWL_LIMIT", "0", "Phase 1: max skills to crawl in total (0 = unlimited)"),
    ("DOWNLOAD_WORKERS", "5", "Phase 1: concurrent repo downloads"),
    ("PHASE3_MODE", "dual", "Phase 3: 'dual' (real agent B/A x3) or 'self-test' (no API key)"),
    ("DOCKER_IMAGE", "skill-leakbench", "Phase 3: sandbox image name"),
    ("DOCKER_CMD", "docker", "Phase 3: docker binary (e.g. 'sudo docker')"),
    ("DUAL_ROUNDS", "3", "Phase 3: rounds per condition (B>=2 / A>=1 tuned for 3)"),
    ("DUAL_NETWORK", "bridge", "Phase 3: docker network for the agent"),
]


def _env_config():
    return {k: (_env_or_dotenv(k) or default) for k, default, _desc in ENV_KNOBS}


def cmd_status(_=None):
    print("API / credentials:")
    sk = _env_or_dotenv("SKILLSMP_API_KEY")
    gh = _env_or_dotenv("GITHUB_TOKEN")
    print(f"  SKILLSMP_API_KEY : {_mask(sk) if sk else 'unset  (required for Phase 1 crawl)'}")
    print(f"  GITHUB_TOKEN     : {'set' if gh else 'unset  (optional; raises GitHub download limits)'}")
    creds = [p for p in (Path("/data/claude_home/.credentials.json"),
                         Path.home() / ".claude" / ".credentials.json") if p.exists()]
    anth = "set" if os.environ.get("ANTHROPIC_API_KEY") else "unset"
    print(f"  Claude auth      : {('found ' + str(creds[0])) if creds else 'none'}; "
          f"ANTHROPIC_API_KEY {anth}  (one is required for Phase 3 --dual)")

    print("\nDocker:")
    dk = shutil.which("docker")
    if not dk:
        print("  not installed (needed only for Phase 3)")
    else:
        daemon = subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL).returncode == 0
        img = subprocess.run(["docker", "image", "inspect", "skill-leakbench"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
        print(f"  {dk}  | daemon: {'reachable' if daemon else 'NOT reachable'}"
              f"  | image skill-leakbench: {'built' if img else 'not built (run `build`)'}")

    cfg = _env_config()
    print("\nPipeline config (code/.env  —  edit with `config`):")
    for k, _default, _desc in ENV_KNOBS:
        print(f"  {k:<16} = {cfg[k]}")

    print("\nProgress (a SKILL = a directory containing SKILL.md):")
    print(f"  metadata records crawled : {_json_len(ROOT / 'code/results/phase1_downloads/skills_metadata.json') or 0}")
    print(f"  skills extracted         : {_count_skill_dirs(ROOT / 'code/results/phase1_downloads/repos')}")
    print(f"  static candidates        : {_json_len(ROOT / 'code/results/phase2_scan/candidates.json', 'candidates') or 0}")
    return 0


def cmd_config(_=None):
    """View + edit the pipeline knobs in code/.env (Enter keeps the current value)."""
    env_path = ROOT / "code" / ".env"
    if not env_path.exists():
        src = ROOT / "code" / ".env.example"
        if src.exists():
            shutil.copyfile(src, env_path)
            print(f"created {env_path} from .env.example")
    cfg = _env_config()
    print("Edit pipeline config (Enter = keep current):\n")
    new = {}
    for k, _default, desc in ENV_KNOBS:
        try:
            ans = input(f"  {k} [{cfg[k]}]  ({desc}): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        new[k] = ans or cfg[k]
    # Rewrite code/.env, updating knob lines in place and preserving secrets + comments.
    lines = env_path.read_text().splitlines() if env_path.exists() else []
    seen, out = set(), []
    for line in lines:
        head = line.split("=", 1)
        if len(head) == 2 and not line.lstrip().startswith("#") and head[0].strip() in new:
            key = head[0].strip()
            out.append(f"{key}={new[key]}")
            seen.add(key)
        else:
            out.append(line)
    for k, _default, _desc in ENV_KNOBS:
        if k not in seen:
            out.append(f"{k}={new[k]}")
    env_path.write_text("\n".join(out) + "\n")
    env_path.chmod(0o600)
    print(f"\nsaved {env_path}")
    return 0


def cmd_clean(_=None):
    d = ROOT / "code" / "results"
    if d.exists():
        shutil.rmtree(d)
        print(f"removed {d}")
    else:
        print("nothing to clean (code/results/ absent)")
    print("note: data/ is preserved")
    return 0


# --------------------------------------------------------------------------- interactive menu
MENU = [
    ("1", "doctor", "check Python deps, tree-sitter, Docker, credentials", cmd_doctor),
    ("2", "analyze", "reproduce ALL paper numbers from data/ (offline; recommended)", cmd_analyze),
    ("3", "init", "create code/.env (only needed to re-run data collection)", cmd_init),
    ("4", "config", "view / edit pipeline config in code/.env (crawl limit, Phase-3 mode, ...)", cmd_config),
    ("5", "build", "build the Phase 3 Docker sandbox image (needs Docker)", cmd_build),
    ("6", "run", "run the pipeline: collect + static + Phase 3 (dual by default; needs keys + Docker)", cmd_run),
    ("7", "status", "show API / Docker / config + crawl & candidate progress", cmd_status),
    ("8", "clean", "remove code/results/ (keeps data/)", cmd_clean),
]


def interactive_menu():
    actions = {k: (name, desc, fn) for k, name, desc, fn in MENU}
    while True:
        print_banner()
        print("Typical reproduction flow:  1 doctor  ->  2 analyze  (then 3/4/5 for the live pipeline)\n")
        print("Choose an action:")
        for k, name, desc, _fn in MENU:
            print(f"  {k}. {name:<8} {desc}")
        print("  0. exit")
        try:
            choice = input("\nSelect [2]: ").strip() or "2"
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if choice == "0":
            return 0
        if choice not in actions:
            print(f"  ? unknown option: {choice}\n")
            continue
        name, _desc, fn = actions[choice]
        print(f"\n--- {name} ---")
        try:
            fn(None)
        except Exception as exc:  # keep the menu alive on errors
            print(f"error in {name}: {exc}")
        try:
            again = input("\nBack to menu? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if again in ("n", "no"):
            return 0


def main():
    if len(sys.argv) == 1:
        return interactive_menu()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("doctor", "init", "analyze", "build", "status", "clean", "config"):
        sub.add_parser(name)
    pr = sub.add_parser("run")
    pr.add_argument("--skip", default="", help="comma-separated phases to skip, e.g. 1,3")
    args = ap.parse_args()
    return {
        "doctor": cmd_doctor, "init": cmd_init, "analyze": cmd_analyze, "build": cmd_build,
        "run": cmd_run, "status": cmd_status, "clean": cmd_clean, "config": cmd_config,
    }[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
