#!/usr/bin/env python3
"""R8: popularity of hardcoded-credential repositories (May-2026 re-check).

Reproduces: among the 28 accessible affected repositories, mean stars 80.79 /
forks 13.71 (median 9 / 1.5), strongly long-tailed, with Pearson r(stars,forks)
= 0.991. The paper frames popularity as an *amplification/persistence* factor.

Provenance: --regen reads the authors' private re-check CSV and writes a
sanitized, name-free data/popularity_hardcoded_repos.csv (repo_status, stars,
forks only -- no repo/owner names, preserving username removal). Downstream
reproduction reads only the sanitized CSV.
"""
import argparse
import csv
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data"))
SANITIZED = os.path.join(DATA, "popularity_hardcoded_repos.csv")
# Private re-check source (authors'). Used only by --regen; --check reads data/ only.
# Override the root with SLB_PRIVATE_DIR, or the file directly with --src.
_PRIV = os.environ.get("SLB_PRIVATE_DIR", "/data/ase")
DEFAULT_SRC = os.path.join(_PRIV, "exam", "github_popularity_recheck_2026-05-26_repos.csv")
EXPECT = {"accessible": 28, "stars_mean": 80.79, "forks_mean": 13.71, "pearson": 0.991}


def regen(src):
    with open(src, newline="") as f:
        rows = list(csv.DictReader(f))
    with open(SANITIZED, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["repo_status", "stars", "forks"])
        for r in rows:
            w.writerow([r["repo_status"], r.get("stars", ""), r.get("forks", "")])
    print(f"regenerated {SANITIZED} ({len(rows)} rows, name-free)")


def pearson(xs, ys):
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    cov = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    sx = sum((x - mx) ** 2 for x in xs) ** 0.5
    sy = sum((y - my) ** 2 for y in ys) ** 0.5
    return cov / (sx * sy) if sx and sy else float("nan")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--src", default=DEFAULT_SRC, help="private re-check CSV (only with --regen)")
    ap.add_argument("--regen", action="store_true", help="re-derive sanitized CSV from --src")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.regen:
        regen(a.src)

    with open(SANITIZED, newline="") as f:
        rows = list(csv.DictReader(f))
    acc = [r for r in rows if r["repo_status"] == "available"]

    def col(c):
        return [float(r[c]) for r in acc if str(r.get(c, "")).strip() not in ("", "NA", "None")]

    stars, forks = col("stars"), col("forks")
    r = pearson(stars, forks)
    print(f"accessible repos: {len(acc)} (paper 28)")
    print(f"stars  mean={sum(stars)/len(stars):.2f} median={statistics.median(stars)} (paper mean 80.79, median 9)")
    print(f"forks  mean={sum(forks)/len(forks):.2f} median={statistics.median(forks)} (paper mean 13.71, median 1.5)")
    print(f"pearson r(stars,forks)={r:.3f} (paper 0.991)")
    ok = (len(acc) == EXPECT["accessible"]
          and round(sum(stars)/len(stars), 2) == EXPECT["stars_mean"]
          and round(sum(forks)/len(forks), 2) == EXPECT["forks_mean"]
          and round(r, 3) == EXPECT["pearson"])
    print("CHECK OK" if ok else "MISMATCH")
    if a.check and not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
