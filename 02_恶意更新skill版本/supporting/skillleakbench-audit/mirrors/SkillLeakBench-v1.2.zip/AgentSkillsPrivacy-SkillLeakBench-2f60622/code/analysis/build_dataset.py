#!/usr/bin/env python3
"""Provenance step: derive the released, sanitized dataset from the authoritative
per-issue master (`creds_in_skills.xlsx`).

The master is the authors' private analysis workbook; it is NOT redistributed
because some columns (IOC, File:Line, Code Snippet) can contain raw credential
strings. This script emits two public, sanitized CSVs:

  data/issues.csv          one row per security issue (1,708): skill + pattern + severity
  data/skills_dataset.csv  one row per affected skill (520): aggregated patterns + counts

Run by maintainers when the master changes:
    python3 build_dataset.py --xlsx /path/to/creds_in_skills.xlsx
Downstream analysis (rq2_taxonomy.py etc.) reads only the sanitized CSVs.
"""
import argparse
import csv
import collections
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data"))
# Private source (authors' master). Used only by the --regen/maintainer path; the
# public reproduction (rq2_taxonomy.py --check etc.) reads only data/ and never touches it.
# Override the root with SLB_PRIVATE_DIR, or the file directly with --xlsx.
_PRIV = os.environ.get("SLB_PRIVATE_DIR", "/data/ase")
DEFAULT_XLSX = os.path.join(_PRIV, "exam", "creds_in_skills.xlsx")

# Academic-classification code -> (classification, paper pattern name).
# Paper Table 3 names; master labels VUL-D internally as "Side Channel Leakage".
CODE_MAP = {
    "VUL-A": ("vulnerable", "Hardcoded Credentials"),
    "VUL-B": ("vulnerable", "Insecure Storage"),
    "VUL-C": ("vulnerable", "Information Exposure"),
    "VUL-D": ("vulnerable", "Artifact Leakage"),
    "MAL-A": ("malicious", "Remote Exploitation"),
    "MAL-B": ("malicious", "Credential Compromise"),
    "MAL-C": ("malicious", "Data Exfiltration"),
    "MAL-D": ("malicious", "Defense Evasion"),
    "MAL-E": ("malicious", "Persistence"),
    "MAL-F": ("malicious", "Resource Hijacking"),
}
SEV_RANK = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


def code_of(academic):
    return str(academic).split(":", 1)[0].strip()


def read_issue_sheets(xlsx):
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    out = []
    for sheet in ("02_Malicious_Issues", "03_Vulnerability_Issues"):
        ws = wb[sheet]
        it = ws.iter_rows(values_only=True)
        hdr = list(next(it))
        idx = {h: i for i, h in enumerate(hdr)}
        for r in it:
            if r[idx["Skill ID"]] is None:
                continue
            code = code_of(r[idx["Academic Classification"]])
            cls, pattern = CODE_MAP[code]
            out.append({
                "skill_id": r[idx["Skill ID"]],
                "skill_name": r[idx["Skill Name"]],
                "classification": cls,
                "pattern_id": r[idx["Pattern ID"]],
                "academic_code": code,
                "pattern": pattern,
                "severity": str(r[idx["Severity"]]).strip().upper(),
            })
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--xlsx", default=DEFAULT_XLSX)
    a = ap.parse_args()
    issues = read_issue_sheets(a.xlsx)

    # issues.csv (sanitized: no IOC / file / code / analysis columns)
    cols = ["skill_id", "skill_name", "classification", "pattern_id", "academic_code", "pattern", "severity"]
    with open(os.path.join(DATA, "issues.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(issues)

    # skills_dataset.csv: one row per CASE (skill x classification) -> 520 = 437 vuln + 83 mal,
    # matching the paper/README wording ("520 confirmed cases"). A skill exhibiting both a
    # vulnerability and a malicious pattern counts as two cases (one vulnerable, one malicious).
    cases = collections.OrderedDict()
    for it in issues:
        key = (it["skill_id"], it["classification"])
        c = cases.setdefault(key, {"skill_name": it["skill_name"], "classification": it["classification"],
                                   "patterns": set(), "issue_count": 0, "sev": 0})
        c["patterns"].add(it["pattern"])
        c["issue_count"] += 1
        c["sev"] = max(c["sev"], SEV_RANK.get(it["severity"], 0))
    rank_sev = {v: k for k, v in SEV_RANK.items()}
    with open(os.path.join(DATA, "skills_dataset.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["source", "skill_name", "classification", "patterns", "issue_count", "severity"])
        for c in cases.values():
            w.writerow(["skillsmp", c["skill_name"], c["classification"],
                        ";".join(sorted(c["patterns"])), c["issue_count"], rank_sev.get(c["sev"], "")])

    # provenance summary + invariants
    n_cases = len(cases)
    n_vuln = sum(1 for c in cases.values() if c["classification"] == "vulnerable")
    n_mal = sum(1 for c in cases.values() if c["classification"] == "malicious")
    distinct = {sid for sid, _ in cases}
    dual = [sid for sid in distinct if (sid, "vulnerable") in cases and (sid, "malicious") in cases]
    print(f"issues.csv rows={len(issues)} (expect 1708)")
    print(f"skills_dataset.csv cases={n_cases} (expect 520)  vulnerable={n_vuln} (437)  malicious={n_mal} (83)")
    print(f"distinct skills={len(distinct)}  dual-class skills={len(dual)}: {dual}")
    assert len(issues) == 1708, "issue count != 1708"
    assert n_cases == 520 and n_vuln == 437 and n_mal == 83, "case totals off"
    print("OK: derived sanitized CSVs reproduce headline totals + Table 3")


if __name__ == "__main__":
    main()
