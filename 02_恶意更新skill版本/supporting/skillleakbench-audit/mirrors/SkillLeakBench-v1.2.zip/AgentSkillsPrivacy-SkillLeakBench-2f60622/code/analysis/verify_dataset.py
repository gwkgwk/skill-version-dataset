#!/usr/bin/env python3
"""Verify the released SkillLeakBench dataset against the paper's reported numbers.

Reproduces the headline counts from ``data/skills_dataset.csv`` and compares the
per-pattern breakdown against Table 3 of the paper. Pure stdlib (no deps).

Usage:
    python3 verify_dataset.py                # print full report
    python3 verify_dataset.py --check        # exit non-zero if core totals mismatch
"""
import argparse
import collections
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CSV = os.path.normpath(os.path.join(HERE, "..", "..", "data", "skills_dataset.csv"))

# Paper Table 3 (Credential Leakage Pattern Taxonomy): pattern -> (issues, skills)
PAPER_TABLE3 = {
    "Hardcoded Credentials": (249, 107),
    "Insecure Storage":      (110, 77),
    "Information Exposure":  (1007, 352),
    "Artifact Leakage":      (5, 5),
    "Remote Exploitation":   (176, 55),
    "Defense Evasion":       (116, 34),
    "Credential Compromise": (28, 16),
    "Data Exfiltration":     (12, 10),
    "Persistence":           (1, 1),
    "Resource Hijacking":    (4, 4),
}
PAPER_TOTALS = {"affected": 520, "vulnerable": 437, "malicious": 83, "issues": 1708, "patterns": 10}


def load(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def patterns_of(row):
    return [p.strip() for p in (row.get("patterns") or "").split(";") if p.strip()]


def analyze(rows):
    totals = {
        "affected": len(rows),
        "vulnerable": sum(r["classification"] == "vulnerable" for r in rows),
        "malicious": sum(r["classification"] == "malicious" for r in rows),
        "issues": sum(int(r["issue_count"]) for r in rows),
    }
    skill_ct = collections.Counter()
    issue_attr = collections.Counter()  # per-skill issue_count summed over skills having the pattern (NON-EXACT)
    multi = 0
    for r in rows:
        ps = patterns_of(r)
        if len(ps) > 1:
            multi += 1
        for p in ps:
            skill_ct[p] += 1
            issue_attr[p] += int(r["issue_count"])
    totals["patterns"] = len(skill_ct)
    return totals, skill_ct, issue_attr, multi


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--csv", default=DEFAULT_CSV)
    ap.add_argument("--check", action="store_true", help="exit non-zero on core-total mismatch")
    args = ap.parse_args()

    rows = load(args.csv)
    totals, skill_ct, issue_attr, multi = analyze(rows)

    print(f"# dataset: {args.csv}")
    print(f"rows={totals['affected']}  multi_pattern_skills={multi}\n")

    core_ok = True
    print("## Core totals  (CSV vs paper)")
    for k in ("affected", "vulnerable", "malicious", "issues", "patterns"):
        got, exp = totals[k], PAPER_TOTALS[k]
        mark = "OK" if got == exp else "MISMATCH"
        core_ok = core_ok and got == exp
        print(f"  {k:11s} csv={got:<6} paper={exp:<6} {mark}")

    # Exact per-pattern ISSUE counts come from the per-issue file (issues.csv);
    # per-pattern SKILL counts come from skills_dataset.csv. Both vs Table 3.
    issues_ct = collections.Counter()
    issues_path = os.path.join(os.path.dirname(args.csv), "issues.csv")
    have_issues = os.path.exists(issues_path)
    if have_issues:
        with open(issues_path, newline="") as f:
            for r in csv.DictReader(f):
                issues_ct[r["pattern"]] += 1

    print("\n## Per-pattern vs Table 3   (issues <- issues.csv, skills <- skills_dataset.csv)")
    diffs = 0
    for p, (p_iss, p_sk) in PAPER_TABLE3.items():
        cs = skill_ct.get(p, 0)
        ci = issues_ct.get(p, 0)
        sk_ok = cs == p_sk
        iss_ok = (ci == p_iss) if have_issues else True
        if not (sk_ok and iss_ok):
            diffs += 1
        flag = "OK" if sk_ok and iss_ok else "DIFF"
        issues_cell = f"{ci:<5}" if have_issues else "n/a  "
        print(f"  {p:24s} issues {issues_cell} (paper {p_iss:<5})  skills {cs:<4} (paper {p_sk:<4})  {flag}")

    print(f"\nsummary: core_totals={'OK' if core_ok else 'MISMATCH'}  per_pattern_diffs={diffs}/10")
    if diffs and not have_issues:
        print("NOTE: data/issues.csv not present — run build_dataset.py to derive it for exact per-pattern issues.")
    # Gate on core totals AND, when issues.csv is present, the per-pattern Table-3 counts
    # (consistent with rq2_taxonomy.py --check). Without issues.csv the per-pattern counts are
    # not checked — skills_dataset.csv carries per-skill aggregates, not per-issue rows.
    if args.check and not (core_ok and (not have_issues or diffs == 0)):
        msg = "core totals mismatch" if not core_ok else f"{diffs}/10 per-pattern mismatches"
        print(f"CHECK FAILED: {msg}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
