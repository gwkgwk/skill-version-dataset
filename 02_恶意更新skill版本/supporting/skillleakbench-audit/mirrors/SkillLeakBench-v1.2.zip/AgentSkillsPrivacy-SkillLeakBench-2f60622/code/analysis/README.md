# `analysis/` — reproduce the paper's numbers

Every check runs **offline from `data/`** (no secrets, no Docker). One command:

```bash
python3 code/helper.py analyze     # runs all --check scripts below
```

| Script | Reproduces | Input | `--check` |
|--------|-----------|-------|:--:|
| `verify_dataset.py` | 520 affected, 437/83, 1,708 issues, 10 patterns | `data/skills_dataset.csv` | ✓ |
| `rq2_taxonomy.py` | Table 3 (per-pattern issues + skills; 1,708) | `data/issues.csv` | ✓ |
| `rq1_landscape.py` | 520/437/83, 1,708, mean 3.28 / median 2 issues-per-skill, severity dist | `data/{skills_dataset,issues}.csv` | ✓ |
| `remediation_status.py` | R6: malicious 83/83; vulnerable 437/374/63; hardcoded 107/100/7 | `data/remediation_summary.csv` | ✓ |
| `popularity.py` | R8: 28 accessible repos, stars 80.79 / forks 13.71, Pearson r=0.991 | `data/popularity_hardcoded_repos.csv` | ✓ |
| `patterns.py` | the 10-pattern taxonomy (reference module) | — | — |
| `build_dataset.py` | *(maintainers)* derive `issues.csv` + `skills_dataset.csv` from the private master | `creds_in_skills.xlsx` | — |

The released `data/` reproduces the paper's **dataset, 10-pattern taxonomy (Table 3), and the R6/R8
disclosure & popularity results**; `build_dataset.py` regenerates the released CSVs from the
authors' master workbook.
