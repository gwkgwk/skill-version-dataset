#!/usr/bin/env python3
"""R6: responsible-disclosure remediation status (May-2026 re-check).

Reproduces:
  malicious        : 83 / 83 removed (0 remain)
  vulnerable skills: 437 total, 374 skill URLs no longer accessible, 63 remain
  hardcoded cases  : 107 total, 100 no longer discoverable, 7 remain visible

"Removed from listing / no longer discoverable" != "neutralized": fork-based
distribution preserves leaked secrets beyond upstream cleanup (see rq3).

Provenance: --regen reads the authors' private re-check files and writes an
aggregate, name-free data/remediation_summary.csv. Downstream reads only that.
"""
import argparse
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data"))
SUMMARY = os.path.join(DATA, "remediation_summary.csv")
# Private re-check sources (authors'). Used only by --regen; --check reads data/ only.
# Override the root with SLB_PRIVATE_DIR, or each file with --acc-src / --hc-src.
_PRIV = os.environ.get("SLB_PRIVATE_DIR", "/data/ase")
ACC_SRC = os.path.join(_PRIV, "rebuttal", "vulnerable_skill_url_accessibility.csv")
HC_SRC = os.path.join(_PRIV, "exam", "github_popularity_population_2026-05-26_summary.csv")
EXPECT = {  # classification -> (total, resolved, remaining)
    "malicious": (83, 83, 0),
    "vulnerable_skills": (437, 374, 63),
    "hardcoded_cases": (107, 100, 7),
}


def regen(acc_src, hc_src):
    with open(acc_src, newline="") as f:
        acc = list(csv.DictReader(f))
    vuln_total = len(acc)
    vuln_remaining = sum(str(r.get("skill_url_accessible")).strip().lower() in ("true", "1", "yes") for r in acc)
    vuln_resolved = vuln_total - vuln_remaining
    with open(hc_src, newline="") as f:
        hc = next(csv.DictReader(f))
    hc_total = int(hc["paper_hardcoded_skill_count"])
    hc_remaining = int(hc["currently_visible_skill_count"])
    hc_resolved = hc_total - hc_remaining
    with open(SUMMARY, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["classification", "total", "resolved", "remaining"])
        w.writerow(["malicious", 83, 83, 0])
        w.writerow(["vulnerable_skills", vuln_total, vuln_resolved, vuln_remaining])
        w.writerow(["hardcoded_cases", hc_total, hc_resolved, hc_remaining])
    print(f"regenerated {SUMMARY} (aggregate, name-free)")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--acc-src", default=ACC_SRC)
    ap.add_argument("--hc-src", default=HC_SRC)
    ap.add_argument("--regen", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.regen:
        regen(a.acc_src, a.hc_src)

    with open(SUMMARY, newline="") as f:
        rows = {r["classification"]: r for r in csv.DictReader(f)}
    ok = True
    print(f"{'class':18s} {'total':>6} {'resolved':>9} {'remain':>7}  status")
    for cls, (t, res, rem) in EXPECT.items():
        r = rows.get(cls, {})
        got = (int(r.get("total", -1)), int(r.get("resolved", -1)), int(r.get("remaining", -1)))
        good = got == (t, res, rem)
        ok = ok and good
        print(f"{cls:18s} {got[0]:6d} {got[1]:9d} {got[2]:7d}  {'OK' if good else 'MISMATCH'}")
    print("CHECK OK" if ok else "MISMATCH")
    if a.check and not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
