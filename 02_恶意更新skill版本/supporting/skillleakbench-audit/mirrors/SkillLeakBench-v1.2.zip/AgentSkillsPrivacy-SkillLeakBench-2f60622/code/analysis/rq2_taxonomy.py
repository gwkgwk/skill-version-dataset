#!/usr/bin/env python3
"""Reproduce paper Table 3 (Credential Leakage Pattern Taxonomy) from data/issues.csv.

For each of the 10 leakage patterns: issues = number of issue rows; skills = distinct
skill_id. --check exits non-zero if any pattern's (issues, skills) differs from the paper.
"""
import argparse
import collections
import csv
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT = os.path.normpath(os.path.join(HERE, "..", "..", "data", "issues.csv"))

# Paper Table 3: pattern -> (issues, skills), in paper order (4 vulnerability + 6 malicious)
PAPER = [
    ("Hardcoded Credentials", (249, 107)),
    ("Insecure Storage",      (110, 77)),
    ("Information Exposure",  (1007, 352)),
    ("Artifact Leakage",      (5, 5)),
    ("Remote Exploitation",   (176, 55)),
    ("Defense Evasion",       (116, 34)),
    ("Credential Compromise", (28, 16)),
    ("Data Exfiltration",     (12, 10)),
    ("Persistence",           (1, 1)),
    ("Resource Hijacking",    (4, 4)),
]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--csv", default=DEFAULT)
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    issues = collections.Counter()
    skills = collections.defaultdict(set)
    with open(args.csv, newline="") as f:
        for r in csv.DictReader(f):
            p = r["pattern"]
            issues[p] += 1
            skills[p].add(r["skill_id"])

    print(f"{'pattern':24s} {'issues':>7} {'skills':>7}   {'paper':>11}  status")
    ok = True
    tot_i = 0
    for p, (pi, ps) in PAPER:
        ci, cs = issues.get(p, 0), len(skills.get(p, set()))
        tot_i += ci
        good = (ci, cs) == (pi, ps)
        ok = ok and good
        print(f"{p:24s} {ci:7d} {cs:7d}   {pi:5d}/{ps:<5d}  {'OK' if good else 'MISMATCH'}")
    print(f"\ntotal issues={tot_i} (paper 1708)")
    if args.check and not (ok and tot_i == 1708):
        print("CHECK FAILED", file=sys.stderr)
        sys.exit(1)
    print("CHECK OK" if ok and tot_i == 1708 else "MISMATCH (see above)")


if __name__ == "__main__":
    main()
