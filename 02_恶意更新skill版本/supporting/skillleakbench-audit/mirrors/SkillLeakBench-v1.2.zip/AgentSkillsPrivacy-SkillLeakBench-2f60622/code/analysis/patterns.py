"""The 10 credential-leakage patterns (paper Table 3 taxonomy).

4 vulnerability patterns (developer negligence) + 6 malicious patterns
(deliberate construction). Codes match the per-issue master's academic
classification; ``name`` matches the paper. Reference module imported by the
other analysis scripts.
"""
from collections import namedtuple

Pattern = namedtuple("Pattern", "code name kind channel cwe severity")

PATTERNS = [
    Pattern("VUL-A", "Hardcoded Credentials", "vulnerability", "Source code, documentation, config files", "CWE-798", "HIGH"),
    Pattern("VUL-B", "Insecure Storage",      "vulnerability", "CLI arguments, process/URL parameters",    "CWE-312", "MEDIUM"),
    Pattern("VUL-C", "Information Exposure",   "vulnerability", "Console logs, debug output, API responses", "CWE-532", "MEDIUM"),
    Pattern("VUL-D", "Artifact Leakage",       "vulnerability", "Shell history, temp files, cache, git config", "CWE-200", "LOW"),
    Pattern("MAL-A", "Remote Exploitation",    "malicious",     "RCE backdoors, reverse shells",            "CWE-94",  "CRITICAL"),
    Pattern("MAL-B", "Credential Compromise",  "malicious",     "Social engineering, env/SSH key theft",    "CWE-522", "HIGH"),
    Pattern("MAL-C", "Data Exfiltration",      "malicious",     "Keyloggers, XSS, webhook exfiltration",     "CWE-200", "HIGH"),
    Pattern("MAL-D", "Defense Evasion",        "malicious",     "Base64/encoding obfuscation",               "CWE-506", "MEDIUM"),
    Pattern("MAL-E", "Persistence",            "malicious",     "C2 beaconing, authorized keys",             "CWE-507", "HIGH"),
    Pattern("MAL-F", "Resource Hijacking",     "malicious",     "Crypto miners",                             "CWE-400", "MEDIUM"),
]

BY_NAME = {p.name: p for p in PATTERNS}
BY_CODE = {p.code: p for p in PATTERNS}
VULNERABILITY = [p for p in PATTERNS if p.kind == "vulnerability"]
MALICIOUS = [p for p in PATTERNS if p.kind == "malicious"]

if __name__ == "__main__":
    for p in PATTERNS:
        print(f"{p.code}  {p.name:24s} {p.kind:13s} {p.cwe:8s} {p.severity}")
    print(f"\n{len(VULNERABILITY)} vulnerability + {len(MALICIOUS)} malicious = {len(PATTERNS)} patterns")
    assert len(PATTERNS) == 10 and len(VULNERABILITY) == 4 and len(MALICIOUS) == 6
