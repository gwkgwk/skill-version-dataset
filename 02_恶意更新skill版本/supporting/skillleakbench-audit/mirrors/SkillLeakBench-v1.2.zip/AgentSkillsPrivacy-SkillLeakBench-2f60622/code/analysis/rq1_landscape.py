#!/usr/bin/env python3
"""RQ1 landscape statistics, reproduced from the released data/.

Reproduces: 520 affected cases (437 vulnerable / 83 malicious), 1,708 issues,
mean 3.28 / median 2 issues per affected skill, and the severity distribution.
"""
import argparse
import collections
import csv
import os
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "..", "data"))
EXPECT = {"affected": 520, "vulnerable": 437, "malicious": 83, "issues": 1708,
          "mean_ips": 3.28, "median_ips": 2.0}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()

    with open(os.path.join(DATA, "skills_dataset.csv"), newline="") as f:
        cases = list(csv.DictReader(f))
    with open(os.path.join(DATA, "issues.csv"), newline="") as f:
        issues = list(csv.DictReader(f))

    cls = collections.Counter(c["classification"] for c in cases)
    ips = [int(c["issue_count"]) for c in cases]
    sev = collections.Counter(i["severity"] for i in issues)
    got = {
        "affected": len(cases), "vulnerable": cls["vulnerable"], "malicious": cls["malicious"],
        "issues": len(issues), "mean_ips": round(sum(ips) / len(ips), 2),
        "median_ips": float(statistics.median(ips)),
    }

    print("RQ1 landscape:")
    for k in ("affected", "vulnerable", "malicious", "issues", "mean_ips", "median_ips"):
        mark = "OK" if got[k] == EXPECT[k] else "MISMATCH"
        print(f"  {k:11s} = {got[k]:<8} (paper {EXPECT[k]}) {mark}")
    print(f"  severity dist = {dict(sev)}")

    ok = all(got[k] == EXPECT[k] for k in EXPECT)
    print("CHECK OK" if ok else "MISMATCH")
    if a.check and not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
