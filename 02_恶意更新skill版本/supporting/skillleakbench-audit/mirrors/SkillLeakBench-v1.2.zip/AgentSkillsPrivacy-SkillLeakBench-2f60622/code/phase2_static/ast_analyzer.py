#!/usr/bin/env python3
"""AST-based credential sink detection (paper Section 3.2).

Uses tree-sitter to parse Python/JavaScript, then, for each credential reference,
(1) resolves the enclosing function scope and (2) checks whether the reference
flows as an argument into a sensitive sink (network / logging / file I/O). A credential is
flagged when the credential *literal* or a credential-named *identifier* appears inside a
sink call's arguments.

Complements the regex scanner (credential *presence*) by detecting credential
*flow* into a sink.

CLI:  python3 ast_analyzer.py <file.py|file.js>
"""
import argparse
import re
import sys
from pathlib import Path

from tree_sitter import Language, Parser
import tree_sitter_python
import tree_sitter_javascript

_LANG = {
    "python": Language(tree_sitter_python.language()),
    "javascript": Language(tree_sitter_javascript.language()),
}
_EXT = {".py": "python", ".js": "javascript", ".jsx": "javascript",
        ".ts": "javascript", ".mjs": "javascript", ".cjs": "javascript"}

# Sink callees -> class. Bare names match exactly; dotted suffixes match the tail.
_SINK_BARE = {"print": "log", "fetch": "network", "open": "file"}
_SINK_SUFFIX = {
    ".post": "network", ".get": "network", ".put": "network", ".patch": "network",
    ".request": "network", ".urlopen": "network", ".send": "network", ".sendall": "network",
    ".log": "log", ".error": "log", ".warn": "log", ".warning": "log", ".info": "log", ".debug": "log",
    ".write": "file", ".writefile": "file", ".writefilesync": "file", ".appendfile": "file", ".dump": "file",
}
_CRED_VALUE = re.compile(
    r"(sk-[A-Za-z0-9_\-]{8,}|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|gsk_[A-Za-z0-9]{8,}"
    r"|xox[baprs]-[A-Za-z0-9\-]{8,}|-----BEGIN [A-Z ]*PRIVATE KEY|eyJ[A-Za-z0-9_\-]{10,}\.)"
)
_CRED_NAME = re.compile(
    r"(api[_-]?key|access[_-]?key|secret[_-]?key|private[_-]?key|client[_-]?secret"
    r"|refresh[_-]?token|access[_-]?token|auth[_-]?token|\btoken\b|\bsecret\b|password|passwd|credential)",
    re.I,
)
_FUNC_TYPES = {"function_definition", "function_declaration", "method_definition",
               "arrow_function", "function", "function_expression"}


def _txt(node):
    return node.text.decode("utf-8", "replace")


def _sink_class(callee: str):
    c = callee.lower()
    if c in _SINK_BARE:
        return _SINK_BARE[c]
    for suf, cls in _SINK_SUFFIX.items():
        if c.endswith(suf):
            return cls
    return None


def _enclosing_function(node):
    p = node.parent
    while p is not None:
        if p.type in _FUNC_TYPES:
            name = p.child_by_field_name("name")
            return _txt(name) if name else "<anonymous>"
        p = p.parent
    return "<module>"


def _is_credentialish(node):
    t = node.type
    if t == "string" or t == "string_fragment" or t.endswith("string"):
        return bool(_CRED_VALUE.search(_txt(node)))
    if t in ("identifier", "property_identifier", "shorthand_property_identifier"):
        return bool(_CRED_NAME.search(_txt(node)))
    return False


def _call_nodes(root):
    stack = [root]
    while stack:
        n = stack.pop()
        if n.type in ("call", "call_expression"):
            yield n
        stack.extend(n.children)


def _descendants(node):
    stack = list(node.children)
    while stack:
        n = stack.pop()
        yield n
        stack.extend(n.children)


def analyze(code: str, lang: str):
    """Return findings: list of dicts {credential, sink, sink_class, function, line}."""
    if lang not in _LANG:
        return []
    parser = Parser(_LANG[lang])
    tree = parser.parse(code.encode("utf-8", "replace"))
    findings = []
    for call in _call_nodes(tree.root_node):
        callee = call.child_by_field_name("function")
        if callee is None:
            continue
        callee_txt = _txt(callee)
        # Skip parse-error callees (tree-sitter on TS-as-JS) so the sink stays a concise callee.
        if getattr(callee, "has_error", False):
            continue
        sink_class = _sink_class(callee_txt)
        if not sink_class:
            continue
        args = call.child_by_field_name("arguments")
        if args is None:
            continue
        for d in _descendants(args):
            if _is_credentialish(d):
                findings.append({
                    "credential": _txt(d)[:60],
                    "sink": re.sub(r"\s+", "", callee_txt)[:64],
                    "sink_class": sink_class,
                    "function": _enclosing_function(d),
                    "line": d.start_point[0] + 1,
                })
                break  # one finding per sink call is enough
    # network > log > file
    rank = {"network": 0, "log": 1, "file": 2}
    findings.sort(key=lambda f: rank.get(f["sink_class"], 9))
    return findings


def analyze_file(path: str):
    p = Path(path)
    lang = _EXT.get(p.suffix.lower())
    if not lang:
        return []
    return analyze(p.read_text(encoding="utf-8", errors="replace"), lang)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("path", help="source file (.py/.js) to analyze")
    a = ap.parse_args()
    fs = analyze_file(a.path)
    for f in fs:
        print(f"{a.path}:{f['line']}  [{f['sink_class']}] {f['credential']} -> {f['sink']}  (fn {f['function']})")
    print(f"{len(fs)} credential->sink flow(s)")
    sys.exit(0)


if __name__ == "__main__":
    main()
