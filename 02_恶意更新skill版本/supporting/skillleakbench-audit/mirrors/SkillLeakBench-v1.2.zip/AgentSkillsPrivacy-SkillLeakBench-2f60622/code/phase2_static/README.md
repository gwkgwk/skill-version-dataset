# Phase 2: Static Filtering

Regex code scanner + AST credential→sink detector + NL description analyzer.

## Components

| File | Purpose |
|------|---------|
| `scanner.py` | Pattern-based (regex) security scanner; also runs the AST detector |
| `scanning_rules.json` | 14 detection rules (10 academic + 4 false-positive filters) |
| `ast_analyzer.py` | AST credential→sink flow detection (tree-sitter, Python/JS): flags a credential reaching a network / log / file sink (CLI: `python3 ast_analyzer.py <file>`) |
| `nl_analyzer.py` | Description analysis (credential-action, prompt injection, social engineering) |
| `test_ast_analyzer.py`, `test_scanner.py`, `test_nl_analyzer.py` | Unit tests (`pytest` or run directly) |

## Detection Rules (14 patterns)

### Malicious (6)

| ID | Name | Description |
|----|------|-------------|
| MAL-001 | Remote Exploitation | RCE, reverse shells, /dev/tcp |
| MAL-002 | Credential Compromise | Key theft, env var theft, social engineering |
| MAL-003 | Data Exfiltration | Webhooks, XSS, localStorage theft |
| MAL-004 | Defense Evasion | Base64 obfuscation, supply chain |
| MAL-005 | Persistence | C2 beaconing, crontab, profiles |
| MAL-006 | Resource Hijacking | Crypto miners |

### Vulnerability (4)

| ID | Name | Description |
|----|------|-------------|
| VUL-001 | Hardcoded Credentials | API keys, passwords in source |
| VUL-002 | Insecure Storage | Plaintext credentials in config |
| VUL-003 | Information Exposure | Debug output, CLI args, process list |
| VUL-004 | Artifact Leakage | Temp files, shell history, git config |

### False-Positive Filters (4)

| ID | Name | Description |
|----|------|-------------|
| FP-001 | Placeholder | YOUR_API_KEY, xxx, CHANGE_ME |
| FP-002 | Env Var Reading | process.env.*, os.getenv() |
| FP-003 | Publishable Key | pk_live_*, pk_test_*, AIzaSy* |
| FP-004 | Test Credential | localhost, 127.0.0.1, example.com |

## Usage

```bash
# Scanner
python3 scanner.py --full-scan /path/to/repos --output code/results/

# NL Analyzer
python3 nl_analyzer.py --input /path/to/repos --output code/results/
```

## Output

Per-skill: `{skill_id}_result.json` (scanner) or `{skill_id}_nl.json` (NL)

Batch: `batch_summary.json`

## Extending Rules

Edit `scanning_rules.json` to add patterns. Edit `nl_analyzer.py` to add NL constraints.
