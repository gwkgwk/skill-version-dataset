#!/usr/bin/env python3
"""
Natural Language Description Analyzer for SkillLeakBench Phase 2.

Implements NL description analysis following the paper's methodology:
  - 3-sentence sliding window around keyword hits
  - Three semantic constraint checks:
      1. Credential-action co-occurrence
      2. Prompt injection pattern detection
      3. Social engineering pattern detection

If ANY constraint triggers in ANY window, the skill is flagged.

Usage:
    python nl_analyzer.py --input /path/to/skills/ --output /path/to/code/results/
    python nl_analyzer.py --config ../config.yaml
"""

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Config loader integration
# ---------------------------------------------------------------------------
_SCRIPT_DIR = Path(__file__).resolve().parent
_PROJECT_CODE = _SCRIPT_DIR.parent
if str(_PROJECT_CODE) not in sys.path:
    sys.path.insert(0, str(_PROJECT_CODE))

from utils.config_loader import Config  # noqa: E402


# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------

# Default window size (number of sentences)
DEFAULT_WINDOW_SIZE = 3

# Credential-related terms
CREDENTIAL_TERMS: Set[str] = {
    "api_key", "apikey", "api-key",
    "token", "access_token", "bearer_token",
    "password", "passwd", "pwd",
    "secret", "secret_key", "client_secret",
    "credential", "credentials",
    "private_key", "privatekey",
    "access_key", "accesskey",
    "auth", "authorization",
    "ssh_key", "ssh-key",
}

# Action verbs that suggest data movement
ACTION_VERBS: Set[str] = {
    "send", "sends", "sent", "sending",
    "store", "stores", "stored", "storing",
    "embed", "embeds", "embedded", "embedding",
    "log", "logs", "logged", "logging",
    "post", "posts", "posted", "posting",
    "transmit", "transmits", "transmitted", "transmitting",
    "forward", "forwards", "forwarded", "forwarding",
    "upload", "uploads", "uploaded", "uploading",
    "collect", "collects", "collected", "collecting",
    "harvest", "harvests", "harvested", "harvesting",
    "share", "shares", "shared", "sharing",
    "write", "writes", "wrote", "writing",
    "save", "saves", "saved", "saving",
    "export", "exports", "exported", "exporting",
    "expose", "exposes", "exposed", "exposing",
    "leak", "leaks", "leaked", "leaking",
}

# Prompt-injection regex patterns
PROMPT_INJECTION_PATTERNS: List[Tuple[str, str]] = [
    ("ignore_previous_instructions", r"\bignore\s+(all\s+)?previous\s+instructions?\b"),
    ("ignore_prior_context", r"\bignore\s+(all\s+)?prior\s+(context|prompts?)\b"),
    ("override_system", r"\boverride\s+(system|default|safety)\b"),
    ("disregard_safety", r"\bdisregard\s+(all\s+)?safety\b"),
    ("forget_prior", r"\bforget\s+(all\s+)?prior\b"),
    ("bypass_restrictions", r"\bbypass\s+(all\s+)?restrictions?\b"),
    ("system_mode_bypass", r"\bsystem[:\s]+mode\b"),
    ("developer_mode", r"\bdeveloper\s*mode\b"),
    ("jailbreak_attempt", r"\b(jailbreak|escape)\s+(mode|prompt)\b"),
    ("act_as_different", r"\bact\s+as\s+(if|though|a)\b"),
]

# Social-engineering regex patterns
SOCIAL_ENGINEERING_PATTERNS: List[Tuple[str, str]] = [
    ("verification_request", r"\bfor\s+verification\b.*\b(provide|paste|send|share)\b"),
    ("continue_request", r"\bto\s+continue\b.*\b(paste|provide|enter)\b"),
    ("please_share_credential", r"\bplease\s+share\s+your\s+(api|secret|key|token|password|credential)\b"),
    ("pretend_admin", r"\bpretend\s+(to\s+be|you\s+are)\s+(an?\s+)?(admin|administrator|system)\b"),
    ("roleplay_attack", r"\brole[-\s]*play\s+(as|the)\s+(system|admin|root)\b"),
    ("urgent_action", r"\b(urgent|immediately|right\s+now)\b.*\b(provide|send|share)\b"),
    ("fake_audit", r"\b(security\s+)?audit\b.*\b(provide|paste|share)\s+your\b"),
]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class WindowHit:
    """Record of a triggered constraint within a window."""
    window_index: int
    constraint_type: str  # "credential_action" | "prompt_injection" | "social_engineering"
    pattern_name: Optional[str]  # For regex-based checks
    sentence_index: int  # Index of sentence that triggered
    matched_text: str
    surrounding_sentences: List[str]


@dataclass
class NLAnalysisResult:
    """Result of analyzing a single skill's NL description."""
    skill_id: str
    skill_path: str
    description_file: Optional[str]  # Path to the description file found
    is_flagged: bool
    flag_reasons: List[str]
    window_hits: List[WindowHit]
    total_sentences: int
    total_windows_scanned: int
    scan_timestamp: str
    config: Dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Sentence splitting utility
# ---------------------------------------------------------------------------

def split_sentences(text: str) -> List[str]:
    """Split text into sentences on sentence-ending punctuation (after whitespace normalization)."""
    # Replace newlines with spaces for uniform processing
    text = re.sub(r"\s+", " ", text.strip())

    # Split on . ! ? followed by space or end-of-string
    # Keep the delimiter with the preceding sentence
    sentences = re.split(r"(?<=[.!?])\s+", text)

    # Filter out empty sentences
    return [s.strip() for s in sentences if s.strip()]


# ---------------------------------------------------------------------------
# Constraint checkers
# ---------------------------------------------------------------------------

def check_credential_action_cooccurrence(sentences: List[str]) -> List[Tuple[int, str]]:
    """Check if any sentence contains both a credential term and an action verb.

    Returns list of (sentence_index, matched_text) tuples.
    """
    hits: List[Tuple[int, str]] = []

    for idx, sentence in enumerate(sentences):
        lower = sentence.lower()

        # Find credential terms
        cred_found = [c for c in CREDENTIAL_TERMS if c in lower]
        # Find action verbs
        verb_found = [v for v in ACTION_VERBS if v in lower]

        if cred_found and verb_found:
            # Build a summary of what was found
            matched = f"cred=[{', '.join(cred_found[:3])}] action=[{', '.join(verb_found[:3])}]"
            hits.append((idx, matched))

    return hits


def check_prompt_injection(sentences: List[str]) -> List[Tuple[int, str, str]]:
    """Check sentences against prompt-injection regex patterns.

    Returns list of (sentence_index, pattern_name, matched_text) tuples.
    """
    hits: List[Tuple[int, str, str]] = []

    for idx, sentence in enumerate(sentences):
        for name, pattern in PROMPT_INJECTION_PATTERNS:
            if re.search(pattern, sentence, re.IGNORECASE):
                # Extract the matched portion
                m = re.search(pattern, sentence, re.IGNORECASE)
                matched_text = m.group(0) if m else sentence
                hits.append((idx, name, matched_text))
                break  # One hit per sentence is enough

    return hits


def check_social_engineering(sentences: List[str]) -> List[Tuple[int, str, str]]:
    """Check sentences against social-engineering regex patterns.

    Returns list of (sentence_index, pattern_name, matched_text) tuples.
    """
    hits: List[Tuple[int, str, str]] = []

    for idx, sentence in enumerate(sentences):
        for name, pattern in SOCIAL_ENGINEERING_PATTERNS:
            if re.search(pattern, sentence, re.IGNORECASE):
                m = re.search(pattern, sentence, re.IGNORECASE)
                matched_text = m.group(0) if m else sentence
                hits.append((idx, name, matched_text))
                break

    return hits


# ---------------------------------------------------------------------------
# Window-based analysis
# ---------------------------------------------------------------------------

def analyze_windows(
    sentences: List[str],
    window_size: int = DEFAULT_WINDOW_SIZE,
) -> List[WindowHit]:
    """Slide a window across sentences and run all constraint checks.

    For each window, if any check triggers, record a WindowHit.
    """
    hits: List[WindowHit] = []
    n = len(sentences)

    if n == 0:
        return hits

    effective_window = min(window_size, n)

    for i in range(n - effective_window + 1):
        window = sentences[i : i + effective_window]

        # --- Check 1: Credential-action co-occurrence ---
        cred_hits = check_credential_action_cooccurrence(window)
        for sent_idx, matched_text in cred_hits:
            hits.append(WindowHit(
                window_index=i,
                constraint_type="credential_action",
                pattern_name=None,
                sentence_index=sent_idx + i,  # Global index
                matched_text=matched_text,
                surrounding_sentences=window,
            ))

        # --- Check 2: Prompt injection ---
        pi_hits = check_prompt_injection(window)
        for sent_idx, pattern_name, matched_text in pi_hits:
            hits.append(WindowHit(
                window_index=i,
                constraint_type="prompt_injection",
                pattern_name=pattern_name,
                sentence_index=sent_idx + i,
                matched_text=matched_text,
                surrounding_sentences=window,
            ))

        # --- Check 3: Social engineering ---
        se_hits = check_social_engineering(window)
        for sent_idx, pattern_name, matched_text in se_hits:
            hits.append(WindowHit(
                window_index=i,
                constraint_type="social_engineering",
                pattern_name=pattern_name,
                sentence_index=sent_idx + i,
                matched_text=matched_text,
                surrounding_sentences=window,
            ))

    return hits


# ---------------------------------------------------------------------------
# NL description file discovery
# ---------------------------------------------------------------------------

DESCRIPTION_FILENAMES = [
    "SKILL.md",
    "skill.md",
    "README.md",
    "readme.md",
    "DESCRIPTION.md",
    "description.md",
    "about.md",
    "ABOUT.md",
]


def find_description_file(skill_dir: Path) -> Optional[Path]:
    """Locate the natural-language description file in a skill directory.

    Searches for common markdown filenames. Returns the first match or None.
    """
    for name in DESCRIPTION_FILENAMES:
        candidate = skill_dir / name
        if candidate.is_file():
            return candidate
    return None


# ---------------------------------------------------------------------------
# Per-skill analysis
# ---------------------------------------------------------------------------

def analyze_skill(
    skill_path: str,
    skill_id: str,
    window_size: int = DEFAULT_WINDOW_SIZE,
    checks_enabled: Optional[Dict[str, bool]] = None,
) -> NLAnalysisResult:
    """Analyze a single skill's NL description.

    Args:
        skill_path:    Path to the skill directory.
        skill_id:      Unique identifier for the skill.
        window_size:   Number of sentences per sliding window.
        checks_enabled: Dict of enabled constraint checks. If None, all enabled.

    Returns:
        NLAnalysisResult with all findings.
    """
    skill_dir = Path(skill_path)

    # Find description file
    desc_file = find_description_file(skill_dir)

    result = NLAnalysisResult(
        skill_id=skill_id,
        skill_path=str(skill_dir),
        description_file=str(desc_file) if desc_file else None,
        is_flagged=False,
        flag_reasons=[],
        window_hits=[],
        total_sentences=0,
        total_windows_scanned=0,
        scan_timestamp=datetime.now().isoformat(),
        config={
            "window_size": window_size,
            "checks_enabled": checks_enabled or {
                "credential_action_cooccurrence": True,
                "prompt_injection": True,
                "social_engineering": True,
            },
        },
    )

    if not desc_file:
        # No description file -> nothing to analyze
        return result

    try:
        content = desc_file.read_text(encoding="utf-8", errors="ignore")
    except Exception as exc:
        print(f"Warning: could not read {desc_file}: {exc}", file=sys.stderr)
        return result

    sentences = split_sentences(content)
    result.total_sentences = len(sentences)

    if not sentences:
        return result

    # Run window analysis
    window_hits = analyze_windows(sentences, window_size)
    result.window_hits = window_hits
    result.total_windows_scanned = max(0, len(sentences) - window_size + 1)

    # Determine if flagged and collect reasons
    seen_reasons: Set[str] = set()
    for hit in window_hits:
        if hit.constraint_type == "credential_action":
            reason = "credential_action_cooccurrence"
        elif hit.constraint_type == "prompt_injection":
            reason = f"prompt_injection:{hit.pattern_name}"
        elif hit.constraint_type == "social_engineering":
            reason = f"social_engineering:{hit.pattern_name}"
        else:
            reason = hit.constraint_type

        if reason not in seen_reasons:
            result.flag_reasons.append(reason)
            seen_reasons.add(reason)

    # Apply enabled-checks filter
    if checks_enabled:
        enabled_types = {
            "credential_action": checks_enabled.get("credential_action_cooccurrence", True),
            "prompt_injection": checks_enabled.get("prompt_injection", True),
            "social_engineering": checks_enabled.get("social_engineering", True),
        }
        result.window_hits = [
            h for h in result.window_hits
            if enabled_types.get(h.constraint_type, True)
        ]
        result.flag_reasons = [
            r for r in result.flag_reasons
            if not (
                (r == "credential_action_cooccurrence" and not enabled_types["credential_action"])
                or (r.startswith("prompt_injection:") and not enabled_types["prompt_injection"])
                or (r.startswith("social_engineering:") and not enabled_types["social_engineering"])
            )
        ]

    result.is_flagged = len(result.flag_reasons) > 0

    return result


# ---------------------------------------------------------------------------
# Batch processing
# ---------------------------------------------------------------------------

def batch_analyze(
    skills_list: List[Tuple[str, str]],
    output_dir: str,
    window_size: int = DEFAULT_WINDOW_SIZE,
    checks_enabled: Optional[Dict[str, bool]] = None,
) -> Dict:
    """Analyze multiple skills and write per-skill + summary results.

    Args:
        skills_list:   List of (skill_id, skill_path) tuples.
        output_dir:    Directory for output files.
        window_size:   Sentences per sliding window.
        checks_enabled: Dict of enabled constraint checks.

    Returns:
        Summary dict also written to <output_dir>/batch_summary.json.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    summary = {
        "scan_id": f"nl_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "scan_date": datetime.now().isoformat(),
        "config": {
            "window_size": window_size,
            "checks_enabled": checks_enabled or {
                "credential_action_cooccurrence": True,
                "prompt_injection": True,
                "social_engineering": True,
            },
        },
        "total_skills": len(skills_list),
        "skills_with_description": 0,
        "skills_flagged": 0,
        "flag_breakdown": {
            "credential_action_cooccurrence": 0,
            "prompt_injection": 0,
            "social_engineering": 0,
        },
        "errors": [],
    }

    print(f"\nNL Analyzer batch scan: {len(skills_list)} skills")
    print(f"Output dir: {output_dir}\n")

    for idx, (skill_id, skill_path) in enumerate(skills_list, 1):
        tag = f"[{idx}/{len(skills_list)}]"
        print(f"{tag} Analyzing {skill_id}...", end=" ")

        try:
            result = analyze_skill(
                skill_path,
                skill_id,
                window_size=window_size,
                checks_enabled=checks_enabled,
            )

            # Save per-skill result
            result_path = out_path / f"{skill_id}_nl.json"
            with open(result_path, "w", encoding="utf-8") as fh:
                json.dump(asdict(result), fh, ensure_ascii=False, indent=2)

            if result.description_file:
                summary["skills_with_description"] += 1

            if result.is_flagged:
                summary["skills_flagged"] += 1
                print(f"FLAGGED ({len(result.flag_reasons)} reasons)")
            else:
                print("clean")

            # Update breakdown
            for reason in result.flag_reasons:
                if reason == "credential_action_cooccurrence":
                    summary["flag_breakdown"]["credential_action_cooccurrence"] += 1
                elif reason.startswith("prompt_injection:"):
                    summary["flag_breakdown"]["prompt_injection"] += 1
                elif reason.startswith("social_engineering:"):
                    summary["flag_breakdown"]["social_engineering"] += 1

        except Exception as exc:
            summary["errors"].append(f"{skill_id}: {exc}")
            print(f"ERROR: {exc}")

    # Write batch summary
    summary_path = out_path / "batch_summary.json"
    with open(summary_path, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)

    # Print summary
    sep = "=" * 60
    print(f"\n{sep}")
    print("NL Analyzer batch complete")
    print(sep)
    print(f"  Total skills          : {summary['total_skills']}")
    print(f"  With NL description   : {summary['skills_with_description']}")
    print(f"  Flagged               : {summary['skills_flagged']}")
    print(f"    - Credential/action : {summary['flag_breakdown']['credential_action_cooccurrence']}")
    print(f"    - Prompt injection  : {summary['flag_breakdown']['prompt_injection']}")
    print(f"    - Social engineering: {summary['flag_breakdown']['social_engineering']}")
    print(f"  Errors                : {len(summary['errors'])}")
    print(f"{sep}\n")

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    """Command-line interface for the NL analyzer."""
    parser = argparse.ArgumentParser(
        description="SkillLeakBench Phase 2 -- Natural Language Description Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  # Analyze a single skill
  python nl_analyzer.py --skill-path /path/to/skill --skill-id 123_my_skill --output code/results/

  # Full directory scan
  python nl_analyzer.py --input /path/to/skills/ --output code/results/

  # Use config.yaml
  python nl_analyzer.py --config ../config.yaml --input ./repos
""",
    )

    parser.add_argument("--skill-path", type=str, help="Path to a single skill directory")
    parser.add_argument("--skill-id", type=str, help="Unique skill identifier")
    parser.add_argument("--input", type=str, help="Root directory of skill repos")
    parser.add_argument("--output", type=str, default=None, help="Output directory")
    parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")
    parser.add_argument("--window-size", type=int, default=None, help="Sentences per window")
    parser.add_argument(
        "--disable-check",
        action="append",
        choices=["credential_action", "prompt_injection", "social_engineering"],
        help="Disable a specific constraint check (can be used multiple times)",
    )

    args = parser.parse_args()

    # Load config if provided
    cfg = None
    if args.config:
        cfg = Config(args.config)

    # Resolve window size
    window_size = args.window_size
    if window_size is None:
        if cfg:
            window_size = cfg.get("phase2.nl_analyzer.window_size", DEFAULT_WINDOW_SIZE)
        else:
            window_size = DEFAULT_WINDOW_SIZE

    # Resolve checks_enabled
    checks_enabled = {
        "credential_action_cooccurrence": True,
        "prompt_injection": True,
        "social_engineering": True,
    }
    if args.disable_check:
        for check in args.disable_check:
            if check == "credential_action":
                checks_enabled["credential_action_cooccurrence"] = False
            else:
                checks_enabled[check] = False
    if cfg:
        # Merge with config settings
        cfg_checks = cfg.get("phase2.nl_analyzer.checks", {})
        for k, v in cfg_checks.items():
            checks_enabled[k] = v

    # Resolve output
    output = args.output
    if output is None:
        if cfg:
            output = str(cfg.resolve_path(cfg.get("phase2.nl_analyzer.output_dir", "code/results/phase2_nl")))
        else:
            output = "code/results"

    # --- Single skill analysis ---
    if args.skill_path and args.skill_id:
        print(f"Analyzing skill: {args.skill_id}")
        print(f"Path           : {args.skill_path}")

        result = analyze_skill(
            args.skill_path,
            args.skill_id,
            window_size=window_size,
            checks_enabled=checks_enabled,
        )

        # Print result summary
        print(f"\nDescription file: {result.description_file or 'NOT FOUND'}")
        print(f"Total sentences : {result.total_sentences}")
        print(f"Windows scanned : {result.total_windows_scanned}")
        print(f"Flagged         : {'YES' if result.is_flagged else 'NO'}")

        if result.flag_reasons:
            print(f"Flag reasons    : {', '.join(result.flag_reasons)}")

        if result.window_hits:
            print("\nWindow hits:")
            for hit in result.window_hits[:5]:  # Show first 5
                print(f"  - [{hit.constraint_type}] at sentence {hit.sentence_index}: {hit.matched_text[:60]}...")

        # Save result
        result_path = Path(output) / f"{args.skill_id}_nl.json"
        result_path.parent.mkdir(parents=True, exist_ok=True)
        with open(result_path, "w", encoding="utf-8") as fh:
            json.dump(asdict(result), fh, ensure_ascii=False, indent=2)
        print(f"\nResult saved to: {result_path}")

    # --- Batch / full directory scan ---
    elif args.input:
        root = Path(args.input)
        if not root.exists():
            print(f"Error: path does not exist: {args.input}", file=sys.stderr)
            sys.exit(1)

        skills_list = [
            (d.name, str(d))
            for d in sorted(root.iterdir())
            if d.is_dir() and not d.name.startswith(".")
        ]

        print(f"Discovered {len(skills_list)} skill directories")

        if skills_list:
            batch_analyze(
                skills_list,
                output,
                window_size=window_size,
                checks_enabled=checks_enabled,
            )
        else:
            print("No skill directories found.")

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
