#!/usr/bin/env python3
"""
GitHub Skills Security Scanner -- Phase 2 Static Filtering for SkillLeakBench.

Automated scanner with 10 academic classifications across three categories:
  - Malware detection (6 patterns: Remote Exploitation, Credential Compromise,
    Data Exfiltration, Defense Evasion, Persistence, Resource Hijacking)
  - Vulnerability detection (4 patterns: Hardcoded Credentials, Insecure Storage,
    Information Exposure, Artifact Leakage)
  - False-positive filtering (4 patterns)

Three-phase scan pipeline per skill:
  Phase A -- Malicious pattern matching
  Phase B -- Vulnerability pattern matching
  Phase C -- False-positive filter applied to Phase B results

Usage:
    python scanner.py --skill-path /path/to/skill --skill-id 123_skill_name
    python scanner.py --batch-file skills_list.json --output code/results/
    python scanner.py --full-scan /path/to/skills/root --output code/results/
    python scanner.py --config ../config.yaml
"""

import json
import re
import os
import sys
import argparse
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass, asdict
from datetime import datetime

# ---------------------------------------------------------------------------
# Config loader integration
# ---------------------------------------------------------------------------
# Allow importing config_loader from code/utils/ regardless of cwd.
_SCRIPT_DIR = Path(__file__).resolve().parent
_PROJECT_CODE = _SCRIPT_DIR.parent
if str(_PROJECT_CODE) not in sys.path:
    sys.path.insert(0, str(_PROJECT_CODE))

from utils.config_loader import Config  # noqa: E402


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------
@dataclass
class ScanResult:
    """Result of scanning a single skill."""
    skill_id: str
    skill_path: str
    is_malicious: bool
    malicious_patterns: List[Dict[str, Any]]
    vulnerabilities: List[Dict[str, Any]]
    false_positives: List[Dict[str, Any]]
    scan_timestamp: str
    confidence_score: float
    ast_flows: List[Dict[str, Any]] = None


@dataclass
class PatternMatch:
    """Single pattern-match record."""
    pattern_id: str
    pattern_name: str
    severity: str
    category: str
    matches: List[str]
    files_affected: List[str]
    evidence: str
    confidence: float


# ---------------------------------------------------------------------------
# SecurityScanner
# ---------------------------------------------------------------------------
class SecurityScanner:
    """Regex-based security scanner for GitHub Skills.

    Loads rules from a JSON file and runs a three-phase scan:
      1. Malicious pattern detection
      2. Vulnerability pattern detection
      3. False-positive filtering on vulnerability hits
    """

    # File extensions considered scannable.
    CODE_EXTENSIONS = {
        ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs",
        ".sh", ".bash", ".zsh", ".env", ".json", ".yaml", ".yml",
        ".html", ".svg", ".css",
    }

    # Directories always excluded from scanning.
    EXCLUDED_DIRS = {"node_modules", ".git", "__pycache__"}

    # Markdown code block language to file extension mapping.
    MARKDOWN_CODE_LANGUAGES = {
        "python": ".py",
        "py": ".py",
        "bash": ".sh",
        "shell": ".sh",
        "sh": ".sh",
        "zsh": ".zsh",
        "javascript": ".js",
        "js": ".js",
        "typescript": ".ts",
        "ts": ".ts",
        "go": ".go",
        "ruby": ".rb",
        "rust": ".rs",
        "json": ".json",
        "yaml": ".yaml",
        "yml": ".yml",
        "html": ".html",
        "css": ".css",
        "env": ".env",
    }

    def __init__(self, rules_file: str = "scanning_rules.json"):
        """Initialise scanner from a rules JSON file.

        Args:
            rules_file: Path to the scanning_rules.json file.
        """
        self.rules = self._load_rules(rules_file)
        self.malicious_rules = self.rules["rules"]["malicious"]
        self.vulnerable_rules = self.rules["rules"]["vulnerable"]
        self.false_positive_rules = self.rules["rules"]["false_positive"]
        self.ioc_database = self.rules.get("ioc_database", {})

    # -- rule loading -------------------------------------------------------

    @staticmethod
    def _load_rules(rules_file: str) -> Dict:
        """Load scanning rules from a JSON file."""
        try:
            with open(rules_file, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            print(f"Error: rules file not found: {rules_file}", file=sys.stderr)
            sys.exit(1)
        except json.JSONDecodeError as exc:
            print(f"Error: invalid JSON in rules file: {exc}", file=sys.stderr)
            sys.exit(1)

    # -- top-level scan -----------------------------------------------------

    def scan_skill(self, skill_path: str, skill_id: str) -> ScanResult:
        """Scan a single skill directory.

        Args:
            skill_path: Path to the skill's root directory.
            skill_id:   Unique identifier for the skill.

        Returns:
            A ScanResult dataclass instance.
        """
        skill_path = Path(skill_path)
        if not skill_path.exists():
            raise FileNotFoundError(f"Skill path does not exist: {skill_path}")

        code_files = self._collect_code_files(skill_path)

        result = ScanResult(
            skill_id=skill_id,
            skill_path=str(skill_path),
            is_malicious=False,
            malicious_patterns=[],
            vulnerabilities=[],
            false_positives=[],
            scan_timestamp=datetime.now().isoformat(),
            confidence_score=0.0,
        )

        # Phase A: Malware detection
        malicious_matches = self._scan_malicious(code_files, skill_path)
        result.malicious_patterns = malicious_matches
        if malicious_matches:
            result.is_malicious = True

        # Phase B: Vulnerability detection
        vulnerability_matches = self._scan_vulnerabilities(code_files, skill_path)
        result.vulnerabilities = vulnerability_matches

        # Phase B.5: AST credential -> sink flow detection (Section 3.2)
        result.ast_flows = self._scan_ast_flows(code_files, skill_path)

        # Phase C: False-positive filtering
        result = self._filter_false_positives(result, code_files)

        # Compute overall confidence
        result.confidence_score = self._calculate_confidence(result)

        return result

    # -- phase 3.2: AST source->sink flow -----------------------------------
    def _scan_ast_flows(self, code_files, skill_path: Path) -> List[Dict]:
        """Detect credential->sink data flows via AST (Python/JS), Section 3.2."""
        import os as _os, sys as _sys
        _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
        try:
            from ast_analyzer import analyze_file
        except Exception:
            return []
        exts = {".py", ".js", ".jsx", ".ts", ".mjs", ".cjs"}
        flows: List[Dict] = []
        for fp, md in code_files:
            if md is not None or fp.suffix.lower() not in exts:
                continue
            try:
                for fl in analyze_file(str(fp)):
                    fl["file_path"] = str(fp.relative_to(skill_path))
                    flows.append(fl)
            except Exception:
                continue
        return flows

    # -- file collection ----------------------------------------------------

    def _collect_code_files(self, skill_path: Path) -> List[Tuple[Path, Optional[str]]]:
        """Recursively collect scannable source files, skipping excluded dirs.

        Returns:
            List of (file_path, markdown_content) tuples.
            markdown_content is None for regular code files,
            or the full file content string for .md files (to be parsed for code blocks).
        """
        files: List[Tuple[Path, Optional[str]]] = []
        max_bytes, max_files, seen = 1_000_000, 1500, 0  # bound scan cost on pathologically large repos
        for fp in skill_path.rglob("*"):
            seen += 1
            if len(files) >= max_files or seen > 20000:
                break
            if not fp.is_file():
                continue
            if any(ex in str(fp) for ex in self.EXCLUDED_DIRS):
                continue
            try:
                if fp.stat().st_size > max_bytes:
                    continue
            except OSError:
                continue

            # Handle Markdown files - pass content for code block extraction
            if fp.suffix == ".md":
                try:
                    content = fp.read_text(encoding="utf-8", errors="ignore")
                    files.append((fp, content))
                except Exception:
                    pass
            # Handle regular code files
            elif fp.suffix in self.CODE_EXTENSIONS:
                files.append((fp, None))

        return files

    def _extract_code_blocks_from_markdown(
        self, content: str
    ) -> List[Tuple[str, str, str]]:
        """Extract code blocks from Markdown content.

        Args:
            content: The markdown file content.

        Returns:
            List of (code_content, language, virtual_extension) tuples.
        """
        code_blocks: List[Tuple[str, str, str]] = []

        # Match ```language ... ``` format (non-greedy)
        pattern = r"```(\w*)\s*\n(.*?)```"

        for match in re.finditer(pattern, content, re.DOTALL):
            language = match.group(1).lower()
            code = match.group(2)

            if language and code.strip():
                virtual_ext = self.MARKDOWN_CODE_LANGUAGES.get(language, "")
                code_blocks.append((code, language, virtual_ext))

        return code_blocks

    # -- phase A: malware ---------------------------------------------------

    def _scan_malicious(
        self, code_files: List[Tuple[Path, Optional[str]]], skill_path: Path
    ) -> List[Dict]:
        """Run every malicious rule against every code file."""
        matches: List[Dict] = []
        for rule in self.malicious_rules:
            hits = self._match_patterns(rule, code_files, skill_path)
            matches.extend(hits)
        return matches

    # -- phase B: vulnerabilities -------------------------------------------

    def _scan_vulnerabilities(
        self, code_files: List[Tuple[Path, Optional[str]]], skill_path: Path
    ) -> List[Dict]:
        """Run every vulnerability rule against every code file."""
        matches: List[Dict] = []
        for rule in self.vulnerable_rules:
            hits = self._match_patterns(rule, code_files, skill_path)
            matches.extend(hits)
        return matches

    # -- core pattern matching ----------------------------------------------

    def _match_patterns(
        self,
        rule: Dict,
        code_files: List[Tuple[Path, Optional[str]]],
        skill_path: Path,
    ) -> List[Dict]:
        """Apply a single rule's regex patterns across all code files.

        Args:
            rule: The scanning rule to apply.
            code_files: List of (file_path, markdown_content) tuples.
            skill_path: Root path of the skill.

        Returns:
            List of hit dicts (one per file/code block that matched).
        """
        regex_patterns = rule.get("regex_patterns", [])
        file_types = rule.get("file_types", ["*"])
        exclusion_patterns = rule.get("exclusion_patterns", [])

        # Pre-compile regexes
        compiled: List[re.Pattern] = []
        for pat in regex_patterns:
            try:
                compiled.append(re.compile(pat, re.IGNORECASE | re.MULTILINE))
            except re.error as exc:
                print(
                    f"Warning: regex compilation failed for {pat}: {exc}",
                    file=sys.stderr,
                )

        matches: List[Dict] = []

        # Split exclusions: '/'-suffixed entries are path-DIR exclusions matched on
        # path components relative to the skill (so '/tmp/leaktest' cannot match 'test');
        # the rest are content placeholders that filter individual match values.
        dir_excls = {e.rstrip("/").lower() for e in exclusion_patterns if e.endswith("/")}
        content_excls = [e.lower() for e in exclusion_patterns if not e.endswith("/")]

        def _excluded_value(m) -> bool:
            s = (" ".join(m) if isinstance(m, tuple) else str(m)).lower()
            return any(c in s for c in content_excls)

        for fp, md_content in code_files:
            try:
                rel_parts = [p.lower() for p in fp.relative_to(skill_path).parts]
            except ValueError:
                rel_parts = [p.lower() for p in fp.parts]
            if dir_excls and any(p in dir_excls for p in rel_parts):
                continue

            # Handle Markdown files with code block extraction
            if md_content is not None:
                code_blocks = self._extract_code_blocks_from_markdown(md_content)

                for code, language, virtual_ext in code_blocks:
                    # File-type filter using virtual extension
                    if file_types != ["*"] and virtual_ext not in file_types:
                        continue

                    file_matches: List[str] = []
                    for rgx in compiled:
                        file_matches.extend(m.group(0) for m in rgx.finditer(code))
                    file_matches = [m for m in file_matches if not _excluded_value(m)]

                    if file_matches:
                        matches.append({
                            "pattern_id": rule["id"],
                            "pattern_name": rule["name"],
                            "severity": rule["severity"],
                            "category": rule["category"],
                            "file_path": f"{fp.relative_to(skill_path)}:block:{language}",
                            "matches": file_matches[:5],
                            "match_count": len(file_matches),
                            "description": rule["description"],
                            "confidence": self._calculate_match_confidence(rule, file_matches),
                        })

            # Handle regular code files
            else:
                # File-type filter
                if file_types != ["*"] and fp.suffix not in file_types:
                    continue

                try:
                    content = fp.read_text(encoding="utf-8", errors="ignore")
                except Exception as exc:
                    print(f"Warning: could not read {fp}: {exc}", file=sys.stderr)
                    continue

                file_matches: List[str] = []
                for rgx in compiled:
                    file_matches.extend(m.group(0) for m in rgx.finditer(content))
                file_matches = [m for m in file_matches if not _excluded_value(m)]

                if file_matches:
                    matches.append({
                        "pattern_id": rule["id"],
                        "pattern_name": rule["name"],
                        "severity": rule["severity"],
                        "category": rule["category"],
                        "file_path": str(fp.relative_to(skill_path)),
                        "matches": file_matches[:5],
                        "match_count": len(file_matches),
                        "description": rule["description"],
                        "confidence": self._calculate_match_confidence(rule, file_matches),
                    })

        return matches

    # -- phase C: false-positive filter -------------------------------------

    def _filter_false_positives(
        self, result: ScanResult, code_files: List[Tuple[Path, Optional[str]]]
    ) -> ScanResult:
        """Remove vulnerability hits that match a false-positive rule."""
        filtered_vulns: List[Dict] = []

        for vuln in result.vulnerabilities:
            is_fp = False
            fp_reason = None

            for fp_rule in self.false_positive_rules:
                for pat_str in fp_rule.get("regex_patterns", []):
                    try:
                        fp_re = re.compile(pat_str, re.IGNORECASE)
                    except re.error:
                        continue
                    for match_val in vuln.get("matches", []):
                        if fp_re.search(str(match_val)):
                            is_fp = True
                            fp_reason = fp_rule["description"]
                            break
                    if is_fp:
                        break
                if is_fp:
                    break

            if is_fp:
                result.false_positives.append({
                    **vuln,
                    "false_positive_reason": fp_reason,
                })
            else:
                filtered_vulns.append(vuln)

        result.vulnerabilities = filtered_vulns
        return result

    # -- confidence helpers -------------------------------------------------

    @staticmethod
    def _calculate_match_confidence(rule: Dict, matches: List) -> float:
        """Compute a per-rule confidence score (0.0 - 1.0)."""
        conf = 0.5
        count = len(matches)
        if count > 10:
            conf += 0.3
        elif count > 5:
            conf += 0.2
        elif count > 1:
            conf += 0.1

        sev = rule.get("severity", "Medium")
        if sev == "Critical":
            conf += 0.2
        elif sev == "High":
            conf += 0.1

        return min(conf, 1.0)

    @staticmethod
    def _calculate_confidence(result: ScanResult) -> float:
        """Compute the overall confidence score (0.0 - 100.0)."""
        score = 0.0

        severity_weight_mal = {"Critical": 30.0, "High": 20.0, "Medium": 10.0, "Low": 5.0}
        for mal in result.malicious_patterns:
            score += severity_weight_mal.get(mal["severity"], 10.0) * mal["confidence"]

        severity_weight_vul = {"Critical": 15.0, "High": 10.0, "Medium": 5.0, "Low": 2.0}
        for vuln in result.vulnerabilities:
            score += severity_weight_vul.get(vuln["severity"], 5.0) * vuln["confidence"]

        return min(score, 100.0)

    # -- IOC checking -------------------------------------------------------

    def check_iocs(self, content: str) -> List[Dict]:
        """Check a string against the known IOC database.

        Returns a list of IOC hit dicts.
        """
        found: List[Dict] = []

        for ip_info in self.ioc_database.get("malicious_ips", []):
            if ip_info["ip"] in content:
                found.append({
                    "type": "ip",
                    "value": ip_info["ip"],
                    "campaign": ip_info.get("campaign", ""),
                    "severity": ip_info.get("severity", "High"),
                })

        for dom_info in self.ioc_database.get("malicious_domains", []):
            if dom_info["domain"] in content:
                found.append({
                    "type": "domain",
                    "value": dom_info["domain"],
                    "description": dom_info.get("description", ""),
                    "severity": dom_info.get("severity", "High"),
                })

        for actor_info in self.ioc_database.get("malicious_actors", []):
            if actor_info["actor"] in content:
                found.append({
                    "type": "actor",
                    "value": actor_info["actor"],
                    "campaign": actor_info.get("campaign", ""),
                    "severity": actor_info.get("severity", "High"),
                })

        return found


# ---------------------------------------------------------------------------
# Result printing helpers
# ---------------------------------------------------------------------------
SEVERITY_LABELS = {
    "Critical": "[CRIT]",
    "High": "[HIGH]",
    "Medium": "[MED ]",
    "Low": "[LOW ]",
    "None": "[NONE]",
}


def print_result(result: ScanResult):
    """Pretty-print a ScanResult to stdout."""
    sep = "=" * 80
    print(f"\n{sep}")
    print(f"Skill ID      : {result.skill_id}")
    print(f"Timestamp     : {result.scan_timestamp}")
    print(f"Confidence    : {result.confidence_score:.1f} / 100")
    flagged = bool(result.malicious_patterns or result.vulnerabilities)
    print(f"Candidate (pattern match) : {'YES' if flagged else 'NO'}  (final label assigned in manual review)")
    print(f"{sep}\n")

    if result.malicious_patterns:
        print(f"Malicious-pattern matches — candidate signals ({len(result.malicious_patterns)}):")
        for i, mal in enumerate(result.malicious_patterns, 1):
            tag = SEVERITY_LABELS.get(mal["severity"], "[????]")
            print(f"  {i}. {tag} {mal['pattern_name']}")
            print(f"     Category   : {mal['category']}")
            print(f"     File       : {mal['file_path']}")
            print(f"     Match count: {mal['match_count']}")
            print(f"     Confidence : {mal['confidence'] * 100:.1f}%")
            print(f"     Description: {mal['description']}")
            if mal.get("matches"):
                print(f"     Sample     : {mal['matches'][0][:100]}...")
        print()

    if result.vulnerabilities:
        print(f"Vulnerability-pattern matches — candidate signals ({len(result.vulnerabilities)}):")
        for i, vuln in enumerate(result.vulnerabilities, 1):
            tag = SEVERITY_LABELS.get(vuln["severity"], "[????]")
            print(f"  {i}. {tag} {vuln['pattern_name']}")
            print(f"     Category   : {vuln['category']}")
            print(f"     File       : {vuln['file_path']}")
            print(f"     Match count: {vuln['match_count']}")
            print(f"     Description: {vuln['description']}")
            if vuln.get("matches"):
                print(f"     Sample     : {vuln['matches'][0][:100]}...")
        print()

    if result.false_positives:
        print(f"Filtered false positives ({len(result.false_positives)}):")
        for fp in result.false_positives:
            print(f"     - {fp['pattern_name']}: {fp['false_positive_reason']}")
        print()

    if not result.malicious_patterns and not result.vulnerabilities:
        print("No candidate signals detected.")
    else:
        total = len(result.malicious_patterns) + len(result.vulnerabilities)
        print(f"Total candidate signals: {total}  (candidates for Phase 3 / manual review)")

    print(f"{sep}\n")


def save_result(result: ScanResult, output_file: str):
    """Persist a ScanResult to a JSON file."""
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as fh:
        json.dump(asdict(result), fh, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Batch scanning
# ---------------------------------------------------------------------------
def batch_scan(
    scanner: SecurityScanner,
    skills_list: List[Tuple[str, str]],
    output_dir: str,
) -> Dict:
    """Scan a list of skills and write per-skill JSON + batch summary.

    Args:
        scanner:     Configured SecurityScanner instance.
        skills_list: List of (skill_id, skill_path) tuples.
        output_dir:  Directory for result files.

    Returns:
        Summary dict also written to <output_dir>/batch_summary.json.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    summary = {
        "scan_id": f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "scan_date": datetime.now().isoformat(),
        "total_skills": len(skills_list),
        "scanned_skills": 0,
        "results": {
            "malicious": {"total": 0, "by_severity": {}},
            "vulnerabilities": {"total": 0, "by_severity": {}},
            "false_positives": {"total": 0},
        },
        "errors": [],
    }

    print(f"\nBatch scan: {len(skills_list)} skills")
    print(f"Output dir : {output_dir}\n")

    for idx, (skill_id, skill_path) in enumerate(skills_list, 1):
        tag = f"[{idx}/{len(skills_list)}]"
        print(f"{tag} Scanning {skill_id}...", end=" ")

        try:
            result = scanner.scan_skill(skill_path, skill_id)
            summary["scanned_skills"] += 1

            # Per-skill result file
            save_result(result, str(out_path / f"{skill_id}_result.json"))

            if result.is_malicious:
                summary["results"]["malicious"]["total"] += 1

            for mal in result.malicious_patterns:
                sev = mal["severity"]
                summary["results"]["malicious"]["by_severity"][sev] = (
                    summary["results"]["malicious"]["by_severity"].get(sev, 0) + 1
                )

            for vuln in result.vulnerabilities:
                sev = vuln["severity"]
                summary["results"]["vulnerabilities"]["total"] += 1
                summary["results"]["vulnerabilities"]["by_severity"][sev] = (
                    summary["results"]["vulnerabilities"]["by_severity"].get(sev, 0) + 1
                )

            summary["results"]["false_positives"]["total"] += len(result.false_positives)
            if result.ast_flows:
                summary["results"].setdefault("ast_flows", {"total": 0})["total"] += 1

            codes = sorted({(p.get("pattern_id") or p.get("code") or p.get("id"))
                            for p in result.malicious_patterns + result.vulnerabilities if p} - {None})
            n_ast = len(result.ast_flows or [])
            parts = []
            if codes:
                parts.append("patterns: " + ", ".join(codes))
            if n_ast:
                parts.append(f"AST cred->sink flow x{n_ast}")
            print(f"done ({'candidate — ' + '; '.join(parts) if parts else 'clean (no signals)'})")

        except Exception as exc:
            summary["errors"].append(f"{skill_id}: {exc}")
            print(f"ERROR: {exc}")

    # Write batch summary
    summary_path = out_path / "batch_summary.json"
    with open(summary_path, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)

    # Print summary
    sep = "=" * 60
    print(f"\n{sep}")
    print("Batch scan complete  (candidate filter)")
    print(sep)
    print(f"  Total skills                       : {summary['total_skills']}")
    print(f"  Scanned                            : {summary['scanned_skills']}")
    print(f"  Skills matching malicious patterns : {summary['results']['malicious']['total']}")
    print(f"  Vulnerability-pattern matches      : {summary['results']['vulnerabilities']['total']}")
    print(f"  Skills with AST cred->sink flow    : {summary['results'].get('ast_flows', {}).get('total', 0)}")
    print(f"  False positives filtered           : {summary['results']['false_positives']['total']}")
    print(f"  Errors                             : {len(summary['errors'])}")
    print("  NOTE: candidate matches against the 10 patterns; final per-skill labels")
    print("        are assigned in manual review (Phase 4).")
    print(f"{sep}\n")

    return summary


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
def main():
    """Command-line interface for the static scanner."""
    parser = argparse.ArgumentParser(
        description="SkillLeakBench Phase 2 -- Static Security Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  # Scan a single skill
  python scanner.py --skill-path /path/to/skill --skill-id 123_my_skill

  # Batch scan from a JSON list
  python scanner.py --batch-file skills_list.json --output code/results/

  # Full directory scan
  python scanner.py --full-scan /path/to/skills --output code/results/

  # Use config.yaml for defaults
  python scanner.py --config ../config.yaml --full-scan ./repos
""",
    )

    parser.add_argument("--skill-path", type=str, help="Path to a single skill directory")
    parser.add_argument("--skill-id", type=str, help="Unique skill identifier")
    parser.add_argument("--batch-file", type=str, help="JSON file with skill list")
    parser.add_argument("--full-scan", type=str, help="Root directory for full scan")
    parser.add_argument("--output", type=str, default=None, help="Output directory or file")
    parser.add_argument("--rules", type=str, default=None, help="Path to scanning_rules.json")
    parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")
    parser.add_argument("--verbose", "-v", action="store_true", help="Print detailed results")

    args = parser.parse_args()

    # Load config if provided (or discovered nearby)
    cfg = None
    if args.config:
        cfg = Config(args.config)

    # Resolve rules file
    rules_file = args.rules
    if rules_file is None:
        if cfg:
            rules_file = str(cfg.resolve_path(cfg.get("phase2.scanner.rules_file", "code/phase2_static/scanning_rules.json")))
        else:
            rules_file = str(_SCRIPT_DIR / "scanning_rules.json")

    # Resolve output target
    output = args.output
    if output is None:
        if cfg:
            output = str(cfg.resolve_path(cfg.get("phase2.scanner.output_dir", "code/results/phase2_scan")))
        else:
            output = "code/results"

    scanner = SecurityScanner(rules_file=rules_file)

    # --- Single skill scan -------------------------------------------------
    if args.skill_path and args.skill_id:
        print(f"Scanning skill : {args.skill_id}")
        print(f"Path           : {args.skill_path}")

        result = scanner.scan_skill(args.skill_path, args.skill_id)

        if args.verbose:
            print_result(result)

        if output:
            output_path = Path(output)
            if output_path.is_dir() or output.endswith("/") or not output_path.suffix:
                output_path.mkdir(parents=True, exist_ok=True)
                output_path = output_path / f"{args.skill_id}_result.json"
            else:
                output_path.parent.mkdir(parents=True, exist_ok=True)
            save_result(result, str(output_path))
            print(f"Result saved to: {output_path}")
        else:
            print_result(result)

    # --- Batch scan --------------------------------------------------------
    elif args.batch_file:
        try:
            with open(args.batch_file, "r", encoding="utf-8") as fh:
                raw = json.load(fh)

            # Accept dict {id: path} or list [[id, path], ...]
            if isinstance(raw, dict):
                skills_list = [(k, v) for k, v in raw.items()]
            elif isinstance(raw, list) and all(isinstance(item, list) for item in raw):
                skills_list = [(item[0], item[1]) for item in raw]
            else:
                print("Error: unsupported batch-file format", file=sys.stderr)
                sys.exit(1)

            batch_scan(scanner, skills_list, output)

        except Exception as exc:
            print(f"Error: failed to load batch file: {exc}", file=sys.stderr)
            sys.exit(1)

    # --- Full directory scan -----------------------------------------------
    elif args.full_scan:
        root = Path(args.full_scan)
        if not root.exists():
            print(f"Error: path does not exist: {args.full_scan}", file=sys.stderr)
            sys.exit(1)

        skills_list = [
            (d.name, str(d))
            for d in sorted(root.iterdir())
            if d.is_dir() and not d.name.startswith(".")
        ]

        print(f"Discovered {len(skills_list)} skill directories")

        if skills_list:
            batch_scan(scanner, skills_list, output)
        else:
            print("No skill directories found.")

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
