# SkillLeakBench Pipeline Code

Entry point: **`helper.py`** — run with no arguments for a menu, or a subcommand
(`doctor` / `analyze` / `build` / `run` / `status` / `clean` / `init`). `analyze` reproduces every
reported dataset/taxonomy number offline from `data/` (no secrets, no Docker).

## Layout

| Path | What |
|------|------|
| `helper.py` | one entry point: env check, offline reproduction, image build, full pipeline |
| `analysis/` | offline reproduction suite (`verify_dataset`, `rq1_landscape`, `rq2_taxonomy`, `remediation_status`, `popularity`, `build_dataset`) — see [`analysis/README.md`](analysis/README.md) |
| `phase1_collection/` | `crawler.py` (SkillsMP API) + `extractor.py` |
| `phase2_static/` | `scanner.py` (regex, `scanning_rules.json`) + `ast_analyzer.py` (tree-sitter source→sink) + `nl_analyzer.py` + `test_*.py` |
| `phase3_dynamic/` | Docker sandbox: `entrypoint.sh`, `monitor.py`, `mock_creds.py`, `differential.py` (dual-condition logic), `run_dual.py` (driver/batch), `executor.py` (interactive) + `test_*.py`, `test_e2e_sandbox.sh` |
| `scripts/` | `01_collect.sh` / `02_static_filter.sh` / `03_dynamic_validate.sh` / `run_all.sh` + `lib.sh` |
| `utils/` | `config_loader.py`, `path_helper.py` |

## Tests

```bash
python3 -m pytest code/phase2_static/test_*.py code/phase3_dynamic/test_*.py   # or run any test_*.py directly
```

## Phase 3 modes (`03_dynamic_validate.sh`)

- `--self-test` (default) — non-interactive forged-credential leak detection; needs Docker, **no API key**.
- `--dual CANDIDATES` — agent-driven Benign/Adversarial differential (needs a valid `ANTHROPIC_API_KEY`).
- `--interactive CANDIDATES` — human-in-the-loop sandbox menu.

## Detection rules

10 academic patterns (4 vulnerability + 6 malicious) + 4 false-positive filters in
`phase2_static/scanning_rules.json`; see [`phase2_static/README.md`](phase2_static/README.md).

## Run artifacts

Live runs write intermediate files under `code/results/` (gitignored). See
[`results.sample/`](results.sample/) for the per-phase output formats.
