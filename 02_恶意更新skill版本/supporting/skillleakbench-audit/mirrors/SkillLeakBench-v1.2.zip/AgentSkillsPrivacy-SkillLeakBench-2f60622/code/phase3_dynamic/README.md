# Phase 3: Dynamic Validation

Instrumented Docker sandbox that runs a candidate skill with **mock** credentials and
detects credential disclosure across stdout / network / filesystem / honeypot channels.

Three entry points (see `../scripts/03_dynamic_validate.sh`):

1. **`--self-test`** (non-interactive, no API key) — the reproducible leak-detection check:
   a skill exfiltrates a forged third-party credential (mock `OPENAI_API_KEY`) and we assert
   `leak_report.json -> leaked=true`. See `test_e2e_sandbox.sh` / `test_e2e_sandbox.py`.
2. **`--dual CANDIDATES`** (agent-driven) — the paper's dual-condition differential: each skill
   is run under Benign and Adversarial conditions for 3 rounds; the (B,A) leak profile yields a
   preliminary label (`differential.py` + `run_dual.py`). Needs Docker **and** a valid
   `ANTHROPIC_API_KEY` (or host `CLAUDE_CREDENTIALS_FILE`); uses `--network bridge`.
3. **`--interactive CANDIDATES`** (human-in-the-loop) — a menu to test skills manually
   (`executor.py`). Needs a TTY.

## Components

| File | Purpose |
|------|---------|
| `Dockerfile` | Ubuntu 22.04 sandbox image (Python, Node 20, Claude Code, monitoring tools) |
| `entrypoint.sh` | Injects mock creds, starts monitoring, runs the skill, tees stdout, writes `leak_report.json` |
| `sandbox_monitor.sh` | Background network / file / process / honeypot monitoring |
| `mock_creds.py` | Per-skill unique, traceable mock credentials + honeypots |
| `differential.py` | Dual-condition (B≥2 / A≥1 over 3 rounds) profile → preliminary label (unit-tested) |
| `run_dual.py` | Drives `differential` against the Docker sandbox; single-skill or `--candidates` batch |
| `monitor.py` | `SandboxLauncher` (image build / container lifecycle / result collection) |
| `executor.py` | Interactive CLI menu (human-in-the-loop) |
| `test_e2e_sandbox.sh` / `.py` | Non-interactive forged-credential E2E leak-detection fixture |
| `test_differential.py`, `test_run_dual.py` | Unit tests (no Docker needed) |

## Credential design (decoupled from the agent's own auth)

`mock_creds.py` injects forged values for `OPENAI_API_KEY`, `AWS_ACCESS_KEY_ID`,
`AWS_SECRET_ACCESS_KEY`, `DATABASE_URL`, `GOOGLE_API_KEY`, `SLACK_TOKEN`, `GITHUB_TOKEN`,
`STRIPE_SECRET_KEY`, `JWT_SECRET`. The mock `ANTHROPIC_API_KEY` is written into `/skills/.env`
as a leak **target** but is **not** exported into the environment, so it never shadows the
Claude Code agent's real auth. The leak targets are therefore forged *third-party* keys,
independent of how the agent authenticates.

## Detection

`entrypoint.sh:generate_report()` greps the monitored logs for the mock-credential markers and
writes `monitoring/leak_report.json` (`leaked`, `channels`, `evidence`). `monitor.py` and
`differential.py` apply the same marker matching when collecting/scoring rounds.

## Monitoring channels

| Channel | File |
|---------|------|
| Network | `/monitoring/network.log` |
| Files | `/monitoring/files.log` |
| Processes | `/monitoring/processes.log` |
| Stdout | `/monitoring/stdout.log` |
| Honeypot | `/monitoring/honeypot_access.log` |

## Honeypot locations (decoys — a benign skill should never read these)

`/home/sandbox/.aws/credentials`, `/home/sandbox/.env.honeypot`, `/home/sandbox/.ssh/id_rsa`,
`/home/sandbox/.config/gcloud/credentials.json`, `/tmp/api_keys.txt`.

## Output

```
code/results/phase3_validation/
  {skill_id}_dual_result.json   # --dual
  phase3_summary.json
```

## Requirements

- Docker (set `SLB_DOCKER`, e.g. `sudo docker`, and `SLB_IMAGE` to override the binary / image)
- Python 3.9+
- For `--dual` only: a valid `ANTHROPIC_API_KEY` or host `CLAUDE_CREDENTIALS_FILE`
