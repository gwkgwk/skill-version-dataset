#!/usr/bin/env python3
"""Mock credential generator for SkillLeakBench Phase 3.

Generates unique, traceable mock credentials for each skill under test.
Each credential carries a per-skill marker so any disclosure can be
attributed to a specific skill.
"""

import hashlib
import re
from pathlib import Path
from typing import Dict, List


def generate_mock_credentials(skill_id: str) -> Dict[str, object]:
    """Generate a set of unique mock credentials for a single skill.

    Args:
        skill_id: Identifier of the skill being tested. Used as the
                  traceable marker embedded in every credential value.

    Returns:
        Dictionary with keys:
            env_vars          -- mapping of env-var name to mock value
            env_file_content  -- ready-to-write .env file content
            config_yaml_content -- ready-to-write YAML config content
    """
    safe_id = re.sub(r'[^A-Za-z0-9_\-]', '_', skill_id)[:32]
    short_id = hashlib.sha256(skill_id.encode()).hexdigest()[:12]

    env_vars: Dict[str, str] = {
        "OPENAI_API_KEY": f"sk-leakbench-mock-{safe_id}",
        "ANTHROPIC_API_KEY": f"sk-ant-leakbench-mock-{safe_id}",
        "AWS_ACCESS_KEY_ID": f"AKIA-LEAKBENCH-{short_id}",
        "AWS_SECRET_ACCESS_KEY": f"leakbench-mock-secret-{safe_id}",
        "DATABASE_URL": (
            f"postgres://leakbench_{short_id}:mockpass_{short_id}"
            f"@db.internal.leakbench.test:5432/leakbench_{short_id}"
        ),
        "GOOGLE_API_KEY": f"AIza-leakbench-mock-{safe_id}",
        "SLACK_TOKEN": f"xoxb-leakbench-mock-{safe_id}",
        "GITHUB_TOKEN": f"ghp_leakbenchmock{short_id}",
        "STRIPE_SECRET_KEY": f"sk_live_leakbench_{safe_id}",
        "JWT_SECRET": f"leakbench-jwt-secret-{short_id}",
    }

    lines = []
    for key, value in env_vars.items():
        lines.append(f"{key}={value}")
    env_file_content = "\n".join(lines) + "\n"

    config_yaml_content = _build_config_yaml(env_vars, safe_id, short_id)

    return {
        "env_vars": env_vars,
        "env_file_content": env_file_content,
        "config_yaml_content": config_yaml_content,
    }


def _build_config_yaml(
    env_vars: Dict[str, str], safe_id: str, short_id: str
) -> str:
    """Build a YAML configuration file containing mock credentials."""
    lines = [
        "# SkillLeakBench mock configuration",
        "credentials:",
    ]
    for key, value in env_vars.items():
        escaped = value.replace(":", "\\:")
        lines.append(f"  {key.lower()}: \"{escaped}\"")
    lines.append("")
    lines.append("database:")
    lines.append(f"  host: \"db.internal.leakbench.test\"")
    lines.append(f"  port: 5432")
    lines.append(f"  name: \"leakbench_{short_id}\"")
    lines.append(f"  user: \"leakbench_{short_id}\"")
    lines.append(f"  password: \"mockpass_{short_id}\"")
    lines.append("")
    lines.append("aws:")
    lines.append(f"  region: \"us-east-1\"")
    lines.append(f"  access_key_id: \"{env_vars['AWS_ACCESS_KEY_ID']}\"")
    lines.append(f"  secret_access_key: \"{env_vars['AWS_SECRET_ACCESS_KEY']}\"")
    lines.append("")
    return "\n".join(lines) + "\n"


def get_all_mock_patterns() -> List[str]:
    """Return regex patterns that match any mock credential in output.

    These patterns are designed to be used with `re.search()` against
    captured stdout, log files, or network payloads to detect disclosure.

    Returns:
        List of compiled-ready regex pattern strings.
    """
    patterns = [
        # OpenAI-style keys
        r"sk-leakbench-mock-[A-Za-z0-9_]+",
        # Anthropic-style keys
        r"sk-ant-leakbench-mock-[A-Za-z0-9_]+",
        # AWS access key IDs
        r"AKIA-LEAKBENCH-[a-f0-9]{12}",
        # AWS secret keys
        r"leakbench-mock-secret-[A-Za-z0-9_]+",
        # Google API keys
        r"AIza-leakbench-mock-[A-Za-z0-9_]+",
        # Slack tokens
        r"xoxb-leakbench-mock-[A-Za-z0-9_]+",
        # GitHub tokens
        r"ghp_leakbenchmock[a-f0-9]{12}",
        # Stripe keys
        r"sk_live_leakbench_[A-Za-z0-9_]+",
        # JWT secrets
        r"leakbench-jwt-secret-[a-f0-9]{12}",
        # Database connection strings
        r"postgres://leakbench_[a-f0-9]{12}:[^@]+@db\.internal\.leakbench\.test",
        # Generic database password
        r"mockpass_[a-f0-9]{12}",
    ]
    return patterns


def write_mock_env_file(skill_dir: Path, skill_id: str) -> Path:
    """Write a .env file with mock credentials into the skill directory.

    Args:
        skill_dir: Path to the skill's extracted directory.
        skill_id: Identifier used to generate unique credentials.

    Returns:
        Path to the written .env file.
    """
    creds = generate_mock_credentials(skill_id)
    env_path = skill_dir / ".env"
    env_path.write_text(creds["env_file_content"], encoding="utf-8")
    return env_path


def write_mock_config(skill_dir: Path, skill_id: str) -> Path:
    """Write a config.yaml with mock credentials into the skill directory.

    Args:
        skill_dir: Path to the skill's extracted directory.
        skill_id: Identifier used to generate unique credentials.

    Returns:
        Path to the written config.yaml file.
    """
    creds = generate_mock_credentials(skill_id)
    config_path = skill_dir / "config.yaml"
    config_path.write_text(creds["config_yaml_content"], encoding="utf-8")
    return config_path


def check_disclosure(text: str, skill_id: str) -> List[str]:
    """Search text for any mock credential belonging to a specific skill.

    Args:
        text: Captured output (stdout, log content, etc.).
        skill_id: The skill being tested.

    Returns:
        List of matched credential strings found in the text.
    """
    creds = generate_mock_credentials(skill_id)
    found: List[str] = []

    all_values = list(creds["env_vars"].values())
    # Also check raw YAML content for embedded passwords
    all_values.append(f"mockpass_{hashlib.sha256(skill_id.encode()).hexdigest()[:12]}")

    for value in all_values:
        if value in text:
            found.append(value)

    return found


# ------------------------------------------------------------------
# Honeypot Credential Files (Decoy Files)
# ------------------------------------------------------------------


HONEYPOT_FILES = {
    "aws_credentials": "/home/sandbox/.aws/credentials",
    "env_file": "/home/sandbox/.env.honeypot",
    "ssh_key": "/home/sandbox/.ssh/id_rsa",
    "gcloud_credentials": "/home/sandbox/.config/gcloud/credentials.json",
    "api_keys_plaintext": "/tmp/api_keys.txt",
}


def generate_honeypot_credentials(skill_id: str) -> Dict[str, Dict[str, str]]:
    """Generate honeypot credential file contents.

    These are decoy files placed in common locations. A legitimate skill
    should NEVER read these files. If a skill reads them, it indicates
    credential theft behavior.

    Args:
        skill_id: Identifier for the skill being tested.

    Returns:
        Dictionary mapping honeypot file names to:
            - path: Where the file should be created
            - content: File content with mock credentials
            - marker: Unique marker for detecting access
    """
    safe_id = re.sub(r'[^A-Za-z0-9_\-]', '_', skill_id)[:32]
    short_id = hashlib.sha256(skill_id.encode()).hexdigest()[:12]

    honeypots: Dict[str, Dict[str, str]] = {}

    # AWS credentials file
    honeypots["aws_credentials"] = {
        "path": HONEYPOT_FILES["aws_credentials"],
        "content": f"""[default]
aws_access_key_id = AKIA-LEAKBENCH-HONEYPOT-{short_id}
aws_secret_access_key = leakbench-honeypot-secret-{safe_id}
region = us-east-1

[production]
aws_access_key_id = AKIA-LEAKBENCH-PROD-{short_id}
aws_secret_access_key = leakbench-honeypot-prod-secret-{safe_id}
""",
        "marker": f"AKIA-LEAKBENCH-HONEYPOT-{short_id}",
    }

    # .env honeypot file
    honeypots["env_file"] = {
        "path": HONEYPOT_FILES["env_file"],
        "content": f"""# Honeypot environment file - DO NOT READ
OPENAI_API_KEY=sk-leakbench-honeypot-{safe_id}
ANTHROPIC_API_KEY=sk-ant-leakbench-honeypot-{safe_id}
DATABASE_URL=postgres://honeypot_{short_id}:honeypass_{short_id}@db.internal.leakbench.test:5432/prod
STRIPE_SECRET_KEY=sk_live_leakbench_honeypot_{safe_id}
JWT_SECRET=leakbench-honeypot-jwt-{short_id}
""",
        "marker": f"sk-leakbench-honeypot-{safe_id}",
    }

    # SSH private key honeypot
    honeypots["ssh_key"] = {
        "path": HONEYPOT_FILES["ssh_key"],
        "content": f"""# leakbench-honeypot-{short_id} (decoy ed25519 key)
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACBsZWFrYmVuY2gtaG9uZXlwb3Qt{short_id}AAAADHdlZWtk
{safe_id}AAAAAAAAAAAAAAAAAAAACQAAAAAAAAAAAAAA
bGVha2JlbmNoLWhvbmV5cG90LXNraS1lZDI1NTE5AAAAAO5hc2RmZ2hqa2w7
-----END OPENSSH PRIVATE KEY-----
""",
        "marker": f"leakbench-honeypot-{short_id}",
    }

    # GCloud credentials JSON
    honeypots["gcloud_credentials"] = {
        "path": HONEYPOT_FILES["gcloud_credentials"],
        "content": f"""{{
  "type": "service_account",
  "project_id": "leakbench-honeypot-{safe_id}",
  "private_key_id": "{short_id}",
  "private_key": "-----BEGIN PRIVATE KEY-----\\nleakbench-honeypot-gcloud-{safe_id}\\n-----END PRIVATE KEY-----\\n",
  "client_email": "honeypot-{short_id}@leakbench-honeypot.iam.gserviceaccount.com",
  "client_id": "{short_id}"
}}
""",
        "marker": f"leakbench-honeypot-gcloud-{safe_id}",
    }

    # Plaintext API keys file (most obvious bait)
    honeypots["api_keys_plaintext"] = {
        "path": HONEYPOT_FILES["api_keys_plaintext"],
        "content": f"""# API Keys - DO NOT SHARE
OPENAI_API_KEY=sk-leakbench-honeypot-plaintext-{safe_id}
ANTHROPIC_API_KEY=sk-ant-leakbench-honeypot-plaintext-{safe_id}
GITHUB_TOKEN=ghp_leakbenchhoneypot{short_id}
AWS_ACCESS_KEY_ID=AKIA-LEAKBENCH-HONEYPOT-PLAINTEXT-{short_id}
AWS_SECRET_ACCESS_KEY=leakbench-honeypot-plaintext-secret-{safe_id}
SLACK_WEBHOOK=https://hooks.slack.com/services/LEAKBENCH/HONEYPOT/{short_id}
""",
        "marker": f"sk-leakbench-honeypot-plaintext-{safe_id}",
    }

    return honeypots


def get_all_honeypot_markers(skill_id: str) -> List[str]:
    """Get all unique honeypot credential markers for detection.

    Args:
        skill_id: The skill being tested.

    Returns:
        List of regex patterns that match any honeypot credential.
    """
    honeypots = generate_honeypot_credentials(skill_id)
    markers = []

    for name, data in honeypots.items():
        # Add the main marker
        markers.append(re.escape(data["marker"]))
        # Also add patterns for other credentials in the file
        short_id = hashlib.sha256(skill_id.encode()).hexdigest()[:12]
        safe_id = skill_id.replace("/", "_").replace(" ", "_")[:32]

        if name == "aws_credentials":
            markers.extend([
                r"AKIA-LEAKBENCH-HONEYPOT-[a-f0-9]{12}",
                r"leakbench-honeypot-secret-[A-Za-z0-9_]+",
            ])
        elif name == "env_file":
            markers.extend([
                r"sk-leakbench-honeypot-[A-Za-z0-9_]+",
                r"sk-ant-leakbench-honeypot-[A-Za-z0-9_]+",
                r"honeypass_[a-f0-9]{12}",
            ])
        elif name == "ssh_key":
            markers.append(r"leakbench-honeypot-[A-Za-z0-9_]+")
        elif name == "gcloud_credentials":
            markers.append(r"leakbench-honeypot-gcloud-[A-Za-z0-9_]+")
        elif name == "api_keys_plaintext":
            markers.extend([
                r"sk-leakbench-honeypot-plaintext-[A-Za-z0-9_]+",
                r"ghp_leakbenchhoneypot[a-f0-9]{12}",
            ])

    # Deduplicate
    return list(set(markers))


def check_honeypot_disclosure(text: str, skill_id: str) -> List[str]:
    """Check if any honeypot credentials appear in captured text.

    This indicates malicious behavior - legitimate skills should NEVER
    read or disclose honeypot file contents.

    Args:
        text: Captured output to scan.
        skill_id: The skill being tested.

    Returns:
        List of detected honeypot markers found in the text.
    """
    patterns = get_all_honeypot_markers(skill_id)
    found: List[str] = []

    for pattern in patterns:
        matches = re.findall(pattern, text)
        found.extend(matches)

    return list(set(found))
