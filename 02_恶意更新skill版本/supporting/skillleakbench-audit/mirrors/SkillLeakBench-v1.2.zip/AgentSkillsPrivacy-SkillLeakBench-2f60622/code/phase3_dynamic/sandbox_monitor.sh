#!/bin/bash
# SkillLeakBench - Background Sandbox Monitor
# Monitors network connections, file changes, and process creation.
# Runs in the background and writes logs to /monitoring/

set -euo pipefail

# Configuration
MONITORING_DIR="${MONITORING_DIR:-/monitoring}"
POLL_INTERVAL="${POLL_INTERVAL:-1}"
SKILL_ID="${SKILL_ID:-unknown}"

# Output files
NETWORK_LOG="$MONITORING_DIR/network.log"
FILE_LOG="$MONITORING_DIR/files.log"
PROCESS_LOG="$MONITORING_DIR/processes.log"
ENV_LOG="$MONITORING_DIR/environment.log"
STDOUT_LOG="$MONITORING_DIR/stdout.log"
HONEYPOT_ACCESS_LOG="$MONITORING_DIR/honeypot_access.log"
SUMMARY_FILE="$MONITORING_DIR/summary.json"

# Initialize monitoring directory
init_monitoring() {
    mkdir -p "$MONITORING_DIR"

    # Initialize log files with headers
    echo "# SkillLeakBench Monitoring Log" > "$NETWORK_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$NETWORK_LOG"
    echo "# Started: $(date -Iseconds)" >> "$NETWORK_LOG"
    echo "# Columns: timestamp,protocol,local_addr,remote_addr,state,pid,program" >> "$NETWORK_LOG"

    echo "# SkillLeakBench File Monitoring Log" > "$FILE_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$FILE_LOG"
    echo "# Started: $(date -Iseconds)" >> "$FILE_LOG"

    echo "# SkillLeakBench Process Monitoring Log" > "$PROCESS_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$PROCESS_LOG"
    echo "# Started: $(date -Iseconds)" >> "$PROCESS_LOG"

    echo "# SkillLeakBench Environment Monitoring Log" > "$ENV_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$ENV_LOG"
    echo "# Started: $(date -Iseconds)" >> "$ENV_LOG"

    echo "# SkillLeakBench Honeypot Access Log" > "$HONEYPOT_ACCESS_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$HONEYPOT_ACCESS_LOG"
    echo "# Started: $(date -Iseconds)" >> "$HONEYPOT_ACCESS_LOG"
    echo "# Honeypot files are decoys - legitimate skills should NEVER access them" >> "$HONEYPOT_ACCESS_LOG"
}

# Monitor network connections
monitor_network() {
    local timestamp
    while true; do
        timestamp=$(date -Iseconds)

        ss -tunap 2>/dev/null | while read -r line; do
            # Skip header lines
            if [[ "$line" =~ ^(Netid|State) ]] || [[ -z "$line" ]]; then
                continue
            fi

            # Log the connection
            echo "$timestamp | $line" >> "$NETWORK_LOG"
        done

        sleep "$POLL_INTERVAL"
    done
}

# Honeypot file paths (must match mock_creds.py:HONEYPOT_FILES)
HONEYPOT_FILES=(
    "/home/sandbox/.aws/credentials"
    "/home/sandbox/.env.honeypot"
    "/home/sandbox/.ssh/id_rsa"
    "/home/sandbox/.config/gcloud/credentials.json"
    "/tmp/api_keys.txt"
)

# Monitor honeypot files for access
monitor_honeypot_files() {
    # Append to honeypot access log (header already written by init_monitoring)
    echo "# Honeypot monitor started: $(date -Iseconds)" >> "$HONEYPOT_ACCESS_LOG"

    # Use inotifywait to monitor honeypot file access
    if command -v inotifywait &>/dev/null; then
        for honeypot in "${HONEYPOT_FILES[@]}"; do
            if [[ -f "$honeypot" ]]; then
                (
                    inotifywait -m -e access,open,read "$honeypot" 2>/dev/null | while read -r line; do
                        echo "$(date -Iseconds) | HONEYPOT_ACCESS | $line" >> "$HONEYPOT_ACCESS_LOG"
                    done
                ) &
            fi
        done
    fi

    # Also use lsof polling as fallback
    while true; do
        for honeypot in "${HONEYPOT_FILES[@]}"; do
            if [[ -f "$honeypot" ]]; then
                # Check if any process has the honeypot file open
                local pids
                pids=$(lsof -t "$honeypot" 2>/dev/null || true)
                if [[ -n "$pids" ]]; then
                    for pid in $pids; do
                        # Check if we've already logged this access
                        if ! grep -q "PID:$pid" "$HONEYPOT_ACCESS_LOG" 2>/dev/null; then
                            local proc_info
                            proc_info=$(ps -p "$pid" -o pid,ppid,user,cmd --no-headers 2>/dev/null || echo "unknown")
                            echo "$(date -Iseconds) | HONEYPOT_OPEN | $honeypot | PID:$pid | $proc_info" >> "$HONEYPOT_ACCESS_LOG"
                        fi
                    done
                fi
            fi
        done
        sleep "$POLL_INTERVAL"
    done
}

# Monitor file system changes using inotifywait
monitor_files() {
    local skills_dir="${SKILLS_DIR:-/skills}"

    if ! command -v inotifywait &>/dev/null; then
        echo "inotifywait not available, using polling for file monitoring" >&2
        monitor_files_polling
        return
    fi

    # Monitor for file changes in the skills directory
    inotifywait -m -r -e create,modify,delete,access,open,close \
        --format "%T | %w | %f | %e" \
        --timefmt "%Y-%m-%dT%H:%M:%S" \
        "$skills_dir" 2>/dev/null >> "$FILE_LOG" || true
}

# Fallback file monitoring using polling
monitor_files_polling() {
    local skills_dir="${SKILLS_DIR:-/skills}"
    local prev_snapshot="$MONITORING_DIR/.file_snapshot_prev"
    local curr_snapshot="$MONITORING_DIR/.file_snapshot_curr"

    find "$skills_dir" -type f -exec ls -la {} \; 2>/dev/null > "$prev_snapshot" || true

    while true; do
        sleep "$POLL_INTERVAL"

        find "$skills_dir" -type f -exec ls -la {} \; 2>/dev/null > "$curr_snapshot" || true

        # Compare snapshots
        if ! diff -q "$prev_snapshot" "$curr_snapshot" >/dev/null 2>&1; then
            echo "$(date -Iseconds) | File changes detected" >> "$FILE_LOG"
            diff "$prev_snapshot" "$curr_snapshot" >> "$FILE_LOG" 2>&1 || true
            cp "$curr_snapshot" "$prev_snapshot"
        fi
    done
}

# Monitor process creation
monitor_processes() {
    local timestamp
    local seen_pids_file="$MONITORING_DIR/.seen_pids"

    touch "$seen_pids_file"

    while true; do
        timestamp=$(date -Iseconds)

        ps -eo pid,ppid,user,cmd --no-headers 2>/dev/null | while read -r line; do
            local pid
            pid=$(echo "$line" | awk '{print $1}')

            # Check if we've seen this PID
            if ! grep -q "^$pid$" "$seen_pids_file" 2>/dev/null; then
                echo "$timestamp | NEW_PROCESS | $line" >> "$PROCESS_LOG"
                echo "$pid" >> "$seen_pids_file"
            fi
        done

        sleep "$POLL_INTERVAL"
    done
}

# Environment-variable access monitoring is disabled: reading /proc/*/environ needs
# privileges the sandbox user does not have.
monitor_environment() {
    :
}

# Capture stdout/stderr from all processes
capture_stdout() {
    # Initialize the stdout log header; the entrypoint appends the command's actual output.
    echo "# SkillLeakBench stdout/stderr capture" > "$STDOUT_LOG"
    echo "# Skill ID: $SKILL_ID" >> "$STDOUT_LOG"
    echo "# Started: $(date -Iseconds)" >> "$STDOUT_LOG"
    echo "# Note: stdout/stderr is captured by the entrypoint script" >> "$STDOUT_LOG"
}

# Generate summary report on exit
generate_summary() {
    local end_time
    end_time=$(date -Iseconds)

    cat > "$SUMMARY_FILE" <<EOF
{
    "skill_id": "$SKILL_ID",
    "monitoring_start": "$(cat "$NETWORK_LOG" | head -3 | tail -1 | cut -d' ' -f3-)",
    "monitoring_end": "$end_time",
    "network_log": "$NETWORK_LOG",
    "file_log": "$FILE_LOG",
    "process_log": "$PROCESS_LOG",
    "env_log": "$ENV_LOG"
}
EOF

    echo "Monitoring summary written to $SUMMARY_FILE"
}

# Cleanup on exit
cleanup() {
    echo "Stopping monitoring..."
    generate_summary

    # Kill all background jobs
    jobs -p | xargs -r kill 2>/dev/null || true

    exit 0
}

# Main entry point
main() {
    echo "Starting SkillLeakBench sandbox monitor..."
    echo "Skill ID: $SKILL_ID"
    echo "Monitoring directory: $MONITORING_DIR"

    # Set up signal handlers
    trap cleanup EXIT INT TERM

    # Initialize monitoring
    init_monitoring

    # Start monitoring in background
    monitor_network &
    NETWORK_PID=$!
    echo "Network monitor started (PID: $NETWORK_PID)"

    monitor_files &
    FILE_PID=$!
    echo "File monitor started (PID: $FILE_PID)"

    monitor_processes &
    PROCESS_PID=$!
    echo "Process monitor started (PID: $PROCESS_PID)"

    capture_stdout &
    STDOUT_PID=$!
    echo "Stdout capture started (PID: $STDOUT_PID)"

    monitor_honeypot_files &
    HONEYPOT_PID=$!
    echo "Honeypot file monitor started (PID: $HONEYPOT_PID)"

    echo ""
    echo "All monitors running. Press Ctrl+C to stop."
    echo ""

    # Wait for all background processes
    wait
}

# Run main
main "$@"
