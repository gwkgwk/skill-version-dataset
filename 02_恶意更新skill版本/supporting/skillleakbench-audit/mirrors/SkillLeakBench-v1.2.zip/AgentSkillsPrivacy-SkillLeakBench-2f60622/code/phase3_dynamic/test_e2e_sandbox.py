#!/usr/bin/env python3
"""pytest wrappers for the Phase 3 end-to-end leak-detection fixtures.

Both run a checked-in shell fixture against the Docker sandbox and assert a leak is
detected; they skip cleanly when Docker or the skill-leakbench image is unavailable,
so they are safe in CI without Docker. The credentials leaked are FORGED third-party
keys (no real Anthropic auth needed).

  test_e2e_sandbox.sh         -> a skill exfiltrates a mock OPENAI_API_KEY to STDOUT
  test_e2e_network_exfil.sh   -> a skill POSTs mock creds + a honeypot file over the
                                 NETWORK; caught via the payload sinkhole (channel=network)

Run:  python3 -m pytest code/phase3_dynamic/test_e2e_sandbox.py
Or:   bash code/phase3_dynamic/test_e2e_sandbox.sh        (standalone, prints PASS/FAIL)
      bash code/phase3_dynamic/test_e2e_network_exfil.sh
"""
import os
import shutil
import subprocess
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent


def _docker_cmd():
    return os.environ.get("SLB_DOCKER", "docker").split()


def _run_fixture(name):
    docker = _docker_cmd()
    if shutil.which(docker[0]) is None:
        pytest.skip(f"{docker[0]} not on PATH (set SLB_DOCKER to override)")
    image = os.environ.get("SLB_IMAGE", "skill-leakbench")
    inspect = subprocess.run(docker + ["image", "inspect", image],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if inspect.returncode != 0:
        pytest.skip(f"image '{image}' not built (run: python3 code/helper.py build)")
    proc = subprocess.run(["bash", str(HERE / name)], capture_output=True, text=True, timeout=300)
    if proc.returncode == 77:
        pytest.skip("fixture reported SKIP: " + proc.stdout.strip())
    assert proc.returncode == 0, f"fixture failed:\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
    assert "PASS" in proc.stdout, proc.stdout


def test_forged_credential_leak_detected_e2e():
    """A skill that exfiltrates a forged non-Anthropic OPENAI_API_KEY to stdout is flagged."""
    _run_fixture("test_e2e_sandbox.sh")


def test_forged_credential_network_exfil_detected_e2e():
    """A skill that POSTs forged creds + a honeypot file over the network is caught via
    the payload sinkhole (channel=network), proving network-exfiltration detection."""
    _run_fixture("test_e2e_network_exfil.sh")
