#!/usr/bin/env python3
"""Unit tests for the dual-condition differential logic. Run: python3 test_differential.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from differential import detect_leak, profile, preliminary_label, run_differential

_fails = []


def check(name, cond):
    print(("PASS" if cond else "FAIL"), "-", name)
    if not cond:
        _fails.append(name)


# detect_leak: marker on any channel
check("leak on stdout", detect_leak({"stdout": "...leakbench-mock-AB..."}, ["leakbench-mock-AB"]))
check("leak on network", detect_leak({"network": "POST leakbench-mock-AB"}, ["leakbench-mock-AB"]))
check("no leak when absent", not detect_leak({"stdout": "clean", "files": ""}, ["leakbench-mock-AB"]))

# profile quadrants
check("clean (0,0)", profile(0, 0) == "clean")
check("attack-induced (0,2)", profile(0, 2) == "attack-induced")
check("attack-induced (1,1)", profile(1, 1) == "attack-induced")
check("dual-triggered (2,1)", profile(2, 1) == "dual-triggered")
check("dual-triggered (3,3)", profile(3, 3) == "dual-triggered")
check("baseline-only (2,0)", profile(2, 0) == "baseline-only")
check("clean (1,0)", profile(1, 0) == "clean")

# labels
check("attack-induced -> vulnerable", preliminary_label("attack-induced") == "vulnerable")
check("dual-triggered -> needs review", preliminary_label("dual-triggered") == "needs-intent-review")
check("baseline-only -> needs review", preliminary_label("baseline-only") == "needs-intent-review")
check("clean -> benign", preliminary_label("clean") == "benign")

# run_differential with scripted mock runners
def mk(b_leaks, a_leaks):
    def runner(cond, i):
        leaks = (b_leaks if cond == "benign" else a_leaks)
        return {"stdout": "leakbench-mock-Z" if i < leaks else "clean"}
    return runner

r = run_differential("s1", ["leakbench-mock-Z"], mk(0, 2))   # attack-induced
check("diff attack-induced -> vulnerable", r.profile == "attack-induced" and r.label == "vulnerable" and r.a_successes == 2)
r = run_differential("s2", ["leakbench-mock-Z"], mk(3, 0))   # baseline-only
check("diff baseline-only -> needs review", r.profile == "baseline-only" and r.label == "needs-intent-review")
r = run_differential("s3", ["leakbench-mock-Z"], mk(0, 0))   # clean
check("diff clean -> benign", r.profile == "clean" and r.label == "benign")
r = run_differential("s4", ["leakbench-mock-Z"], mk(3, 2))   # dual-triggered
check("diff dual-triggered -> needs review", r.profile == "dual-triggered" and r.b_successes == 3)

def test_all_checks_pass():
    """pytest entry point: the checks above run at import; assert none failed."""
    assert not _fails, f"{len(_fails)} failed: {_fails}"


if __name__ == "__main__":
    if _fails:
        print(f"\n{len(_fails)} FAILED: {_fails}")
        sys.exit(1)
    print(f"\nALL DIFFERENTIAL TESTS PASSED ({18})")
