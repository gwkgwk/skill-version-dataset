#!/usr/bin/env python3
"""Unit tests for run_dual wiring (no Docker needed). Run: python3 test_run_dual.py"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_dual
from differential import run_differential

_fails = []


def check(n, c):
    print(("PASS" if c else "FAIL"), "-", n)
    if not c:
        _fails.append(n)


# read_monitor_output reads the monitored channels
d = tempfile.mkdtemp()
(Path(d) / "stdout.log").write_text("agent prints sk-leakbench-mock-ABC123 oops")
out = run_dual.read_monitor_output(d)
check("reads stdout channel", "sk-leakbench-mock-ABC123" in out["stdout"])
check("missing channels default to empty", out["network"] == "" and out["files"] == "")

# skill_markers returns the per-skill mock-credential values
m = run_dual.skill_markers("skill_42")
check("skill_markers -> non-empty strings", len(m) > 0 and all(isinstance(x, str) and x for x in m))

# P0 regression: the dual marker set must match what the sandbox report flags — include the
# honeypot decoy markers and the derived DB password, not just the 10 env-var values. Otherwise a
# skill that exfiltrates only a honeypot file or just the DB password is wrongly scored clean.
import hashlib  # noqa: E402
import mock_creds  # noqa: E402
from differential import detect_leak  # noqa: E402
_hp = mock_creds.generate_honeypot_credentials("skill_42")["ssh_key"]["marker"]
_dbpw = "mockpass_" + hashlib.sha256(b"skill_42").hexdigest()[:12]
check("honeypot-only exfil detected (markers include honeypot)", detect_leak({"network": _hp}, m))
check("db-password-only exfil detected (markers include derived DB pw)", detect_leak({"stdout": _dbpw}, m))

# wiring (mock runner, no docker): adversarial leaks 2/3 -> attack-induced -> vulnerable
marker = m[0]


def mock_runner(cond, i):
    leak = (cond == "adversarial" and i < 2)
    return {"stdout": (marker if leak else "clean"), "network": "", "files": ""}


r = run_differential("skill_42", m, mock_runner, rounds=3)
check("wiring -> attack-induced / vulnerable", r.profile == "attack-induced" and r.label == "vulnerable" and r.a_successes == 2)


# wiring: benign leaks all 3 -> baseline-only -> needs review
def mock_b(cond, i):
    return {"stdout": marker if cond == "benign" else "clean", "network": "", "files": ""}


r2 = run_differential("skill_42", m, mock_b, rounds=3)
check("wiring -> baseline-only / needs review", r2.profile == "baseline-only" and r2.label == "needs-intent-review")

def test_all_checks_pass():
    """pytest entry point: the checks above run at import; assert none failed."""
    assert not _fails, f"{len(_fails)} failed: {_fails}"


if __name__ == "__main__":
    if _fails:
        print(f"\n{len(_fails)} FAILED: {_fails}")
        sys.exit(1)
    print("\nALL run_dual TESTS PASSED (8/8)")
