#!/usr/bin/env python3
"""Interactive sandbox executor for SkillLeakBench Phase 3.

This executor provides an interactive testing workflow:
1. Load candidate skills from Phase 2 output
2. Present skills to the user one by one
3. Launch interactive sandbox for manual testing
4. Collect monitoring results after each test

IMPORTANT: This does NOT auto-execute any skill code.
The user must manually test each skill inside the sandbox.
"""

import argparse
import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# Allow running as a script or importing as a module.
try:
    from monitor import SandboxLauncher, run_interactive_session
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from monitor import SandboxLauncher, run_interactive_session

# Also try to load shared config utility.
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "utils"))
    from config_loader import Config
except ImportError:
    Config = None  # type: ignore[misc,assignment]

logger = logging.getLogger("skill-leakbench.phase3.executor")


# ------------------------------------------------------------------
# Candidate loading
# ------------------------------------------------------------------


def load_candidates(candidates_file: str) -> List[Dict[str, Any]]:
    """Load the list of candidate skills produced by Phase 2.

    The expected JSON format is either a plain list of skill dicts or a
    dict containing a ``candidates`` or ``skills`` key holding the list.

    Each skill dict should contain at minimum:
        - ``skill_id``   -- unique identifier
        - ``skill_path`` -- path to the extracted skill directory

    Args:
        candidates_file: Path to the Phase 2 output JSON file.

    Returns:
        List of skill dictionaries ready for execution.
    """
    path = Path(candidates_file)
    if not path.exists():
        logger.error("Candidates file not found: %s", candidates_file)
        return []

    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    # Accept several shapes of JSON.
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("candidates", "skills", "results"):
            if key in data and isinstance(data[key], list):
                return data[key]
        # If it looks like a single skill, wrap it.
        if "skill_id" in data:
            return [data]

    logger.error("Unexpected JSON structure in %s", candidates_file)
    return []


# ------------------------------------------------------------------
# Docker image building
# ------------------------------------------------------------------


def build_docker_image(
    dockerfile_dir: str, image_name: str = "skill-leakbench"
) -> bool:
    """Build the sandbox Docker image from the provided Dockerfile directory.

    Args:
        dockerfile_dir: Directory containing the Dockerfile.
        image_name: Tag to apply to the built image.

    Returns:
        True if the build succeeded, False otherwise.
    """
    dockerfile_path = Path(dockerfile_dir) / "Dockerfile"
    if not dockerfile_path.exists():
        logger.error("Dockerfile not found at %s", dockerfile_path)
        return False

    logger.info("Building Docker image '%s' from %s ...", image_name, dockerfile_dir)
    cmd = [
        "docker",
        "build",
        "-t",
        image_name,
        "-f",
        str(dockerfile_path),
        str(dockerfile_dir),
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            logger.error("Docker build failed:\n%s", result.stderr)
            return False
        logger.info("Docker image '%s' built successfully.", image_name)
        return True
    except subprocess.TimeoutExpired:
        logger.error("Docker build timed out after 600 seconds.")
        return False
    except FileNotFoundError:
        logger.error(
            "docker command not found. Is Docker installed and on PATH?"
        )
        return False
    except Exception as exc:
        logger.error("Docker build error: %s", exc)
        return False


# ------------------------------------------------------------------
# Interactive session management
# ------------------------------------------------------------------


def interactive_session(
    skill: Dict[str, Any],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """Start an interactive sandbox session for a single skill.

    This function:
    1. Launches an interactive Docker container
    2. Waits for the user to manually test the skill
    3. Collects monitoring results when the user exits

    Args:
        skill: Dict with ``skill_id`` and ``skill_path``.
        config: Phase 3 configuration (Docker settings, timeouts, etc.).

    Returns:
        Monitoring result dictionary with leak detection findings.
    """
    skill_id = skill.get("skill_id", "unknown")
    skill_path = skill.get("skill_path", "")

    if not skill_path:
        logger.warning("Skill %s has no skill_path; skipping.", skill_id)
        return {
            "skill_id": skill_id,
            "leaked": False,
            "channels": [],
            "evidence": [],
            "stdout": "",
            "file_changes": {"added": [], "modified": [], "deleted": []},
            "network": {},
            "container_id": None,
            "status": "error:missing_skill_path",
        }

    docker_cfg = config.get("docker", {})
    image_name = docker_cfg.get("image_name", "skill-leakbench")

    monitor_config = {
        "docker_image": image_name,
        "network_mode": docker_cfg.get("network_mode", "none"),
        "memory_limit": docker_cfg.get("memory_limit", "512m"),
    }

    logger.info("Starting interactive session for skill: %s", skill_id)
    print("\n" + "=" * 70)
    print(f"  SKILL: {skill_id}")
    print(f"  PATH:  {skill_path}")
    print("=" * 70)
    print("\nThe sandbox container will now start.")
    print("Please test the skill manually using Claude Code or direct execution.")
    print("When finished, type 'exit' or press Ctrl+D to return to this menu.\n")

    input("Press Enter to start the interactive sandbox...")

    try:
        result = run_interactive_session(
            skill_path=skill_path,
            skill_id=skill_id,
            config=monitor_config,
        )
    except Exception as exc:
        logger.error("Unhandled exception for %s: %s", skill_id, exc)
        result = {
            "skill_id": skill_id,
            "leaked": False,
            "channels": [],
            "evidence": [],
            "stdout": "",
            "file_changes": {"added": [], "modified": [], "deleted": []},
            "network": {},
            "container_id": None,
            "status": f"error:exception:{exc}",
        }

    return result


# ------------------------------------------------------------------
# Interactive menu
# ------------------------------------------------------------------


def interactive_menu(
    candidates: List[Dict[str, Any]],
    config: Dict[str, Any],
    output_dir: str,
) -> Dict[str, Any]:
    """Present an interactive menu for skill testing.

    Args:
        candidates: List of skill dicts from :func:`load_candidates`.
        config: Phase 3 configuration.
        output_dir: Directory to write per-skill result files.

    Returns:
        Summary dictionary with aggregate statistics.
    """
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    results: List[Dict[str, Any]] = []
    completed = 0
    leaked_count = 0
    errors = 0
    tested_skills: set = set()

    # Load any existing results
    for skill in candidates:
        skill_id = skill.get("skill_id", "")
        result_file = out_path / f"{skill_id}_dynamic_result.json"
        if result_file.exists():
            try:
                with open(result_file, "r", encoding="utf-8") as f:
                    existing = json.load(f)
                    results.append(existing)
                    tested_skills.add(skill_id)
                    if existing.get("status") == "completed":
                        completed += 1
                        if existing.get("leaked", False):
                            leaked_count += 1
                    else:
                        errors += 1
            except Exception:
                pass

    while True:
        print("\n" + "=" * 70)
        print("  SkillLeakBench Phase 3 - Interactive Sandbox Menu")
        print("=" * 70)
        print(f"\n  Total candidates: {len(candidates)}")
        print(f"  Tested: {completed} | Leaked: {leaked_count} | Errors: {errors}")
        print("\n  Options:")
        print("    [1-N]  Test skill by number")
        print("    [a]    Test all remaining skills sequentially")
        print("    [l]    List all candidates")
        print("    [s]    Show summary")
        print("    [q]    Quit")
        print()

        choice = input("  Enter choice: ").strip().lower()

        if choice == "q":
            break

        elif choice == "l":
            print("\n  Candidate Skills:")
            print("  " + "-" * 66)
            for idx, skill in enumerate(candidates, start=1):
                skill_id = skill.get("skill_id", f"skill_{idx}")
                status = "✓ tested" if skill_id in tested_skills else "pending"
                print(f"  [{idx:3d}] {skill_id[:50]:<50} ({status})")

        elif choice == "s":
            print("\n  Summary:")
            print(f"    Total:     {len(candidates)}")
            print(f"    Tested:    {completed}")
            print(f"    Leaked:    {leaked_count}")
            print(f"    Errors:    {errors}")
            if completed > 0:
                rate = (leaked_count / completed) * 100
                print(f"    Leak Rate: {rate:.1f}%")

        elif choice == "a":
            # Test all remaining skills
            for idx, skill in enumerate(candidates, start=1):
                skill_id = skill.get("skill_id", f"skill_{idx}")
                if skill_id in tested_skills:
                    continue

                result = interactive_session(skill, config)
                results.append(result)
                tested_skills.add(skill_id)

                # Write per-skill result file
                result_file = out_path / f"{skill_id}_dynamic_result.json"
                try:
                    with open(result_file, "w", encoding="utf-8") as fh:
                        json.dump(result, fh, indent=2, default=str)
                except OSError as exc:
                    logger.warning("Could not write result file for %s: %s", skill_id, exc)

                status = result.get("status", "unknown")
                if status == "completed":
                    completed += 1
                    if result.get("leaked", False):
                        leaked_count += 1
                else:
                    errors += 1

                # Ask if user wants to continue
                cont = input("\nContinue to next skill? [Y/n]: ").strip().lower()
                if cont == "n":
                    break

        elif choice.isdigit():
            idx = int(choice)
            if 1 <= idx <= len(candidates):
                skill = candidates[idx - 1]
                skill_id = skill.get("skill_id", f"skill_{idx}")

                result = interactive_session(skill, config)
                results.append(result)

                # Update counts (before adding to tested_skills)
                if skill_id not in tested_skills:
                    status = result.get("status", "unknown")
                    if status == "completed":
                        completed += 1
                        if result.get("leaked", False):
                            leaked_count += 1
                    else:
                        errors += 1
                    tested_skills.add(skill_id)

                # Write per-skill result file
                result_file = out_path / f"{skill_id}_dynamic_result.json"
                try:
                    with open(result_file, "w", encoding="utf-8") as fh:
                        json.dump(result, fh, indent=2, default=str)
                except OSError as exc:
                    logger.warning("Could not write result file for %s: %s", skill_id, exc)

                # Show result summary
                print("\n  Result:")
                print(f"    Leaked:   {result.get('leaked', False)}")
                print(f"    Channels: {', '.join(result.get('channels', []))}")
                print(f"    Status:   {result.get('status', 'unknown')}")

            else:
                print(f"  Invalid choice: {idx}. Please enter 1-{len(candidates)}.")

        else:
            print(f"  Invalid choice: {choice}")

    # Write aggregate summary
    summary = {
        "total_candidates": len(candidates),
        "completed": completed,
        "errors": errors,
        "leaked_count": leaked_count,
        "leak_rate": round(leaked_count / max(completed, 1), 4),
        "results": results,
    }

    summary_file = out_path / "phase3_summary.json"
    with open(summary_file, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, default=str)

    logger.info(
        "Session complete: %d/%d completed, %d leaked (%.1f%%), %d errors.",
        completed,
        len(candidates),
        leaked_count,
        (leaked_count / max(completed, 1)) * 100,
        errors,
    )

    return summary


# ------------------------------------------------------------------
# CLI entry point
# ------------------------------------------------------------------


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="SkillLeakBench Phase 3 - Interactive Sandbox Executor"
    )
    parser.add_argument(
        "--candidates",
        type=str,
        default=None,
        help=(
            "Path to Phase 2 candidates JSON file. "
            "Defaults to code/results/phase2_scan/candidates.json"
        ),
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to the SkillLeakBench config.yaml file.",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Directory for Phase 3 result files.",
    )
    parser.add_argument(
        "--skip-build",
        action="store_true",
        help="Skip Docker image build (use existing image).",
    )
    parser.add_argument(
        "--image-name",
        type=str,
        default=None,
        help="Override Docker image name.",
    )
    parser.add_argument(
        "--skill",
        type=str,
        default=None,
        help="Test a single skill by ID (non-interactive).",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> None:
    """CLI entry point: load config, build image, start interactive menu."""
    args = parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # --- Load configuration ------------------------------------------------
    cfg_data: Dict[str, Any] = {}
    if Config is not None:
        try:
            cfg = Config(args.config)
            cfg_data = cfg.raw
        except Exception as exc:
            logger.warning("Could not load config.yaml: %s. Using defaults.", exc)
    elif args.config:
        try:
            with open(args.config, "r") as fh:
                cfg_data = json.load(fh) if args.config.endswith(".json") else {}
        except Exception:
            pass

    phase3_cfg = cfg_data.get("phase3", {})
    docker_cfg = phase3_cfg.get("docker", {})
    image_name = args.image_name or docker_cfg.get("image_name", "skill-leakbench")

    # --- Resolve default paths ---------------------------------------------
    project_root = Path(__file__).resolve().parent.parent.parent

    candidates_file = args.candidates or str(
        project_root / "code" / "results" / "phase2_scan" / "candidates.json"
    )
    output_dir = args.output_dir or str(
        project_root
        / cfg_data.get("paths", {}).get("phase3_dir", "code/results/phase3_validation")
    )

    # --- Build Docker image ------------------------------------------------
    if not args.skip_build:
        dockerfile_dir = str(Path(__file__).resolve().parent)
        ok = build_docker_image(dockerfile_dir, image_name)
        if not ok:
            logger.error("Docker image build failed. Aborting.")
            sys.exit(1)
    else:
        logger.info("Skipping Docker build (--skip-build).")

    # --- Load candidates ---------------------------------------------------
    candidates = load_candidates(candidates_file)
    if not candidates:
        logger.warning("No candidates loaded from %s", candidates_file)
        sys.exit(0)

    logger.info("Loaded %d candidates from %s", len(candidates), candidates_file)

    # --- Handle single skill mode ------------------------------------------
    if args.skill:
        # Find the skill by ID
        skill = None
        for s in candidates:
            if s.get("skill_id") == args.skill:
                skill = s
                break

        if not skill:
            logger.error("Skill not found: %s", args.skill)
            sys.exit(1)

        result = interactive_session(skill, phase3_cfg)

        # Write result
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        result_file = out_path / f"{args.skill}_dynamic_result.json"
        with open(result_file, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2, default=str)

        logger.info("Result written to %s", result_file)
        sys.exit(0 if not result.get("leaked", False) else 1)

    # --- Start interactive menu --------------------------------------------
    interactive_menu(
        candidates=candidates,
        config=phase3_cfg,
        output_dir=output_dir,
    )

    logger.info("Phase 3 complete. Results written to %s", output_dir)


if __name__ == "__main__":
    main()
