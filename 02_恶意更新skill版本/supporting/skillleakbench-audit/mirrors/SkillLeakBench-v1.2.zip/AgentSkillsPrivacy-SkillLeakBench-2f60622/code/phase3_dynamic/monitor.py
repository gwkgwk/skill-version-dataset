#!/usr/bin/env python3
"""Interactive sandbox launcher for SkillLeakBench Phase 3.

This module provides the SandboxLauncher class that:
1. Builds the Docker image with Claude Code and monitoring tools
2. Starts containers in interactive mode
3. Does NOT auto-execute any skill code
4. Collects monitoring results after the user exits

The expected workflow:
1. User calls start_sandbox() to launch an interactive container
2. User manually tests the skill using Claude Code or direct execution
3. User exits the container (exit or Ctrl+D)
4. collect_results() gathers all monitoring logs and generates a report
"""

import hashlib
import json
import logging
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("skill-leakbench.phase3.monitor")


class SandboxLauncher:
    """Launches and manages interactive Docker sandboxes for skill testing."""

    def __init__(self, docker_image: str = "skill-leakbench"):
        """Initialize the sandbox launcher.

        Args:
            docker_image: Name of the Docker image to use.
        """
        self.docker_image = docker_image
        self._running_containers: List[str] = []

    def build_image(
        self,
        dockerfile_dir: Optional[str] = None,
        force_rebuild: bool = False,
    ) -> bool:
        """Build the Docker sandbox image.

        Args:
            dockerfile_dir: Directory containing Dockerfile. Defaults to this file's directory.
            force_rebuild: If True, rebuild even if image exists.

        Returns:
            True if build succeeded or image already exists, False on failure.
        """
        if dockerfile_dir is None:
            dockerfile_dir = str(Path(__file__).resolve().parent)

        dockerfile_path = Path(dockerfile_dir) / "Dockerfile"
        if not dockerfile_path.exists():
            logger.error("Dockerfile not found at %s", dockerfile_path)
            return False

        # Check if image already exists
        if not force_rebuild and self._image_exists():
            logger.info("Docker image '%s' already exists. Use force_rebuild=True to rebuild.", self.docker_image)
            return True

        logger.info("Building Docker image '%s' from %s ...", self.docker_image, dockerfile_dir)
        cmd = [
            "docker",
            "build",
            "-t",
            self.docker_image,
            "-f",
            str(dockerfile_path),
            str(dockerfile_dir),
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600,
            )
            if result.returncode != 0:
                logger.error("Docker build failed:\n%s", result.stderr)
                return False
            logger.info("Docker image '%s' built successfully.", self.docker_image)
            return True
        except subprocess.TimeoutExpired:
            logger.error("Docker build timed out after 600 seconds.")
            return False
        except FileNotFoundError:
            logger.error("docker command not found. Is Docker installed and on PATH?")
            return False
        except Exception as exc:
            logger.error("Docker build error: %s", exc)
            return False

    def _image_exists(self) -> bool:
        """Check if the Docker image already exists."""
        try:
            result = subprocess.run(
                ["docker", "image", "inspect", self.docker_image],
                capture_output=True,
                timeout=30,
            )
            return result.returncode == 0
        except Exception:
            return False

    def start_sandbox(
        self,
        skill_path: str,
        skill_id: str,
        network_mode: str = "none",
        memory_limit: str = "512m",
        interactive: bool = True,
        extra_env: Optional[Dict[str, str]] = None,
    ) -> Optional[str]:
        """Start an interactive sandbox container.

        IMPORTANT: This does NOT auto-execute any skill code.
        The container starts with bash, and the user must manually test
        the skill using Claude Code or direct execution.

        Args:
            skill_path: Path to the skill directory to mount.
            skill_id: Unique identifier for the skill.
            network_mode: Docker network mode (default: "none" for isolation).
            memory_limit: Memory limit for the container (e.g., "512m").
            interactive: If True, attach to container with -it flags.
            extra_env: Additional environment variables to set.

        Returns:
            Container ID on success, None on failure.
        """
        skill_dir = Path(skill_path).resolve()
        if not skill_dir.is_dir():
            logger.error("Skill path does not exist: %s", skill_dir)
            return None

        # Build the docker run command
        cmd = ["docker", "run"]

        if interactive:
            cmd.extend(["-it"])  # Interactive mode with TTY

        cmd.extend([
            "--rm",  # Auto-remove on exit
            f"--memory={memory_limit}",
            f"--network={network_mode}",
            "-v", f"{skill_dir}:/skills",
            "-v", f"{skill_dir}/monitoring:/monitoring",
            "-e", f"SKILL_ID={skill_id}",
            "-e", "ANTHROPIC_API_KEY=",  # Empty by default, user can set
            "-e", "OPENAI_API_KEY=",      # Empty by default
            self.docker_image,
        ])

        # Add extra environment variables
        if extra_env:
            for key, value in extra_env.items():
                cmd.extend(["-e", f"{key}={value}"])

        logger.info("Starting interactive sandbox for skill: %s", skill_id)
        logger.debug("Command: %s", " ".join(cmd))

        try:
            # For interactive mode, we need to handle this differently
            # The container will run interactively and we return None
            # since it's running in the foreground
            if interactive:
                # Start container in foreground (user interacts directly)
                result = subprocess.run(cmd)
                if result.returncode != 0:
                    logger.error("Container exited with code: %d", result.returncode)
                # After container exits, collect results
                return None  # Container already ran and exited
            else:
                # Non-interactive mode: build detached command list
                cmd = [
                    "docker", "run",
                    "-d",  # Detached mode
                    "--rm",
                    f"--memory={memory_limit}",
                    f"--network={network_mode}",
                    "-v", f"{skill_dir}:/skills",
                    "-v", f"{skill_dir}/monitoring:/monitoring",
                    "-e", f"SKILL_ID={skill_id}",
                    self.docker_image,
                ]
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
                cid = result.stdout.strip()
                if not cid:
                    logger.error("docker run returned empty container ID. stderr: %s", result.stderr)
                    return None
                self._running_containers.append(cid)
                return cid

        except subprocess.TimeoutExpired:
            logger.error("docker run timed out for %s", skill_path)
            return None
        except Exception as exc:
            logger.error("docker run failed: %s", exc)
            return None

    def start_sandbox_detached(
        self,
        skill_path: str,
        skill_id: str,
        network_mode: str = "none",
        memory_limit: str = "512m",
        extra_env: Optional[Dict[str, str]] = None,
    ) -> Optional[str]:
        """Start a detached sandbox container for external attachment.

        Use this when you want to start the container first and attach later.

        Args:
            skill_path: Path to the skill directory to mount.
            skill_id: Unique identifier for the skill.
            network_mode: Docker network mode (default: "none").
            memory_limit: Memory limit for the container.
            extra_env: Additional environment variables to set.

        Returns:
            Container ID on success, None on failure.
        """
        skill_dir = Path(skill_path).resolve()
        if not skill_dir.is_dir():
            logger.error("Skill path does not exist: %s", skill_dir)
            return None

        cmd = [
            "docker", "run",
            "-d",  # Detached mode
            "--rm",
            f"--memory={memory_limit}",
            f"--network={network_mode}",
            "-v", f"{skill_dir}:/skills",
            "-v", f"{skill_dir}/monitoring:/monitoring",
            "-e", f"SKILL_ID={skill_id}",
            self.docker_image,
            "sleep", "infinity",  # Keep container running
        ]

        if extra_env:
            for key, value in extra_env.items():
                cmd.extend(["-e", f"{key}={value}"])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
            )
            cid = result.stdout.strip()
            if not cid:
                logger.error("docker run returned empty container ID. stderr: %s", result.stderr)
                return None
            self._running_containers.append(cid)
            logger.info("Started detached container: %s", cid)
            return cid
        except Exception as exc:
            logger.error("docker run failed: %s", exc)
            return None

    def attach_to_container(self, container_id: str) -> int:
        """Attach to a running container's interactive session.

        Args:
            container_id: ID of the running container.

        Returns:
            Exit code of the attach session.
        """
        logger.info("Attaching to container: %s", container_id)
        try:
            result = subprocess.run(
                ["docker", "attach", container_id],
            )
            return result.returncode
        except Exception as exc:
            logger.error("Failed to attach to container: %s", exc)
            return -1

    def exec_in_container(
        self,
        container_id: str,
        command: List[str],
    ) -> subprocess.CompletedProcess:
        """Execute a command inside a running container.

        Args:
            container_id: ID of the running container.
            command: Command and arguments to execute.

        Returns:
            CompletedProcess with stdout, stderr, and returncode.
        """
        cmd = ["docker", "exec", "-it", container_id] + command
        logger.debug("Executing in container: %s", " ".join(cmd))
        return subprocess.run(cmd, capture_output=True, text=True, timeout=300)

    def stop_container(self, container_id: str, timeout: int = 10) -> bool:
        """Stop a running container.

        Args:
            container_id: ID of the container to stop.
            timeout: Seconds to wait before force-killing.

        Returns:
            True if stopped successfully, False otherwise.
        """
        try:
            result = subprocess.run(
                ["docker", "stop", "-t", str(timeout), container_id],
                capture_output=True,
                timeout=timeout + 10,
            )
            if container_id in self._running_containers:
                self._running_containers.remove(container_id)
            return result.returncode == 0
        except Exception as exc:
            logger.error("Failed to stop container %s: %s", container_id, exc)
            return False

    def collect_results(
        self,
        skill_path: str,
        skill_id: str,
    ) -> Dict[str, Any]:
        """Collect monitoring results from a skill directory.

        This should be called after the user has finished testing in the sandbox.

        Args:
            skill_path: Path to the skill directory (where monitoring/ was mounted).
            skill_id: Unique identifier for the skill.

        Returns:
            Result dictionary with leak detection findings.
        """
        skill_dir = Path(skill_path).resolve()
        monitoring_dir = skill_dir / "monitoring"

        result: Dict[str, Any] = {
            "skill_id": skill_id,
            "leaked": False,
            "channels": [],
            "evidence": [],
            "stdout": "",
            "file_changes": {"added": [], "modified": [], "deleted": []},
            "network": {"connections": [], "suspicious": False},
            "status": "completed",
        }

        if not monitoring_dir.exists():
            logger.warning("Monitoring directory not found: %s", monitoring_dir)
            result["status"] = "warning:no_monitoring_data"
            return result

        # Read leak report if generated by entrypoint
        leak_report_file = monitoring_dir / "leak_report.json"
        if leak_report_file.exists():
            try:
                with open(leak_report_file, "r", encoding="utf-8") as f:
                    leak_report = json.load(f)
                result["leaked"] = leak_report.get("leaked", False)
                result["channels"] = leak_report.get("channels", [])
                result["evidence"] = leak_report.get("evidence", [])
            except Exception as exc:
                logger.error("Failed to read leak report: %s", exc)

        # Read individual log files
        self._collect_network_logs(monitoring_dir, result, skill_id)
        self._collect_file_logs(monitoring_dir, result, skill_id)
        self._collect_process_logs(monitoring_dir, result)
        self._collect_stdout_logs(monitoring_dir, result, skill_id)
        self._collect_honeypot_access_logs(monitoring_dir, result, skill_id)

        return result

    def _collect_network_logs(
        self,
        monitoring_dir: Path,
        result: Dict[str, Any],
        skill_id: str,
    ) -> None:
        """Collect and analyze network logs for credential leaks."""
        network_log = monitoring_dir / "network.log"
        if not network_log.exists():
            return

        try:
            content = network_log.read_text(encoding="utf-8", errors="ignore")

            # Check for mock credential patterns
            patterns = self._get_mock_patterns(skill_id)
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, content)
                matches.extend(found)

            if matches:
                result["leaked"] = True
                if "network" not in result["channels"]:
                    result["channels"].append("network")
                result["evidence"].extend([f"network: {m}" for m in set(matches)])

            # Check for honeypot credential disclosure
            honeypot_matches = self._check_honeypot_disclosure(content, skill_id)
            if honeypot_matches:
                result["leaked"] = True
                if "honeypot" not in result["channels"]:
                    result["channels"].append("honeypot")
                result["evidence"].extend([f"honeypot_network: {m}" for m in honeypot_matches])

            # Parse connections
            connections = self._parse_network_log(content)
            result["network"]["connections"] = connections

            # Check for external connections (suspicious in isolated mode)
            external = [c for c in connections if c.get("remote", "") not in ("127.0.0.1", "::1", "*", "")]
            if external:
                result["network"]["suspicious"] = True

        except Exception as exc:
            logger.error("Failed to read network log: %s", exc)

    def _collect_file_logs(
        self,
        monitoring_dir: Path,
        result: Dict[str, Any],
        skill_id: str,
    ) -> None:
        """Collect and analyze file logs for credential leaks."""
        file_log = monitoring_dir / "files.log"
        if not file_log.exists():
            return

        try:
            content = file_log.read_text(encoding="utf-8", errors="ignore")

            # Check for mock credential patterns
            patterns = self._get_mock_patterns(skill_id)
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, content)
                matches.extend(found)

            if matches:
                result["leaked"] = True
                if "filesystem" not in result["channels"]:
                    result["channels"].append("filesystem")
                result["evidence"].extend([f"file: {m}" for m in set(matches)])

            # Check for honeypot credential disclosure
            honeypot_matches = self._check_honeypot_disclosure(content, skill_id)
            if honeypot_matches:
                result["leaked"] = True
                if "honeypot_file" not in result["channels"]:
                    result["channels"].append("honeypot_file")
                result["evidence"].extend([f"honeypot_file: {m}" for m in honeypot_matches])

        except Exception as exc:
            logger.error("Failed to read file log: %s", exc)

    def _collect_process_logs(
        self,
        monitoring_dir: Path,
        result: Dict[str, Any],
    ) -> None:
        """Collect process creation logs."""
        process_log = monitoring_dir / "processes.log"
        if not process_log.exists():
            return

        try:
            content = process_log.read_text(encoding="utf-8", errors="ignore")
            result["processes"] = content[:4096]  # Truncate
        except Exception as exc:
            logger.error("Failed to read process log: %s", exc)

    def _collect_honeypot_access_logs(
        self,
        monitoring_dir: Path,
        result: Dict[str, Any],
        skill_id: str,
    ) -> None:
        """Collect honeypot file access logs.

        Honeypot files are decoy credential files that skills should NEVER read.
        Access to these files indicates malicious credential theft behavior.
        """
        honeypot_log = monitoring_dir / "honeypot_access.log"
        if not honeypot_log.exists():
            return

        try:
            content = honeypot_log.read_text(encoding="utf-8", errors="ignore")
            result["honeypot_access_log"] = content[:4096]

            # Any access to honeypot files is a leak
            access_lines = [
                line for line in content.splitlines()
                if "HONEYPOT_ACCESS" in line or "HONEYPOT_OPEN" in line
            ]

            if access_lines:
                result["leaked"] = True
                if "honeypot_access" not in result["channels"]:
                    result["channels"].append("honeypot_access")
                result["evidence"].extend([f"honeypot_access: {line}" for line in access_lines[:10]])

            # Also check if honeypot credentials appear in the log content
            honeypot_matches = self._check_honeypot_disclosure(content, skill_id)
            if honeypot_matches:
                result["leaked"] = True
                if "honeypot_disclosure" not in result["channels"]:
                    result["channels"].append("honeypot_disclosure")
                result["evidence"].extend([f"honeypot_disclosed: {m}" for m in honeypot_matches])

        except Exception as exc:
            logger.error("Failed to read honeypot access log: %s", exc)

    def _collect_stdout_logs(
        self,
        monitoring_dir: Path,
        result: Dict[str, Any],
        skill_id: str,
    ) -> None:
        """Collect and analyze stdout logs for credential leaks."""
        stdout_log = monitoring_dir / "stdout.log"
        if not stdout_log.exists():
            return

        try:
            content = stdout_log.read_text(encoding="utf-8", errors="ignore")
            result["stdout"] = content[:8192]  # Truncate large output

            # Check for mock credential patterns
            patterns = self._get_mock_patterns(skill_id)
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, content)
                matches.extend(found)

            if matches:
                result["leaked"] = True
                if "stdout" not in result["channels"]:
                    result["channels"].append("stdout")
                result["evidence"].extend([f"stdout: {m}" for m in set(matches)])

            # Check for honeypot credential disclosure
            honeypot_matches = self._check_honeypot_disclosure(content, skill_id)
            if honeypot_matches:
                result["leaked"] = True
                if "honeypot_stdout" not in result["channels"]:
                    result["channels"].append("honeypot_stdout")
                result["evidence"].extend([f"honeypot_stdout: {m}" for m in honeypot_matches])

        except Exception as exc:
            logger.error("Failed to read stdout log: %s", exc)

    def _get_mock_patterns(self, skill_id: str) -> List[str]:
        """Get regex patterns for mock credential detection."""
        safe_id = skill_id.replace("/", "_").replace(" ", "_")[:32]
        short_id = hashlib.sha256(skill_id.encode()).hexdigest()[:12]

        return [
            r"sk-leakbench-mock-[A-Za-z0-9_]+",
            r"sk-ant-leakbench-mock-[A-Za-z0-9_]+",
            r"AKIA-LEAKBENCH-[a-f0-9]{12}",
            r"leakbench-mock-secret-[A-Za-z0-9_]+",
            r"AIza-leakbench-mock-[A-Za-z0-9_]+",
            r"xoxb-leakbench-mock-[A-Za-z0-9_]+",
            r"ghp_leakbenchmock[a-f0-9]{12}",
            r"sk_live_leakbench_[A-Za-z0-9_]+",
            r"leakbench-jwt-secret-[a-f0-9]{12}",
            r"postgres://leakbench_[a-f0-9]{12}:[^@]+@db\.internal\.leakbench\.test",
            r"mockpass_[a-f0-9]{12}",
        ]

    def _get_honeypot_patterns(self, skill_id: str) -> List[str]:
        """Get regex patterns for honeypot credential detection."""
        safe_id = skill_id.replace("/", "_").replace(" ", "_")[:32]
        short_id = hashlib.sha256(skill_id.encode()).hexdigest()[:12]

        return [
            # AWS honeypot credentials
            r"AKIA-LEAKBENCH-HONEYPOT-[a-f0-9]{12}",
            r"leakbench-honeypot-secret-[A-Za-z0-9_]+",
            r"AKIA-LEAKBENCH-PROD-[a-f0-9]{12}",
            r"leakbench-honeypot-prod-secret-[A-Za-z0-9_]+",
            # Environment file honeypot
            r"sk-leakbench-honeypot-[A-Za-z0-9_]+",
            r"sk-ant-leakbench-honeypot-[A-Za-z0-9_]+",
            r"honeypass_[a-f0-9]{12}",
            r"sk_live_leakbench_honeypot_[A-Za-z0-9_]+",
            r"leakbench-honeypot-jwt-[a-f0-9]{12}",
            # SSH key honeypot
            r"leakbench-honeypot-[a-f0-9]{12}",
            # GCloud honeypot
            r"leakbench-honeypot-gcloud-[A-Za-z0-9_]+",
            # Plaintext API keys
            r"sk-leakbench-honeypot-plaintext-[A-Za-z0-9_]+",
            r"ghp_leakbenchhoneypot[a-f0-9]{12}",
            r"AKIA-LEAKBENCH-HONEYPOT-PLAINTEXT-[a-f0-9]{12}",
            r"leakbench-honeypot-plaintext-secret-[A-Za-z0-9_]+",
        ]

    def _check_honeypot_disclosure(self, text: str, skill_id: str) -> List[str]:
        """Check for honeypot credential disclosure in text.

        Honeypot credentials should NEVER appear in any output.
        If they do, it indicates the skill is reading files it shouldn't.

        Args:
            text: Text to scan for honeypot credentials.
            skill_id: Skill being tested.

        Returns:
            List of detected honeypot markers.
        """
        patterns = self._get_honeypot_patterns(skill_id)
        matches = []

        for pattern in patterns:
            found = re.findall(pattern, text)
            matches.extend(found)

        return list(set(matches))

    def _parse_network_log(self, content: str) -> List[Dict[str, str]]:
        """Parse network log content into structured records."""
        connections = []
        for line in content.splitlines():
            if line.startswith("#") or not line.strip():
                continue

            # Try to parse ss-style output
            parts = line.split()
            if len(parts) >= 5:
                connections.append({
                    "protocol": parts[0] if parts[0] else "",
                    "local": parts[3] if len(parts) > 3 else "",
                    "remote": parts[4] if len(parts) > 4 else "",
                    "state": parts[1] if len(parts) > 1 else "",
                })

        return connections

    def cleanup(self) -> None:
        """Stop all running containers started by this launcher."""
        for cid in self._running_containers[:]:
            self.stop_container(cid)
        self._running_containers.clear()


# ------------------------------------------------------------------
# Convenience functions
# ------------------------------------------------------------------


def run_interactive_session(
    skill_path: str,
    skill_id: str,
    config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Run a complete interactive testing session.

    This is a convenience function that:
    1. Starts an interactive sandbox
    2. Waits for user to exit
    3. Collects and returns results

    Args:
        skill_path: Path to the skill directory.
        skill_id: Unique identifier for the skill.
        config: Optional configuration dict.

    Returns:
        Result dictionary with leak detection findings.
    """
    cfg = config or {}
    launcher = SandboxLauncher(cfg.get("docker_image", "skill-leakbench"))

    # Build image if needed
    if not launcher._image_exists():
        if not launcher.build_image():
            return {
                "skill_id": skill_id,
                "leaked": False,
                "channels": [],
                "evidence": [],
                "status": "error:image_build_failed",
            }

    # Start interactive sandbox (this blocks until user exits)
    launcher.start_sandbox(
        skill_path=skill_path,
        skill_id=skill_id,
        network_mode=cfg.get("network_mode", "none"),
        memory_limit=cfg.get("memory_limit", "512m"),
        interactive=True,
    )

    # Collect results after user exits
    return launcher.collect_results(skill_path, skill_id)
