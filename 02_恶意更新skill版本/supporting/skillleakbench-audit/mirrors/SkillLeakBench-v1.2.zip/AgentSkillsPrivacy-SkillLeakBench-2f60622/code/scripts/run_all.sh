#!/bin/bash
# SkillLeakBench: Run full three-phase pipeline
#
# Usage:
#   bash code/scripts/run_all.sh              # Run all phases
#   bash code/scripts/run_all.sh --skip 1     # Skip Phase 1
#   bash code/scripts/run_all.sh --skip 1,3   # Skip Phase 1 and 3

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/lib.sh"
load_dotenv

cd "$PROJECT_DIR"

SKIP=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --skip)
            SKIP="$2"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            echo "Usage: $0 [--skip PHASES]"
            echo "  --skip PHASES   Comma-separated phase numbers to skip (1,2,3)"
            exit 1
            ;;
    esac
done

echo "============================================"
echo "  SkillLeakBench Pipeline"
echo "============================================"
echo ""

START_TIME=$(date +%s)

# Phase 1: Data Collection
if echo "$SKIP" | grep -q "1"; then
    echo "[SKIP] Phase 1: Data Collection"
else
    bash code/scripts/01_collect.sh
fi

echo ""

# Phase 2: Static Filtering
if echo "$SKIP" | grep -q "2"; then
    echo "[SKIP] Phase 2: Static Filtering"
else
    bash code/scripts/02_static_filter.sh
fi

echo ""

# Phase 3: Dynamic Validation
if echo "$SKIP" | grep -q "3"; then
    echo "[SKIP] Phase 3: Dynamic Validation"
else
    # Phase 3 mode is configurable via code/.env (PHASE3_MODE=dual|self-test). DEFAULT = dual:
    # the real agent-driven Benign/Adversarial validation (needs Docker + a Claude credential,
    # i.e. ANTHROPIC_API_KEY or CLAUDE_CREDENTIALS_FILE). 'self-test' is the no-API-key sandbox
    # leak-detection check.
    if [ "${PHASE3_MODE:-dual}" = "self-test" ]; then
        bash code/scripts/03_dynamic_validate.sh --self-test
    else
        bash code/scripts/03_dynamic_validate.sh --dual code/results/phase2_scan/candidates.json
    fi
fi

END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo ""
echo "============================================"
echo "  Pipeline Complete (${ELAPSED}s)"
echo "============================================"
echo ""
echo "Results:"
echo "  data/                        - Dataset (CSV)"
echo "  code/results/phase1_downloads/    - Downloaded skills"
echo "  code/results/phase2_scan/         - Static scan results"
echo "  code/results/phase2_nl/           - NL analysis results"
echo "  code/results/phase3_validation/   - Dynamic validation results"
