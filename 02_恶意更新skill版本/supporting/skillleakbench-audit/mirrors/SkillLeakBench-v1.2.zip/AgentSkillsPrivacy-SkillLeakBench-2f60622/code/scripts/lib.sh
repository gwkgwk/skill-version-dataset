#!/usr/bin/env bash
# Shared helpers sourced by SkillLeakBench pipeline scripts.
# Usage:  source "$(dirname "$0")/lib.sh"

SLB_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SLB_LIB_DIR/../.." && pwd)"
CONFIG="${CONFIG:-$PROJECT_DIR/config.yaml}"

log_info()    { printf '\033[0;34m[INFO]\033[0m %s\n' "$*"; }
log_success() { printf '\033[0;32m[ OK ]\033[0m %s\n' "$*"; }
log_warn()    { printf '\033[0;33m[WARN]\033[0m %s\n' "$*"; }
log_error()   { printf '\033[0;31m[FAIL]\033[0m %s\n' "$*" >&2; }

# Load code/.env (if present) into the environment without committing secrets.
load_dotenv() {
  # Load code/.env WITHOUT overriding variables already set in the environment (an externally
  # exported value wins over a stale .env entry) and without `source`-ing it (no arbitrary shell
  # execution). Simple KEY=VALUE lines only; comments/blank lines skipped.
  local env_file="${1:-$PROJECT_DIR/code/.env}" line key val
  [ -f "$env_file" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    line="${line%$'\r'}"
    case "$line" in ''|\#*) continue ;; esac
    [ "$line" = "${line#*=}" ] && continue
    key="${line%%=*}"; val="${line#*=}"
    key="${key//[[:space:]]/}"
    case "$key" in ''|*[!A-Za-z0-9_]*) continue ;; esac
    [ -n "${!key+x}" ] && continue
    val="${val%\"}"; val="${val#\"}"; val="${val%\'}"; val="${val#\'}"
    export "$key=$val"
  done < "$env_file"
  log_info "loaded env from $env_file (existing env preserved)"
}
