#!/bin/bash
# SkillLeakBench Phase 3: Dynamic Validation
#
# Modes (first argument):
#   --self-test        (default) Non-interactive forged-credential E2E: a skill
#                      exfiltrates the sandbox-injected forged third-party creds
#                      (mock OPENAI_API_KEY, AWS_*, DATABASE_URL) and we assert the
#                      sandbox flags leaked=true. Needs Docker only — NO API key, NO network.
#   --dual CANDS       Agent-driven dual-condition (Benign/Adversarial x3) per candidate
#                      via run_dual.py. Needs Docker + a valid ANTHROPIC_API_KEY
#                      (or host CLAUDE_CREDENTIALS_FILE); uses network=bridge.
#   --interactive CANDS  Human-in-the-loop sandbox menu (executor.py). Needs a TTY.
#
# CANDS defaults to code/results/phase2_scan/candidates.json. Set SLB_DOCKER (e.g. "sudo docker")
# and SLB_IMAGE to override the docker binary / image name.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/lib.sh"
load_dotenv   # code/.env: DOCKER_CMD / DOCKER_IMAGE / DUAL_ROUNDS / DUAL_NETWORK
CONFIG="${CONFIG:-$PROJECT_DIR/config.yaml}"
DOCKER="${SLB_DOCKER:-${DOCKER_CMD:-docker}}"
IMAGE="${SLB_IMAGE:-${DOCKER_IMAGE:-skill-leakbench}}"

cd "$PROJECT_DIR"

MODE="--self-test"
CANDIDATES="code/results/phase2_scan/candidates.json"
case "${1:-}" in
    --self-test|"")  MODE="--self-test" ;;
    --dual)          MODE="--dual";        CANDIDATES="${2:-$CANDIDATES}" ;;
    --interactive)   MODE="--interactive"; CANDIDATES="${2:-$CANDIDATES}" ;;
    *)               MODE="--interactive"; CANDIDATES="$1" ;;  # back-compat: bare path
esac

echo "============================================"
echo "  SkillLeakBench Phase 3: Dynamic Validation"
echo "  mode: $MODE"
echo "============================================"

# Build the sandbox image (idempotent: skip if it already exists).
# For --self-test we delegate Docker availability to the fixture (which exits 77 = clean
# skip when Docker/the image is absent), and only build if the daemon is actually up — so a
# Docker-less machine SKIPS rather than failing the build under `set -e`.
if [ "$MODE" = "--self-test" ]; then
    if $DOCKER info >/dev/null 2>&1 && ! $DOCKER image inspect "$IMAGE" >/dev/null 2>&1; then
        # Daemon is up but the image is missing: build it. A build FAILURE here is a real
        # error (set -e surfaces it) rather than being masked as a skip; Docker-unavailable
        # (daemon down) is handled by the fixture's exit-77 skip, not reached here.
        echo "[*] Building sandbox image '$IMAGE' ..."
        $DOCKER build -t "$IMAGE" code/phase3_dynamic/
    fi
elif $DOCKER image inspect "$IMAGE" >/dev/null 2>&1; then
    echo "[*] Image '$IMAGE' present; skipping build."
else
    echo "[*] Building sandbox image '$IMAGE' ..."
    $DOCKER build -t "$IMAGE" code/phase3_dynamic/
fi

case "$MODE" in
    --self-test)
        echo ""
        echo "[E2E] Forged-credential leak detection (non-interactive, no API key)..."
        overall=0; skipped=0
        for fx in test_e2e_sandbox.sh test_e2e_network_exfil.sh; do
            echo "  -> $fx"
            rc=0
            bash "code/phase3_dynamic/$fx" || rc=$?
            if [ "$rc" -eq 77 ]; then
                skipped=1
            elif [ "$rc" -ne 0 ]; then
                overall=$rc
            fi
        done
        if [ "$overall" -ne 0 ]; then
            echo "Phase 3 self-test FAILED (exit $overall)."
            exit "$overall"
        elif [ "$skipped" -eq 1 ]; then
            echo "Phase 3 self-test SKIPPED (docker/image unavailable)."
        else
            echo "Phase 3 self-test PASSED: sandbox detects stdout AND network credential leaks end-to-end."
        fi
        ;;
    --dual)
        echo ""
        echo "[DUAL] Agent-driven dual-condition validation via run_dual.py ..."
        # Resolve Claude auth: prefer an explicit ANTHROPIC_API_KEY / CLAUDE_CREDENTIALS_FILE,
        # else auto-detect the local Claude Code credential ($CLAUDE_CONFIG_DIR, then ~/.claude).
        if [ -z "${ANTHROPIC_API_KEY:-}" ] && [ -z "${CLAUDE_CREDENTIALS_FILE:-}" ]; then
            for c in "${CLAUDE_CONFIG_DIR:-/dev/null}/.credentials.json" "$HOME/.claude/.credentials.json" "$HOME/.credentials.json"; do
                if [ -f "$c" ]; then export CLAUDE_CREDENTIALS_FILE="$c"; echo "       auto-detected Claude credential: $c"; break; fi
            done
        fi
        if [ -z "${ANTHROPIC_API_KEY:-}" ] && { [ -z "${CLAUDE_CREDENTIALS_FILE:-}" ] || [ ! -f "${CLAUDE_CREDENTIALS_FILE}" ]; }; then
            echo "[dual] No Claude auth found. Set CLAUDE_CREDENTIALS_FILE or ANTHROPIC_API_KEY in code/.env"
            echo "       (or set PHASE3_MODE=self-test for the no-API-key sandbox check). Aborting dual."
            exit 1
        fi
        echo "       auth source: ${CLAUDE_CREDENTIALS_FILE:-ANTHROPIC_API_KEY}"
        echo "       NOTE: each candidate runs 2x DUAL_ROUNDS agent rounds (~minutes each)."
        echo "       For a quick end-to-end check: DUAL_ROUNDS=1, or PHASE3_MODE=self-test."
        OUTPUT_DIR="code/results/phase3_validation"; mkdir -p "$OUTPUT_DIR"
        SLB_DOCKER="$DOCKER" python3 code/phase3_dynamic/run_dual.py \
            --candidates "$CANDIDATES" --image "$IMAGE" --output-dir "$OUTPUT_DIR" \
            --rounds "${DUAL_ROUNDS:-3}" --network "${DUAL_NETWORK:-bridge}"
        echo ""
        echo "Phase 3 complete. Results in: $OUTPUT_DIR/"
        ;;
    --interactive)
        echo ""
        echo "[INTERACTIVE] Human-in-the-loop sandbox menu (executor.py) ..."
        echo "       NOTE: this path is interactive and needs a TTY."
        OUTPUT_DIR="code/results/phase3_validation"; mkdir -p "$OUTPUT_DIR"
        python3 code/phase3_dynamic/executor.py \
            --config "$CONFIG" --candidates "$CANDIDATES" --output-dir "$OUTPUT_DIR"
        echo ""
        echo "Phase 3 complete. Results in: $OUTPUT_DIR/"
        ;;
esac
