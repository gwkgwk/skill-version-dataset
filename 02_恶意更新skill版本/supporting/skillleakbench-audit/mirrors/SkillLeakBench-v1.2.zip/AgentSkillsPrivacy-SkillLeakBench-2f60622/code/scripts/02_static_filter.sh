#!/bin/bash
# SkillLeakBench Phase 2: Static Filtering
# Run regex-based pattern scanner and NL description analyzer

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
CONFIG="${CONFIG:-$PROJECT_DIR/config.yaml}"

cd "$PROJECT_DIR"

echo "============================================"
echo "  SkillLeakBench Phase 2: Static Filtering"
echo "============================================"

INPUT_DIR="${1:-code/results/phase1_downloads/repos}"
SCAN_OUTPUT="code/results/phase2_scan"
NL_OUTPUT="code/results/phase2_nl"

# Guard: Phase 2 scans EXTRACTED skill directories (one folder per skill) produced
# by Phase 1 — NOT the released data/*.csv. Without them the scan/NL steps silently
# produce empty results, which looks like "nothing found" rather than "no input".
if [ ! -d "$INPUT_DIR" ] || [ -z "$(find "$INPUT_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | head -1)" ]; then
    echo "ERROR: no skill repositories found under '$INPUT_DIR'."
    echo "  Phase 2 needs extracted skill folders from Phase 1 (python3 code/helper.py run,"
    echo "  or code/scripts/01_collect.sh), not the released data/ CSVs."
    echo "  Pass a directory of skill folders explicitly, e.g.:"
    echo "    bash code/scripts/02_static_filter.sh /path/to/skill_repos"
    exit 1
fi

mkdir -p "$SCAN_OUTPUT" "$NL_OUTPUT"

# Step 1: Source code scanning (14 patterns: 10 academic classifications + 4 false-positive filters)
echo ""
echo "[1/2] Running pattern-based scanner on: $INPUT_DIR"
python3 code/phase2_static/scanner.py \
    --config "$CONFIG" \
    --full-scan "$INPUT_DIR" \
    --output "$SCAN_OUTPUT"

# Step 2: NL description analysis
echo ""
echo "[2/2] Running NL description analyzer..."
python3 code/phase2_static/nl_analyzer.py \
    --config "$CONFIG" \
    --input "$INPUT_DIR" \
    --output "$NL_OUTPUT"

# Summary
echo ""
echo "Phase 2 complete."
echo "  Scan results:  $SCAN_OUTPUT/"
echo "  NL results:    $NL_OUTPUT/"

if [ -f "$SCAN_OUTPUT/batch_summary.json" ]; then
    echo ""
    echo "Candidate-signal summary (matches vs the 10 patterns; final labels assigned in manual review):"
    python3 -c "
import json
with open('$SCAN_OUTPUT/batch_summary.json') as f:
    s = json.load(f)
print(f'  Total scanned:                      {s.get(\"scanned_skills\", s.get(\"total_skills\", \"?\"))}')
mal = s.get('results', {}).get('malicious', {}).get('total', 0)
vul = s.get('results', {}).get('vulnerabilities', {}).get('total', 0)
false_pos = s.get('results', {}).get('false_positives', {}).get('total', 0)
# Candidate matches vs the paper patterns (MAL-001..6 / VUL-001..4) — NOT confirmed labels.
print(f'  Skills matching malicious patterns: {mal}')
print(f'  Vulnerability-pattern matches:      {vul}')
print(f'  False positives filtered:           {false_pos}')
"
fi

# Step 3: Generate candidates.json for Phase 3
# A skill is a candidate if ANY static signal fires: regex (malicious/vulnerability),
# AST credential->sink flow, OR NL-description flag. Each candidate records its reasons.
echo ""
echo "[3/3] Generating candidates.json for Phase 3..."
python3 - "$SCAN_OUTPUT" "$NL_OUTPUT" <<'PY'
import json, sys
from pathlib import Path

scan_dir, nl_dir = Path(sys.argv[1]), Path(sys.argv[2])
cands = {}  # skill_id -> {skill_id, skill_path, reasons:set}

def add(sid, path, reason):
    c = cands.setdefault(sid, {"skill_id": sid, "skill_path": path or "", "reasons": set()})
    if path and not c["skill_path"]:
        c["skill_path"] = path
    c["reasons"].add(reason)

for rf in scan_dir.glob('*_result.json'):
    try:
        d = json.load(open(rf))
    except Exception as e:
        print(f'  Warning: could not parse {rf}: {e}', file=sys.stderr)
        continue
    sid = d.get('skill_id', rf.stem.replace('_result', ''))
    path = d.get('skill_path', '')
    if d.get('malicious_patterns'):
        add(sid, path, 'malicious_pattern')
    if d.get('vulnerabilities'):
        add(sid, path, 'vulnerability_pattern')
    if d.get('ast_flows'):
        add(sid, path, 'ast_flow')

# NL-description flags live in a separate output dir; merge them in by skill_id.
for nf in nl_dir.glob('*_nl.json'):
    try:
        d = json.load(open(nf))
    except Exception:
        continue
    if d.get('is_flagged'):
        add(d.get('skill_id', nf.stem.replace('_nl', '')), d.get('skill_path', ''), 'nl')

out = [{"skill_id": c["skill_id"], "skill_path": c["skill_path"], "reasons": sorted(c["reasons"])}
       for c in cands.values()]
(scan_dir / 'candidates.json').write_text(json.dumps(out, indent=2))
print(f'  Candidates: {len(out)} skills (malicious-pattern / vulnerability-pattern / AST-flow / NL signals) -> {scan_dir / "candidates.json"}')
PY
