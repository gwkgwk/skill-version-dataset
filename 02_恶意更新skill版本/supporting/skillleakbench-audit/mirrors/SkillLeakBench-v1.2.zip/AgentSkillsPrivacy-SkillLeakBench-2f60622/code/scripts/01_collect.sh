#!/bin/bash
# SkillLeakBench Phase 1: Data Collection
# Crawl skill metadata and download repositories

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
source "$SCRIPT_DIR/lib.sh"
load_dotenv   # code/.env: CRAWL_LIMIT / DOWNLOAD_WORKERS
CONFIG="${CONFIG:-$PROJECT_DIR/config.yaml}"

cd "$PROJECT_DIR"

echo "============================================"
echo "  SkillLeakBench Phase 1: Data Collection"
echo "============================================"

# Step 1: Crawl metadata (CRAWL_LIMIT caps the TOTAL skills; unset/0 = config default)
echo ""
echo "[1/3] Crawling skill metadata from SkillsMP..."
if [ -n "${CRAWL_LIMIT:-}" ]; then
    echo "  (crawl up to ${CRAWL_LIMIT} skills total)"
    python3 code/phase1_collection/crawler.py --config "$CONFIG" metadata --max-limit "$CRAWL_LIMIT"
else
    python3 code/phase1_collection/crawler.py --config "$CONFIG" metadata
fi

# Step 2: Download repositories (DOWNLOAD_WORKERS = concurrency; CRAWL_LIMIT caps how many)
echo ""
echo "[2/3] Downloading skill repositories..."
DL_ARGS=(--config "$CONFIG" download)
[ -n "${DOWNLOAD_WORKERS:-}" ] && DL_ARGS+=(--workers "$DOWNLOAD_WORKERS")
[ -n "${CRAWL_LIMIT:-}" ] && DL_ARGS+=(--max-limit "$CRAWL_LIMIT")
python3 code/phase1_collection/crawler.py "${DL_ARGS[@]}"

# Step 3: Extract ZIP files
echo ""
echo "[3/3] Extracting downloaded archives..."
python3 code/phase1_collection/extractor.py \
    --config "$CONFIG"

echo ""
echo "Phase 1 complete. Results in: code/results/phase1_downloads/"
