---
name: threat-modeling
description: This skill should be used when the user mentions keywords related to threat-modeling.
version: 1.0.0
---

# Skill: threat-modeling

This skill provides methodology guidance for threat-modeling work.

## Key Principles

Apply best practices from the reference books when working on threat-modeling tasks.

## Process

1. Read relevant input documents
2. Apply methodology principles
3. Document decisions and trade-offs
4. Follow the patterns established in the codebase

## Testing Your Work

Ensure quality by:
- Checking against the principles above
- Getting feedback from team members
- Verifying against acceptance criteria
- Following the SDLC process

